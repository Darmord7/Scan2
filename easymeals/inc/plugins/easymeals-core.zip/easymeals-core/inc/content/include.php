<?php

include_once EASYMEALS_CORE_INC_PATH . '/content/helper.php';