<?php

require_once EASYMEALS_CORE_INC_PATH . '/like/like.php';
require_once EASYMEALS_CORE_INC_PATH . '/like/helpers.php';