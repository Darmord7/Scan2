(function($) {
    'use strict';
	
	$(document).ready(function () {
		qodefLikes.init();
	});
	
	var qodefLikes = {
		init: function () {
			$(document).on('click','.qodef-like', function() {
				var likeLink = $(this),
					id = likeLink.attr('id'),
					postID = likeLink.data('post-id'),
                    unlike = false,
					type = '';
				
				if ( likeLink.hasClass('liked') ) {
                    unlike = true;
				}
				
				if (typeof likeLink.data('type') !== 'undefined') {
					type = likeLink.data('type');
				}

				var dataToPass = {
					action: 'easymeals_core_action_like',
					likes_id: id,
					type: type,
                    unlike: unlike,
					like_nonce: $('#qodef_like_nonce_'+postID).val()
				};
				
				var like = $.post(easymeals_ajax_object.ajax_url, dataToPass, function( data ) {
				    if(!unlike) {
                        likeLink.addClass('liked').attr('title', 'You already like this!').children('span').html(data);
                    } else {
                        likeLink.removeClass('liked').attr('title', '').children('span').html(data);
                    }
				});
				
				return false;
			});
		},
	};
    
})(jQuery);