<?php

if ( ! function_exists( 'easymeals_core_action_like' ) ) {
	/**
	 * Returns ThemeNamePhpClassLike instance
	 *
	 * @return ThemeNamePhpClassLike
	 */
	function easymeals_core_action_like() {
		return EasyMealsCoreLike::get_instance();
	}
}

function easymeals_core_get_like() {
	
	echo wp_kses( easymeals_core_action_like()->add_like(), array(
		'span'  => array(
			'class'       => true,
			'aria-hidden' => true,
			'style'       => true,
			'id'          => true
		),
		'i'     => array(
			'class' => true,
			'style' => true,
			'id'    => true
		),
		'a'     => array(
			'href'         => true,
			'class'        => true,
			'id'           => true,
			'title'        => true,
			'style'        => true,
			'data-post-id' => true
		),
		'input' => array(
			'type'  => true,
			'name'  => true,
			'id'    => true,
			'value' => true
		)
	) );
}