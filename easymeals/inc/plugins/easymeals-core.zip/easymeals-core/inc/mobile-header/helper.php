<?php

if ( ! function_exists( 'easymeals_core_dependency_for_mobile_menu_typography_options' ) ) {
	function easymeals_core_dependency_for_mobile_menu_typography_options() {
		$dependency_options = apply_filters( 'easymeals_core_filter_mobile_menu_typography_hide_option', $hide_dep_options = array() );
		
		return $dependency_options;
	}
}