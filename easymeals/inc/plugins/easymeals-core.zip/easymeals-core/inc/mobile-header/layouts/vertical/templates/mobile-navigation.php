<?php if ( has_nav_menu( 'mobile-navigation' ) || has_nav_menu( 'main-navigation' ) ) { ?>
	<div class="qodef-mobile-side-area">
		<div class="qodef-close-mobile-side-area-holder">
			<?php echo qode_framework_icons()->render_icon( 'lnr-cross', 'linear-icons' ); ?>
        </div>
		<div class="qodef-mobile-side-area-inner">
			<nav id="qodef-vertical-mobile-header-navigation" class="qodef-m" role="navigation" aria-label="<?php esc_attr_e( 'Mobile Menu', 'easymeals-core' ); ?>">
				<div class="qodef-grid">
					<?php
					// Set main navigation menu as mobile if mobile navigation is not set
					$theme_location = has_nav_menu( 'mobile-navigation' ) ? 'mobile-navigation' : 'main-navigation';
					
					wp_nav_menu( array(
						'theme_location'  => $theme_location,
						'container_class' => 'qodef-m-inner',
						'menu_id'         => 'qodef-mobile-header-navigation-menu',
						'menu_class'      => '',
						'link_before'     => '<span>',
						'link_after'      => '</span>',
			            'walker'          => new EasyMealsCoreRootMainMenuWalker(),
		             ) ); ?>
				</div>
			</nav>
		</div>
	</div>
<?php } ?>