<?php

if ( ! function_exists( 'easymeals_core_add_vertical_mobile_header_global_option' ) ) {
	/**
	 * This function set header type value for global header option map
	 */
	function easymeals_core_add_vertical_mobile_header_global_option( $header_layout_options ) {
		$header_layout_options['vertical'] = array(
			'image' => EASYMEALS_CORE_INC_URL_PATH . '/mobile-header/layouts/vertical/assets/img/vertical-header.png',
			'label' => esc_html__( 'Vertical', 'easymeals-core' )
		);

		return $header_layout_options;
	}

	add_filter( 'easymeals_core_filter_mobile_header_layout_option', 'easymeals_core_add_vertical_mobile_header_global_option' );
}

if ( ! function_exists( 'easymeals_core_register_vertical_mobile_header_layout' ) ) {
	function easymeals_core_register_vertical_mobile_header_layout( $mobile_header_layouts ) {
		$mobile_header_layout = array(
			'vertical' => 'VerticalMobileHeader'
		);

		$mobile_header_layouts = array_merge( $mobile_header_layouts, $mobile_header_layout );

		return $mobile_header_layouts;
	}

	add_filter( 'easymeals_core_filter_register_mobile_header_layouts', 'easymeals_core_register_vertical_mobile_header_layout');
}