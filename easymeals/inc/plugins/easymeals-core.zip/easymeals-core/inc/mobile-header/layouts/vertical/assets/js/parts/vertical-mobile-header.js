(function ($) {
	"use strict";
	
	$(document).ready(function () {
		qodefMobileHeaderAppearance.init();
	});
	
	/*
	 **	Init mobile header functionality
	 */
	var qodefMobileHeaderAppearance = {
		init: function () {
			if (qodef.body.hasClass('qodef-mobile-header--vertical')) {
				
				var navigationOpener = $('#qodef-page-mobile-header .qodef-mobile-vertical-menu-opener, .qodef-close-mobile-side-area-holder'),
					navigationHolder = $('#qodef-page-mobile-header .qodef-mobile-side-area'),
					dropdownOpener = $('#qodef-vertical-mobile-header-navigation .qodef-menu-arrow'),
					animationSpeed = 200;
				
				//whole mobile menu opening / closing
				if (navigationOpener.length && navigationHolder.length) {
					navigationOpener.on('tap click', function (e) {
						e.stopPropagation();
						e.preventDefault();
						
						if (navigationHolder.hasClass('opened')) {
							navigationHolder.removeClass('opened');
							
						} else {
							navigationHolder.addClass('opened');
						}
					});
				}
				
				//dropdown opening / closing
				if (dropdownOpener.length) {
					dropdownOpener.each(function () {
						var $thisItem = $(this);
						
						$thisItem.on('tap click', function (e) {
							var $thisItemParent = $thisItem.parent(),
								$thisItemParentSiblingsWithDrop = $thisItemParent.siblings('.menu-item-has-children');
							
							if ($thisItemParent.hasClass('menu-item-has-children')) {
								var $submenu = $thisItemParent.find('ul.sub-menu').first();
								
								if ($submenu.is(':visible')) {
									$submenu.slideUp(animationSpeed);
									$thisItemParent.removeClass('qodef--opened');
								} else {
									$thisItemParent.addClass('qodef--opened');
									
									if ($thisItemParentSiblingsWithDrop.length === 0) {
										$thisItemParent.find('.sub-menu').slideUp(animationSpeed, function () {
											$submenu.slideDown(animationSpeed);
										});
									} else {
										$thisItemParent.siblings().removeClass('qodef--opened').find('.sub-menu').slideUp(animationSpeed, function () {
											$submenu.slideDown(animationSpeed);
										});
									}
								}
							}
							
						});
					});
				}
				
				// close menu on link/logo click
				$('#qodef-vertical-mobile-header-navigation a, .qodef-mobile-header-logo-link').on('click tap', function (e) {
					if (($(this).attr('href') !== 'http://#' && $(this).attr('href') !== '#') && !($(this).parent().hasClass("menu-item-has-children"))) {
						navigationHolder.removeClass('opened');
					}
				});
				
				qodefMobileHeaderAppearance.initMobileNavigationScroll();
				qodefMobileHeaderAppearance.mobileHeaderBehavior();
				
				$(window).resize(function () {
					qodefMobileHeaderAppearance.initMobileNavigationScroll();
				});
			}
		},
		initMobileNavigationScroll: function() {
			if (qodef.windowWidth <= 1024) {
				var mobileHeader = $('#qodef-page-mobile-header'),
					mobileHeaderHeight = mobileHeader.length ? mobileHeader.height() : 0,
					navigationHolder = mobileHeader.find('.qodef-mobile-side-area-inner'),
					navigationHeight = navigationHolder.outerHeight(),
					windowHeight = qodef.windowHeight - 100;
				
				//init scrollable menu
				var scrollHeight = mobileHeaderHeight + navigationHeight > windowHeight ? windowHeight - mobileHeaderHeight : navigationHeight;
				
				// in case if mobile header exists on specific page
				if(navigationHolder.length && typeof qodefCore.qodefPerfectScrollbar === 'object') {
					navigationHolder.height(scrollHeight);
					qodefCore.qodefPerfectScrollbar.init(navigationHolder);
                }
			}
		},
		mobileHeaderBehavior: function() {
			var mobileHeader = $('#qodef-page-mobile-header'),
				mobileHeaderHeight = mobileHeader.length ? mobileHeader.outerHeight() : 0;
			
			if (qodef.body.hasClass('qodef-content-behind-header') && mobileHeaderHeight > 0 && qodef.windowWidth <= 1024) {
				$('#qodef-page-outer').css('marginTop', -mobileHeaderHeight);
			}
		}
	};
	
})(jQuery);