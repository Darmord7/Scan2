<a class="qodef-mobile-vertical-menu-opener" href="javascript:void(0)">
	<?php echo qode_framework_icons()->render_icon( 'lnr-menu', 'linear-icons' ); ?>
</a>