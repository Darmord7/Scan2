<?php

include_once EASYMEALS_CORE_INC_PATH . '/header/layouts/centered-reverse/helper.php';
include_once EASYMEALS_CORE_INC_PATH . '/header/layouts/centered-reverse/centered-reverse-header.php';
include_once EASYMEALS_CORE_INC_PATH . '/header/layouts/centered-reverse/dashboard/admin/centered-reverse-header-options.php';
include_once EASYMEALS_CORE_INC_PATH . '/header/layouts/centered-reverse/dashboard/meta/centered-reverse-header-meta.php';