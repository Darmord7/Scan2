<?php

if ( ! function_exists( 'easymeals_core_include_blog_single_post_navigation_template' ) ) {
	/**
	 * Function which includes additional module on single posts page
	 */
	function easymeals_core_include_blog_single_post_navigation_template() {
		if ( is_single() ) {
			include_once EASYMEALS_CORE_INC_PATH . '/blog/templates/single/single-post-navigation/templates/single-post-navigation.php';
		}
	}
	
	add_action( 'easymeals_action_after_blog_post_item', 'easymeals_core_include_blog_single_post_navigation_template', 20 ); // permission 20 is set to define template position
}