<?php

include_once EASYMEALS_CORE_INC_PATH . '/blog/shortcodes/blog-list/variations/minimal/minimal.php';