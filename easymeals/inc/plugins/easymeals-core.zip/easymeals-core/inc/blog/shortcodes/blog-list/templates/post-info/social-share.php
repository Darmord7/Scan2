<?php if ( class_exists( 'EasyMealsCoreSocialShareShortcode' ) ) { ?>
	<div class="qodef-e-info-item qodef-e-info-social-share">
		<?php
		$params = array();
		$params['title'] = esc_html__( 'Share:', 'easymeals-core' );
		
		echo EasyMealsCoreSocialShareShortcode::call_shortcode( $params ); ?>
	</div>
<?php } ?>