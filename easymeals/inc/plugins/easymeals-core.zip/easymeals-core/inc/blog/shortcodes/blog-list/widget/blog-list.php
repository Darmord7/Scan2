<?php

if ( ! function_exists( 'easymeals_core_add_blog_list_widget' ) ) {
	/**
	 * Function that add widget into widgets list for registration
	 *
	 * @param array $widgets
	 *
	 * @return array
	 */
	function easymeals_core_add_blog_list_widget( $widgets ) {
		$widgets[] = 'EasyMealsCoreBlogListWidget';
		
		return $widgets;
	}
	
	add_filter( 'easymeals_core_filter_register_widgets', 'easymeals_core_add_blog_list_widget' );
}

if ( class_exists( 'QodeFrameworkWidget' ) ) {
	class EasyMealsCoreBlogListWidget extends QodeFrameworkWidget {
		
		public function map_widget() {
			$this->set_widget_option(
				array(
					'field_type' => 'text',
					'name'       => 'widget_title',
					'title'      => esc_html__( 'Title', 'easymeals-core' )
				)
			);
			$widget_mapped = $this->import_shortcode_options( array(
				'shortcode_base' => 'easymeals_core_blog_list'
			) );
			
			if ( $widget_mapped ) {
				$this->set_base( 'easymeals_core_blog_list' );
				$this->set_name( esc_html__( 'EasyMeals Blog List', 'easymeals-core' ) );
				$this->set_description( esc_html__( 'Display a list of blog posts', 'easymeals-core' ) );
			}
		}
		
		public function render( $atts ) {
			$params = $this->generate_string_params( $atts );
			
			echo do_shortcode( "[easymeals_core_blog_list $params]" ); // XSS OK
		}
	}
}
