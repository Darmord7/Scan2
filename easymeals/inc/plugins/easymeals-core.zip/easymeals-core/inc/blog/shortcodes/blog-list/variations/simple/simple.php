<?php

if ( ! function_exists( 'easymeals_core_add_blog_list_variation_simple' ) ) {
	function easymeals_core_add_blog_list_variation_simple( $variations ) {
		$variations['simple'] = esc_html__( 'Simple', 'easymeals-core' );
		
		return $variations;
	}
	
	add_filter( 'easymeals_core_filter_blog_list_layouts', 'easymeals_core_add_blog_list_variation_simple' );
}