<?php

if ( ! function_exists( 'easymeals_core_add_blog_list_variation_minimal' ) ) {
	function easymeals_core_add_blog_list_variation_minimal( $variations ) {
		$variations['minimal'] = esc_html__( 'Minimal', 'easymeals-core' );
		
		return $variations;
	}
	
	add_filter( 'easymeals_core_filter_blog_list_layouts', 'easymeals_core_add_blog_list_variation_minimal' );
}