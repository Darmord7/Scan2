<?php

if ( ! function_exists( 'easymeals_core_add_content_bottom_options' ) ) {
	/**
	 * Function that add general options for this module
	 */
	function easymeals_core_add_content_bottom_options() {
		$qode_framework = qode_framework_get_framework_root();

		$page = $qode_framework->add_options_page(
			array(
				'scope'       => EASYMEALS_CORE_OPTIONS_NAME,
				'type'        => 'admin',
				'slug'        => 'content-bottom',
				'icon'        => 'fa fa-envelope',
				'title'       => esc_html__( 'Content Bottom', 'easymeals-core' ),
				'description' => esc_html__( 'Global Content Bottom Options', 'easymeals-core' )
			)
		);

		if ( $page ) {

			$page->add_field_element(
				array(
					'field_type'    => 'yesno',
					'name'          => 'qodef_enable_content_bottom_area',
					'title'         => esc_html__( 'Enable Content Bottom', 'easymeals-core' ),
					'description'   => esc_html__( 'Use this option to enable/disable content bottom area', 'easymeals-core' ),
					'default_value' => 'no'
				)
			);

			$page_content_bottom_section = $page->add_section_element(
				array(
					'name'       => 'qodef_page_content_bottom_section',
					'title'      => esc_html__( 'Content Bottom', 'easymeals-core' ),
					'dependency' => array(
						'hide' => array(
							'qodef_enable_content_bottom_area' => array(
								'values'        => 'no',
								'default_value' => ''
							)
						)
					)
				)
			);

			$custom_sidebars = easymeals_core_get_custom_sidebars();


			if ( ! empty( $custom_sidebars ) && count( $custom_sidebars ) > 1 ) {
				$page_content_bottom_section->add_field_element(
					array(
						'field_type'    => 'select',
						'name'          => 'qodef_content_bottom_sidebar_custom_display',
						'title'         => esc_html__( 'Custom Sidebar', 'easymeals-core' ),
						'description'   => esc_html__( 'Choose a custom sidebar to display for content bottom', 'easymeals-core' ),
						'options'       => $custom_sidebars
					)
				);
			}

			$page_content_bottom_section->add_field_element(
				array(
					'field_type'    => 'yesno',
					'name'          => 'qodef_content_bottom_in_grid',
					'title'         => esc_html__( 'Content Bottom In Grid', 'easymeals-core' ),
					'description'   => esc_html__( 'Enabling this option will set page content bottom area to be in grid', 'easymeals-core' ),
					'default_value' => 'yes'
				)
			);
		}
	}

	add_action( 'easymeals_core_action_default_options_init', 'easymeals_core_add_content_bottom_options', easymeals_core_get_admin_options_map_position( 'content-bottom' ) );
}