<?php

include_once EASYMEALS_CORE_INC_PATH . '/icons/linear-icons/linear-icons.php';