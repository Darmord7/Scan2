<?php

include_once EASYMEALS_CORE_INC_PATH . '/icons/dripicons/dripicons.php';