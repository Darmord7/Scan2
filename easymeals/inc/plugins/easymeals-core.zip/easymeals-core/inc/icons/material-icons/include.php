<?php

include_once EASYMEALS_CORE_INC_PATH . '/icons/material-icons/material-icons.php';