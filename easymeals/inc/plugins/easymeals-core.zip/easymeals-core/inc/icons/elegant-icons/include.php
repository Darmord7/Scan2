<?php

include_once EASYMEALS_CORE_INC_PATH . '/icons/elegant-icons/elegant-icons.php';