<?php

include_once EASYMEALS_CORE_INC_PATH . '/opener-icon/helper.php';