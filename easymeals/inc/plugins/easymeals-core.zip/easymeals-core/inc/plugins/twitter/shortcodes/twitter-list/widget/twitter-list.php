<?php

if ( ! function_exists( 'easymeals_core_add_twitter_list_widget' ) ) {
	/**
	 * Function that add widget into widgets list for registration
	 *
	 * @param array $widgets
	 *
	 * @return array
	 */
	function easymeals_core_add_twitter_list_widget( $widgets ) {
		if( qode_framework_is_installed( 'twitter' ) ) {
			$widgets[] = 'EasyMealsCoreTwitterListWidget';
		}
		
		return $widgets;
	}
	
	add_filter( 'easymeals_core_filter_register_widgets', 'easymeals_core_add_twitter_list_widget' );
}

if ( class_exists( 'QodeFrameworkWidget' ) ) {
	class EasyMealsCoreTwitterListWidget extends QodeFrameworkWidget {
		
		public function map_widget() {
			$this->set_widget_option(
				array(
					'name'       => 'widget_title',
					'field_type' => 'text',
					'title'      => esc_html__( 'Title', 'easymeals-core' )
				)
			);
			$widget_mapped = $this->import_shortcode_options( array(
				'shortcode_base' => 'easymeals_core_twitter_list'
			) );
			if( $widget_mapped ) {
				$this->set_base( 'easymeals_core_twitter_list' );
				$this->set_name( esc_html__( 'EasyMeals Twitter List', 'easymeals-core' ) );
				$this->set_description( esc_html__( 'Add a twitter list element into widget areas', 'easymeals-core' ) );
			}
		}
		
		public function render( $atts ) {
			$params = $this->generate_string_params( $atts );
			
			echo do_shortcode( "[easymeals_core_twitter_list $params]" ); // XSS OK
		}
	}
}
