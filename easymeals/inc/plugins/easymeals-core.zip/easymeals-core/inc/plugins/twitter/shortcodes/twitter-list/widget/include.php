<?php

include_once EASYMEALS_CORE_PLUGINS_PATH . '/twitter/shortcodes/twitter-list/widget/twitter-list.php';