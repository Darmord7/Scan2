<?php

if(!function_exists('easymeals_core_bbpress_sidebar')) {
	/**
	 * Function that hooks to sidebar filter and changes it to option set for bbpress sidebar
	 * @param $sidebar
	 *
	 * @return bool|void
	 */
	function easymeals_core_bbpress_sidebar($sidebar) {
		if(qode_framework_is_installed( 'bbpress' ) &&  is_bbpress() && !bbp_is_single_user_profile() && !bbp_is_topics_created() && !bbp_is_replies_created() && !bbp_is_favorites() && !bbp_is_single_user()) {
			$sidebar_option = easymeals_get_post_value_through_levels('qodef_bbpress_custom_sidebar');

			if($sidebar_option !== '') {
				$sidebar = $sidebar_option;
			}
		}

		return $sidebar;
	}

	add_filter('easymeals_filter_sidebar_name', 'easymeals_core_bbpress_sidebar');
}

if(!function_exists('easymeals_core_bbpress_sidebar_layout')) {
	/**
	 * Function that hooks to sidebar layout filter and changes it to option set for bbpress sidebar layout
	 * @param $layout
	 *
	 * @return bool|void
	 */
	function easymeals_core_bbpress_sidebar_layout($layout) {


		if(qode_framework_is_installed( 'bbpress' ) && is_bbpress() && !bbp_is_single_user_profile() && !bbp_is_topics_created() && !bbp_is_replies_created() && !bbp_is_favorites() && !bbp_is_single_user() ) {


			$layout_option = easymeals_get_post_value_through_levels('qodef_bbpress_sidebar_layout');

			if($layout_option !== '') {
				$layout = $layout_option;
			}
		}

		return $layout;
	}

	add_filter('easymeals_filter_sidebar_layout', 'easymeals_core_bbpress_sidebar_layout');
}

if ( ! function_exists( 'easymeals_core_set_bbpress_sidebar_grid_gutter_classes' ) ) {
	/**
	 * Function that returns grid gutter classes
	 *
	 * @param string $classes
	 *
	 * @return string
	 */
	function easymeals_core_set_bbpress_sidebar_grid_gutter_classes( $classes ) {

		$option = easymeals_core_get_post_value_through_levels( 'qodef_bbpress_sidebar_grid_gutter' );
		if ( isset( $option ) && ! empty( $option ) ) {
			$classes = 'qodef-gutter--' . esc_attr( $option );
		}

		return $classes;
	}

	add_filter('easymeals_filter_grid_gutter_classes', 'easymeals_core_set_bbpress_sidebar_grid_gutter_classes');
}