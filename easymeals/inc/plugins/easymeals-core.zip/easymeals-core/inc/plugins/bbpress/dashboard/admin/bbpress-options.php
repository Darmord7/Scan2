<?php

if ( ! function_exists( 'easymeals_core_add_bbpress_options' ) ) {
	/**
	 * Function that add general options for this module
	 */
	function easymeals_core_add_bbpress_options() {
		$qode_framework = qode_framework_get_framework_root();

		$page = $qode_framework->add_options_page(
			array(
				'scope'       => EASYMEALS_CORE_OPTIONS_NAME,
				'type'        => 'admin',
				'slug'        => 'bbpress',
				'icon'        => 'fa fa-book',
				'title'       => esc_html__( 'BBPress', 'easymeals-core' ),
				'description' => esc_html__( 'Global BBPress Options', 'easymeals-core' ),
			)
		);

		if ( $page ) {

			$page->add_field_element(
				array(
					'field_type'    => 'select',
					'name'          => 'qodef_bbpress_sidebar_layout',
					'title'         => esc_html__( 'Sidebar Layout', 'easymeals-core' ),
					'description'   => esc_html__( 'Choose default sidebar layout for bbpress pages', 'easymeals-core' ),
					'default_value' => 'no-sidebar',
					'options'       => easymeals_core_get_select_type_options_pool( 'sidebar_layouts', false )
				)
			);

			$custom_sidebars = easymeals_core_get_custom_sidebars();
			if ( ! empty( $custom_sidebars ) && count( $custom_sidebars ) > 1 ) {
				$page->add_field_element(
					array(
						'field_type'  => 'select',
						'name'        => 'qodef_bbpress_custom_sidebar',
						'title'       => esc_html__( 'Custom Sidebar', 'easymeals-core' ),
						'description' => esc_html__( 'Choose a custom sidebar to display on bbpress pages', 'easymeals-core' ),
						'options'     => $custom_sidebars
					)
				);
			}

			$page->add_field_element(
				array(
					'field_type'  => 'select',
					'name'        => 'qodef_bbpress_sidebar_grid_gutter',
					'title'       => esc_html__( 'Set Grid Gutter', 'easymeals-core' ),
					'description' => esc_html__( 'Choose grid gutter size to set space between content and sidebar', 'easymeals-core' ),
					'options'     => easymeals_core_get_select_type_options_pool( 'items_space' )
				)
			);
		}
	}

	add_action( 'easymeals_core_action_default_options_init', 'easymeals_core_add_bbpress_options', easymeals_core_get_admin_options_map_position( 'bbpress' ) );
}