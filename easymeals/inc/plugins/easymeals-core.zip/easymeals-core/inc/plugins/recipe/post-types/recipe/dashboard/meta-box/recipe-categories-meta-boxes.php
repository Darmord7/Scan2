<?php

if ( ! function_exists( 'easymeals_core_add_recipe_category_options' ) ) {
	function easymeals_core_add_recipe_category_options() {
		$qode_framework = qode_framework_get_framework_root();
		
		$page = $qode_framework->add_options_page(
			array(
				'scope' => array( 'recipe-category' ),
				'type'  => 'taxonomy',
				'slug'  => 'recipe-category',
			)
		);
		
		if ( $page ) {
			$page->add_field_element(
				array(
					'field_type'  => 'image',
					'name'        => 'qodef_recipe_category_image',
					'title'       => esc_html__( 'Category Image', 'easymeals-core' ),
				)
			);
		}
	}
	
	add_action( 'easymeals_core_action_register_cpt_tax_fields', 'easymeals_core_add_recipe_category_options' );
}