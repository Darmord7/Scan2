<div class="qodef-e-section qodef-e-section--buttons">
	<div class="qodef-e-section-inner">
        <div class="qodef-e-buttons">
            <?php
                // Get search button
                echo EasyMealsCoreButtonShortcode::call_shortcode( array(
                    'custom_class' => 'qodef-e-filter--search',
                    'text'         => esc_html__( 'Filter Results', 'easymeals-core' )
                ) );
            ?>
        </div>
        <span class="qodef-filter-query-results"></span>
	</div>
</div>