<?php
$tags = wp_get_post_terms( get_the_ID(), 'recipe-tag' );

if ( is_array( $tags ) && count( $tags ) ) { ?>
	<div class="qodef-e qodef-info--tags">
		<div class="qodef-e-tags">
			<span class="qodef-icon-linear-icons lnr-pushpin lnr qodef-icon qodef-e"></span>
			<span class="qodef-m-label"><?php esc_html_e('Tags','easymeals-core'); ?></span>
			<div class="qodef-m-tags-wrapper">
				<?php foreach ( $tags as $tag ) { ?>
					<a itemprop="url" class="qodef-e-tag" href="<?php echo esc_url( get_term_link( $tag->term_id ) ); ?>">
						<?php echo esc_html( $tag->name ); ?>
					</a>
				<?php } ?>
			</div>
		</div>
	</div>
<?php }
