<?php

get_header();

// Include cpt content template
easymeals_core_template_part( 'plugins/recipe/post-types/recipe', 'templates/content' );

get_footer();