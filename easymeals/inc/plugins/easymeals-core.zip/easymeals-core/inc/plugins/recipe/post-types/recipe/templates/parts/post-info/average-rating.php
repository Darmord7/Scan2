<?php echo easymeals_core_list_review_details( 'average-count' ); ?>
