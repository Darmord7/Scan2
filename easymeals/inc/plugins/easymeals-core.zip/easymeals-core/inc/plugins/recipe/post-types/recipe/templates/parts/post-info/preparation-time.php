<?php
$preparation_time = get_post_meta( get_the_ID(), 'qodef_recipe_preparation_time', true);

if( ! empty( $preparation_time ) ) { ?>
	<p class="qodef-recipe-prep-time">
		<span class="qodef-icon-linea-icons icon-basic-clock qodef-icon qodef-e"></span>
		<?php echo esc_html( $preparation_time ); ?>
	</p>
<?php }