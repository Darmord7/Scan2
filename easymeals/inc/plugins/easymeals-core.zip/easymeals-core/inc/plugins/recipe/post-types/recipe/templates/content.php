<?php
// Hook to include additional content before page content holder
do_action( 'easymeals_core_action_before_recipe_content_holder' );
?>
	<main id="qodef-page-content" class="qodef-grid qodef-layout--template <?php echo esc_attr( easymeals_core_get_grid_gutter_classes() ); ?>">
		<div class="qodef-grid-inner clear">
			<?php
			// Include team template
			$content = isset( $content ) ? $content : '';
			easymeals_core_template_part( 'plugins/recipe/post-types/recipe', 'templates/recipe', $content );
			
			// Include page content sidebar
			easymeals_core_theme_template_part( 'sidebar', 'templates/sidebar' );
			?>
		</div>
	</main>
<?php
// Hook to include additional content after main page content holder
do_action( 'easymeals_core_action_after_recipe_content_holder' );
?>