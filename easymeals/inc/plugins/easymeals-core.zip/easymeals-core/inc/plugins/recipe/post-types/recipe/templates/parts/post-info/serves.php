<?php
$serves = get_post_meta( get_the_ID(), 'qodef_recipe_servings_number', true);

if( ! empty( $serves ) ) { ?>
	<p class="qodef-recipe-serves">
		<span class="qodef-icon-linear-icons lnr-dinner lnr qodef-icon qodef-e"></span>
		<?php echo esc_html( $serves ); ?>
	</p>
<?php }