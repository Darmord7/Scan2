<article <?php qode_framework_class_attribute( $item_classes ); ?>>
	<div class="qodef-e-inner">
		<?php easymeals_core_template_part( 'plugins/recipe/post-types/recipe/shortcodes/recipe-category-list', 'templates/parts/image', '', $params ); ?>
		<div class="qodef-e-content">
			<?php easymeals_core_template_part( 'plugins/recipe/post-types/recipe/shortcodes/recipe-category-list', 'templates/parts/title', '', $params ); ?>
		</div>
		<?php easymeals_core_template_part( 'plugins/recipe/post-types/recipe/shortcodes/recipe-category-list', 'templates/parts/link', '', $params ); ?>
	</div>
</article>