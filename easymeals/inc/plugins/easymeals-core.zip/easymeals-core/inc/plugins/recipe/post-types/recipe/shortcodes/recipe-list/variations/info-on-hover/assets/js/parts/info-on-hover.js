(function($) {
	'use strict';

	$(window).on('load', function () {
		qodefRecipeInfoOnHover.init();
	});

	$(document).on('easymeals_trigger_swiper_is_initialized', function () {
		qodefRecipeInfoOnHover.init();
	});
	
	var qodefRecipeInfoOnHover = {
		init: function () {
			this.holder = $('.qodef-recipe-list.qodef-item-layout--info-on-hover');

			if (this.holder.length) {
				this.holder.each(function () {
					var $thisHolder = $(this),
						$imagesHolder = $thisHolder.find('.qodef-e-image');
					qodefRecipeInfoOnHover.setPositions( $thisHolder );
					qodefRecipeInfoOnHover.mouseEnter($thisHolder, $imagesHolder);
				});
			}
		},
		setPositions: function ($holder) {
			var $items = $holder.find('article');
			$items.each(function () {
				var $item = $(this),
					$itemInner = $item.find('.qodef-e-content'),
					$itemInfoTopHeight = $item.find('.qodef-e-info-top').length ? $item.find('.qodef-e-info-top').outerHeight() : 0,
					$itemTitleHeight = $item.find('.qodef-e-title').length ? $item.find('.qodef-e-title').outerHeight() : 0,
					$totalHeight = $itemInfoTopHeight + $itemTitleHeight + 35;

				$itemInner.css({'top': 'calc(100% - '+$totalHeight+'px)', 'opacity': '1' });
			});
		},
		mouseEnter: function ($holder) {
			var $items = $holder.find('article');
			
			$items.on("mouseenter", function () {
				var $contentHeight = $(this).find('.qodef-e-content').outerHeight() - 35,
					$itemWrapper = $(this).find('.qodef-content-holder'),
					$itemInfoTopHeight = $(this).find('.qodef-e-info-top').length ? $(this).find('.qodef-e-info-top').outerHeight() : 0,
					$itemTitleHeight = $(this).find('.qodef-e-title').outerHeight(),
					$totalTranslate = $contentHeight - $itemInfoTopHeight - $itemTitleHeight;
				$items.find('.qodef-e-content').css('transform', 'translateY(0)');
				$(this).find('.qodef-e-content').css('transform', 'translateY(-'+$totalTranslate+'px)');
				$itemWrapper.css('height', '100%');
			});

			$items.on("mouseleave", function () {
				$(this).find('.qodef-e-content').css('transform', 'translateY(0)');
			});
		}
	};

	qodefCore.shortcodes.easymeals_core_recipe_list.qodefRecipeInfoOnHover = qodefRecipeInfoOnHover;
	
})(jQuery);
