<?php

if ( ! function_exists( 'easymeals_core_include_recipe_single_post_navigation_template' ) ) {
	/**
	 * Function which includes additional module on single portfolio page
	 */
	function easymeals_core_include_recipe_single_post_navigation_template() {
		easymeals_core_template_part( 'plugins/recipe/post-types/recipe', 'templates/single/single-navigation/templates/single-navigation' );
	}
	
	add_action( 'easymeals_core_action_after_recipe_single_item', 'easymeals_core_include_recipe_single_post_navigation_template' );
}