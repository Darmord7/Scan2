<?php

include_once EASYMEALS_CORE_PLUGINS_PATH.'/recipe/helper.php';

foreach ( glob( EASYMEALS_CORE_PLUGINS_PATH . '/recipe/*/include.php' ) as $module ) {
	include_once $module;
}