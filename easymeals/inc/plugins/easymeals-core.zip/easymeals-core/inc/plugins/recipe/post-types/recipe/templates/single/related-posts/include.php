<?php

include_once EASYMEALS_CORE_PLUGINS_PATH . '/recipe/post-types/recipe/templates/single/related-posts/helper.php';
include_once EASYMEALS_CORE_PLUGINS_PATH . '/recipe/post-types/recipe/templates/single/related-posts/dashboard/admin/related-posts-options.php';