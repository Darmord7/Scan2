<div class="qodef-e-section-inner qodef-e-checkbox qodef-e-checkbox--<?php echo esc_attr( $filter_type ); ?>" data-type="<?php echo esc_attr( $filter_type ); ?>">
	<?php if ( ! empty( $default_label ) ) { ?>
		<h5 class="qodef-e-title"><?php echo esc_html( $default_label ); ?></h5>
	<?php } ?>
    <?php
    $last_element = end($terms);
    $last_element_index = array_search($last_element, array_keys($terms));
    $count_limit = $last_element_index != false && $last_element_index + 1 < 6 ? $last_element_index + 1 : 6;
    $count = count( $terms ) - $count_limit;

    $show_more_text = sprintf( '%s (%d)', esc_html__( 'Show more', 'easymeals-core' ),  $count );
    $show_less_text = esc_html__( 'Show less', 'easymeals-core' );
    ?>
	<div class="qodef-e-cb-items qodef-filter-show-more" data-count="<?php echo esc_attr( $count ); ?>" data-count-limit="<?php echo esc_attr( $count_limit ); ?>" data-show-more-text="<?php echo esc_attr( $show_more_text ); ?>" data-show-less-text="<?php echo esc_attr( $show_less_text ); ?>">
        <?php foreach ( $terms as $id => $name ) {
			$cb_id      = strtolower( str_replace( ' ', '-', $name ) ) . '-' . $id;
			$cb_values  = ! empty( $value ) ? explode( ',', $value ) : '';
			$real_value = '';

			if ( ! empty( $cb_values ) ) {
				foreach ( $cb_values as $cb_value ) {
					if ( intval( $cb_value ) === $id ) {
						$real_value = intval( $cb_value );
					}
				}
			}
			?>
			<div class="qodef-e-cb-item">
				<input type="checkbox" id="<?php echo esc_attr( $cb_id ); ?>" name="qodef-e--<?php echo esc_attr( $filter_type ); ?>[]" data-id="<?php echo esc_attr( $id ); ?>" value="" <?php checked( $real_value, $id ); ?> />
				<label for="<?php echo esc_attr( $cb_id ); ?>"><?php echo esc_html( $name ); ?></label>
			</div>
		<?php } ?>
		<?php //qode_framework_svg_icon( 'spinner', 'qodef-m-spinner' ); ?>
    </div>
</div>
