(function ($) {
	"use strict";
	
	var shortcode = 'easymeals_core_recipe_list_with_filter';
	
	qodefCore.shortcodes[shortcode] = {};

    $(window).on('load', function () {
        qodefRecipeListFilter.init();
    });

    $(document).on('easymeals_trigger_get_new_posts', function (e, $holder, response, nextPage) {
        qodefRecipeFilterReinit.init($holder, response, nextPage);
    });

    var qodefRecipeListFilter = {
        init: function () {
            var $holder = $('.qodef-recipe-list-with-filter .qodef-e-filter-holder');

            if ($holder.length) {
                $holder.each(function () {
                    var $thisHolder = $(this),
                        $thisListingList = $thisHolder.parents('.qodef-recipe-list-with-filter'),
                        $groups = $thisHolder.find('.qodef-e-section--category, .qodef-e-section--tag'),
                        $fields = [];
                    qodefRecipeListFilter.initGroupEffect($groups);

                    // Filter by attributes
                    $fields.$checkboxFields = $holder.find('.qodef-e-checkbox');
                    $fields.checkboxFieldsExists = $fields.$checkboxFields.length;
                    $fields.$inputTextFields = $holder.find('.qodef-e-text');
                    $fields.inputTextFieldsExists = $fields.$inputTextFields.length;


                    qodefRecipeListFilter.search($thisHolder, $thisListingList, $fields);
                });
            }
        },
        initGroupEffect: function (groups) {
            groups.each(function () {
                var thisGroup = $(this),
                    thisGroupList = thisGroup.find('.qodef-e-cb-items');
                if (thisGroupList.length) {
                    if (thisGroupList.hasClass('qodef-filter-show-more')) {
                        qodefRecipeListFilter.initShowMoreLess(thisGroupList);
                    } else if (thisGroupList.hasClass('qodef-filter-expand')) {
                        qodefRecipeListFilter.initShowDropdown(thisGroupList);
                    }
                }
            });
        },
        initShowMoreLess: function (filterList) {
            var showMoreText = filterList.data('show-more-text'),
                showLessText = filterList.data('show-less-text'),
                count = filterList.data('count'),
                countLimit = filterList.data('count-limit'),
                speed = (count / countLimit) * 200;
            speed = speed < 450 ? 450 : speed;
            if (count > 3) {
                var minHeight = countLimit * 26;
                /*26 li height*/
                filterList.showMore({
                    buttontxtmore: showMoreText,
                    buttontxtless: showLessText,
                    minheight: minHeight,
                    animationspeed: speed
                });
                if(qodef.windowWidth < 769) {
                    filterList.siblings('.showmore-button').slideUp(450);
                }
            }
        },
        initShowDropdown: function (filterList) {
            var dropdownOpeners = filterList.find('.qodef-tl-filter-opener');
            dropdownOpeners.on('click', '.qodef-opener-wrapper', function () {
                var $thisCategory = $(this).parent('.qodef-tl-filter-opener');
                var $thisCategoryDropdown = $thisCategory.next('.qodef-tl-filter-children');
                if ($thisCategoryDropdown.is(':visible')) {
                    $thisCategoryDropdown.slideUp(450, function () {
                        qodef.body.trigger("sticky_kit:recalc");
                    });
                    $thisCategory.removeClass('qodef-opened');
                } else {
                    $thisCategoryDropdown.slideDown(450, function () {
                        qodef.body.trigger("sticky_kit:recalc");
                    });
                    $thisCategory.addClass('qodef-opened');
                }


            });
        },
        search: function ($holder, $list, $fields) {
            var $searchButton = $holder.find('.qodef-e-filter--search');

                $searchButton.on('click', function(e){
                e.preventDefault();

                var options = $list.data('options'),
                    newOptions = {};

                    if ($fields.checkboxFieldsExists) {
                        $fields.$checkboxFields.each(function () {
                            var checkedCBItems = [];

                            $(this).find('input[type="checkbox"]:checked').each(function () {
                                checkedCBItems.push($(this).data('id'));
                            });

                            if (checkedCBItems.length) {
                                checkedCBItems = checkedCBItems.join(',');
                                newOptions[$(this).data('type')] = checkedCBItems;
                            } else {
                                newOptions[$(this).data('type')] = '';
                            }
                        });
                    }

                    if ($fields.inputTextFieldsExists) {
                        $fields.$inputTextFields.each(function () {
                            var inputTextValue = $(this).find('input[type="text"]').val();

                            if (inputTextValue !== "") {
                                newOptions[$(this).data('type')] = inputTextValue;
                            } else {
                                newOptions[$(this).data('type')] = '';
                            }
                        });
                    }

                    var additional = qodefRecipeListFilter.createAdditionalQuery(newOptions);

                    $.each(additional, function (key, value) {
                        options[key] = value;
                    });

                $list.data('options', options);

                qodef.body.trigger('easymeals_trigger_load_more', [$list, 1]);

            });
        },
        createAdditionalQuery: function (newOptions) {
            var addQuery = {};
            var i = 0;

            addQuery.additional_query_args = {};
            addQuery.additional_query_args.tax_query = [];

            if (typeof newOptions === 'object') {
                $.each(newOptions, function (key, value) {
                    switch (key) {
                        case 'category':
                        case 'tag':
                            if ( value !== '' ) {
                                if ( value.indexOf(',') !== -1 ) {
                                    value = value.split(',');
                                }
                                addQuery.additional_query_args.tax_query[i] = {};
                                addQuery.additional_query_args.tax_query[i].taxonomy = 'recipe-' + key;
                                addQuery.additional_query_args.tax_query[i].field = 'slug';
                                addQuery.additional_query_args.tax_query[i].terms = value;
                                i++;
                            }
                            break;
                        case 'custom_search':
                            addQuery.custom_search = value;
                            break;
                    }
                });

                if ( addQuery.additional_query_args.tax_query.length > 1 ) {
                    addQuery.additional_query_args.tax_query['relation'] = 'AND';
                }
            }

            return addQuery;
        }
    }

    qodefCore.shortcodes.easymeals_core_recipe_list_with_filter.qodefRecipeListFilter = qodefRecipeListFilter;

    var qodefRecipeFilterReinit = {
        init: function($holder, response, nextPage) {
            var options = $holder.data('options'),
                $paginationHolder = $holder.find('.qodef-m-pagination');

            if($holder.hasClass('qodef-recipe-list-with-filter')) {
                //if filter clicked - adjust pagination
                if (nextPage == 1) {
                    options.max_pages_num = response.max_num_pages;
                    $holder.data('options', options);

                    if ($paginationHolder.length) {
                        $paginationHolder.remove();
                    }

                    $holder.append(response.pagination_html);

                    qodef.qodefPagination.init();
                }
            }
        }
    }


    if (typeof qodefCore.listShortcodesScripts === 'object') {
		$.each(qodefCore.listShortcodesScripts, function (key, value) {
			qodefCore.shortcodes[shortcode][key] = value;
		});
	}
	
})(jQuery);
