<?php

if ( ! function_exists( 'easymeals_core_add_recipe_category_list_shortcode' ) ) {
	/**
	 * Function that add shortcode into shortcodes list for registration
	 *
	 * @param array $shortcodes
	 *
	 * @return array
	 */
	function easymeals_core_add_recipe_category_list_shortcode( $shortcodes ) {
		$shortcodes[] = 'EasyMealsCoreRecipeCategoryListShortcode';
		return $shortcodes;
	}
	
	add_filter( 'easymeals_core_filter_register_shortcodes', 'easymeals_core_add_recipe_category_list_shortcode' );
}

if ( class_exists( 'EasyMealsCoreListShortcode' ) ) {
	class EasyMealsCoreRecipeCategoryListShortcode extends EasyMealsCoreListShortcode {
	
		public function __construct() {
			$this->set_layouts( apply_filters( 'easymeals_core_filter_recipe_category_list_layouts', array() ) );
			parent::__construct();
		}
		
		public function map_shortcode() {
			$this->set_shortcode_path( EASYMEALS_CORE_PLUGINS_URL_PATH . '/recipe/post-types/recipe/shortcodes/recipe-category-list' );
			$this->set_base( 'easymeals_core_recipe_category_list' );
			$this->set_name( esc_html__( 'Recipe Category List', 'easymeals-core' ) );
			$this->set_description( esc_html__( 'Shortcode that display list of category items', 'easymeals-core' ) );
			$this->set_category( esc_html__( 'EasyMeals Core', 'easymeals-core' ) );
			$this->set_option( array(
				'field_type' => 'text',
				'name'       => 'custom_class',
				'title'      => esc_html__( 'Custom Class', 'easymeals-core' ),
			) );
			$this->map_list_options();
			$this->map_list_options( array(
                 'exclude_behavior' => array( 'masonry' ),
                 'exclude_option'   => array( 'images_proportion' ),
                 'group'            => esc_html__( 'Gallery Settings', 'easymeals-core' )
             ) );
			$this->set_option( array(
				'field_type' => 'select',
				'name'       => 'taxonomy',
				'title'      => esc_html__( 'Taxonomy', 'easymeals-core' ),
				'options'    => qode_framework_get_framework_root()->get_custom_post_type_taxonomies( 'recipe' ),
				'group'      => esc_html__( 'Query', 'easymeals-core' ),
			) );
			$this->map_query_options( array(
				'exclude_option' => array( 'additional_params' ),
			) );
			$this->set_option( array(
				'field_type' => 'select',
				'name'       => 'hide_empty',
				'title'      => esc_html__( 'Hide Empty', 'easymeals-core' ),
				'options'    => easymeals_core_get_select_type_options_pool( 'no_yes', false ),
				'group'      => esc_html__( 'Query', 'easymeals-core' ),
			) );
			$this->set_option( array(
				'field_type' => 'select',
				'name'       => 'additional_params',
				'title'      => esc_html__( 'Additional Params', 'easymeals-core' ),
				'options'    => array(
					''   => esc_html__( 'No', 'easymeals-core' ),
					'id' => esc_html__( 'Taxonomy IDs', 'easymeals-core' ),
				),
				'group'      => esc_html__( 'Query', 'easymeals-core' ),
			) );
			$this->set_option( array(
				'field_type'  => 'text',
				'name'        => 'taxonomy_ids',
				'title'       => esc_html__( 'Taxonomy IDs', 'easymeals-core' ),
				'description' => esc_html__( 'Separate taxonomy IDs with commas', 'easymeals-core' ),
				'group'       => esc_html__( 'Query', 'easymeals-core' ),
				'dependency'  => array(
					'show' => array(
						'additional_params' => array(
							'values'        => 'id',
							'default_value' => '',
						)
					),
				),
			) );
			$this->map_layout_options( array( 'layouts' => $this->get_layouts() ) );
		}
		
		public function render( $options, $content = null ) {
			parent::render( $options );
			
			$atts = $this->get_atts();
			
			$atts['taxonomy_items'] = get_terms( easymeals_core_get_custom_post_type_taxonomy_query_args( $atts ) );
			$atts['holder_classes'] = $this->get_holder_classes( $atts );
			$atts['slider_attr']    = $this->get_slider_data( $atts );
			
			$atts['this_shortcode'] = $this;
			
			return easymeals_core_get_template_part( 'plugins/recipe/post-types/recipe/shortcodes/recipe-category-list', 'templates/content', $atts['behavior'], $atts );
		}
		
		private function get_holder_classes( $atts ) {
			$holder_classes = $this->init_holder_classes();
			
			$holder_classes[] = 'qodef-recipe-category-list';
			$holder_classes[] = ! empty( $atts['layout'] ) ? 'qodef-layout--' . $atts['layout'] : '';
			
			$list_classes   = $this->get_list_classes( $atts );
			$holder_classes = array_merge( $holder_classes, $list_classes );
			
			return implode( ' ', $holder_classes );
		}
		
		public function get_item_classes( $atts ) {
			$item_classes = $this->init_item_classes();
			
			$list_item_classes = $this->get_list_item_classes( $atts );
			
			$item_classes = array_merge( $item_classes, $list_item_classes );
			
			return implode( ' ', $item_classes );
		}
		
		public function get_title_styles( $atts ) {
			$styles = array();
			
			if ( ! empty( $atts['text_transform'] ) ) {
				$styles[] = 'text-transform: ' . $atts['text_transform'];
			}
			
			return $styles;
		}
	}
}