<?php
$banner  = get_post_meta( get_the_ID(), 'qodef_recipe_single_banner', true );
$banner_link  = get_post_meta( get_the_ID(), 'qodef_recipe_single_banner_link', true );
if($banner !== '') { ?>
	<div class="qodef-m-recipe-banner">
		<a href="<?php echo esc_url( $banner_link ); ?>">
			<?php echo wp_get_attachment_image( $banner, 'full' );?>
		</a>
	</div>
<?php } ?>