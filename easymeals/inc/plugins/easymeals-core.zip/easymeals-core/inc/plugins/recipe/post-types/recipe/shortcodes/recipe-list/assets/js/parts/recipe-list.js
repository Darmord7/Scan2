(function ($) {
	"use strict";
	
	var shortcode = 'easymeals_core_recipe_list';
	
	qodefCore.shortcodes[shortcode] = {};
	
	if (typeof qodefCore.listShortcodesScripts === 'object') {
		$.each(qodefCore.listShortcodesScripts, function (key, value) {
			qodefCore.shortcodes[shortcode][key] = value;
		});
	}

	$(document).ready(function () {
		qodefRecipeList.init();
	});

	var qodefRecipeList = {
		init: function () {
			this.holder = $('.qodef-recipe-list');

			if (this.holder.length) {
				this.holder.each(function () {
					var $thisHolder = $(this);

					if ( $thisHolder.hasClass('qodef-hover-type--zoom') || $thisHolder.hasClass('qodef-hover-type--move') ) {
						qodefRecipeList.titleHover( $thisHolder );
					}
				});
			}
		},
		titleHover: function ( $thisHolder ) {
			var $item = $thisHolder.find('article');

			$item.each( function() {
				var $thisItem = $(this),
					$title = $thisItem.find('.qodef-e-title');

				$title.on('mouseenter', function() {
					$title.closest('article').addClass('qodef-active-hover');
				});

				$title.on('mouseleave', function() {
					$title.closest('article').removeClass('qodef-active-hover');
				})
			})
		}
	}

	qodefCore.shortcodes.easymeals_core_recipe_list.qodefRecipeList = qodefRecipeList;
	
})(jQuery);
