<div class="qodef-grid-item <?php echo esc_attr( easymeals_core_get_page_content_sidebar_classes() ); ?>">
	<div class="qodef-recipe qodef-m <?php echo esc_attr( easymeals_core_get_recipe_holder_classes() ); ?>">
		<?php
		// Include team posts loop
		easymeals_core_template_part( 'plugins/recipe/post-types/recipe', 'templates/parts/loop' );
		?>
	</div>
</div>