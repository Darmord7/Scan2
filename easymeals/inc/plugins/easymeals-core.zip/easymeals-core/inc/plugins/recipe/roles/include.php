<?php

include_once EASYMEALS_CORE_PLUGINS_PATH . '/recipe/roles/helper.php';

foreach ( glob( EASYMEALS_CORE_PLUGINS_PATH . '/recipe/roles/*/add-user-role.php' ) as $module ) {
	include_once $module;
}

foreach ( glob( EASYMEALS_CORE_PLUGINS_PATH . '/recipe/roles/*/remove-user-role.php' ) as $module ) {
	include_once $module;
}

foreach ( glob( EASYMEALS_CORE_PLUGINS_PATH . '/recipe/roles/*/include.php' ) as $module ) {
	include_once $module;
}

foreach ( glob( EASYMEALS_CORE_PLUGINS_PATH . '/recipe/roles/*/admin/*.php' ) as $module ) {
	include_once $module;
}