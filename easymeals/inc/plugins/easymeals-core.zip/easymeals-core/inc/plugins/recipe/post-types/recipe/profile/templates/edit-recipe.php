<?php

$recipe_get_id = $_GET['recipe_id'];
$recipe_db_id  = esc_attr( intval( $recipe_get_id ) );

//check if user is author of targeted item
if ( easymeals_core_recipe_check_is_users_item( $recipe_db_id ) ) {
    ?>
    <div class="qodef-recipe-profile-edit-recipe">
        <div class="qodef-lp-section-title">
            <h3 class="qodef-lp-st-title"><?php esc_html_e( 'Edit Recipe Item', 'easymeals-core' ); ?></h3>
            <p class="qodef-lp-st-text"><?php esc_html_e( 'Here you can edit every part of the recipe. Please note that fields marked with an asterisk (*) have to be filled before you can apply changes.', 'easymeals-core' ); ?></p>
        </div>
        <div>
            <div id="qodef-page" class="qodef-options-front-end">
                <?php easymeals_core_dashboard_add_edit_recipe_fields( easymeals_core_get_recipe_meta( $recipe_db_id ), 'edit', $recipe_db_id ); ?>
                <?php do_action( 'easymeals_membership_action_login_ajax_response' ); ?>
            </div>
        </div>
    </div>
<?php } else { ?>
    <h3 class="qodef-lp-st-title"><?php esc_html_e( 'Error', 'easymeals-core' ); ?></h3>
    <p><?php esc_html_e( 'You are not authorized to edit this item', 'easymeals-core' ); ?></p>
<?php } ?>