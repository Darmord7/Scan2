(function ($) {
	'use strict';

	$(document).ready(function () {
		qodefDeleteRecipeItemFromDashboard.init();
		qodefSavedSearchesRemove.init();
	});
	
	var qodefSavedSearchesRemove = {
		init: function() {
			var $searchesTab = $('.qodef-recipe-profile-searches');

			if ($searchesTab.length) {
				var $removeQueryButton = $searchesTab.find('.qodef-undo-query-save');

				$removeQueryButton.on('click', function (e) {
					e.preventDefault();

					var $thisButton = $(this);

					if (!confirm('Are you sure you want to remove this search?')) {
						return;
					}

					$thisButton.html('<span class="fa fa-spinner fa-spin" aria-hidden="true"></span>');

					$.ajax({
						type: 'POST',
						data: {
							'query_id' : $thisButton.data('query-id')
						},
						url: qodefGlobal.vars.restUrl + qodefGlobal.vars.recipeRemoveQueryRestRoute,
						beforeSend: function (request) {
							request.setRequestHeader('X-WP-Nonce', qodefGlobal.vars.restNonce);
						},
						success: function (response) {

							if (response.status === 'success') {
								$thisButton.parents('.qodef-lp-ss-content-row').remove();
							} else {
								$thisButton.html('<i class="fa fa-times" aria-hidden="true"></i>');
							}
						}
					});
				});
			}
		}
	};

	var qodefDeleteRecipeItemFromDashboard = {
		init: function () {
			var $button = $('.qodef-recipe-item-delete');

			if ($button.length) {
				$button.each(function () {
					var $thisDeleteButton = $(this),
						recipeId = $thisDeleteButton.data('recipe-id'),
						confirmText = $thisDeleteButton.data('confirm-text'),
						$recipe = $thisDeleteButton.parents('.qodef-lp-recipe-item');

					$thisDeleteButton.on('click', function (e) {
						e.preventDefault();

						var confirmDelete = confirm(confirmText);

						if (confirmDelete) {

							$.ajax({
								type: 'POST',
								data: {
									recipe_id: recipeId
								},
								url: qodefGlobal.vars.restUrl + qodefGlobal.vars.deleteRecipeRestRoute,
								beforeSend: function (request) {
									request.setRequestHeader('X-WP-Nonce', qodefGlobal.vars.restNonce);
								},
								success: function (response) {
									if (response.status === 'success') {
										$recipe.fadeOut(function () {
											$recipe.remove();
										});
									}
								}
							});
						}
					});
				});
			}
		}
	};
	
})(jQuery);