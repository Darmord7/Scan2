<?php

if ( ! function_exists( 'easymeals_core_add_recipe_profile_navigation_item' ) ) {
	function easymeals_core_add_recipe_profile_navigation_item( $items, $dashboard_url ) {
		$is_allowed = apply_filters( 'easymeals_core_filter_recipe_profile_navigation_item_visibility', true );

		if ( post_type_exists( 'recipe' ) && $is_allowed ) {
			$items['my-recipes'] = array(
				'url'         => esc_url( add_query_arg( array( 'user-action' => 'my-recipes' ), $dashboard_url ) ),
				'text'        => esc_html__( 'My Recipes', 'easymeals-core' ),
				'user_action' => 'my-recipes',
				'icon'        => '<span class="qodef-icon-linear-icons lnr-book lnr"></span>'
			);
			
			$add_recipe_url = esc_url( add_query_arg( array( 'user-action' => 'add-recipe' ), $dashboard_url ) );

			$items['add-recipe'] = array(
				'url'         => $add_recipe_url,
				'text'        => esc_html__( 'Add Recipe', 'easymeals-core' ),
				'user_action' => 'add-recipe',
				'icon'        => '<span class="qodef-icon-linear-icons lnr-file-add lnr"></span>'
			);
		}
		
		return $items;
	}
	
	add_filter( 'easymeals_membership_filter_dashboard_navigation_pages', 'easymeals_core_add_recipe_profile_navigation_item', 10, 2 );
}

if ( ! function_exists( 'easymeals_core_add_recipe_profile_navigation_pages' ) ) {
	function easymeals_core_add_recipe_profile_navigation_pages( $html, $action ) {
		$is_allowed = apply_filters( 'easymeals_core_filter_recipe_profile_navigation_item_visibility', true );

		if ( $is_allowed ) {
			switch ( $action ) {
				case 'edit-recipe':
					$html = easymeals_core_get_template_part( 'plugins/recipe/post-types/recipe/profile', 'templates/edit-recipe' );
					break;
				case 'add-recipe':
					$html				= easymeals_core_get_template_part( 'plugins/recipe/post-types/recipe/profile', 'templates/add-recipe', '' );
					break;
				case 'my-recipes':
					$list_params['recipe_items'] = qode_framework_get_cpt_items( 'recipe', array( 'post_status' => array( 'publish', 'pending', 'draft' ), 'author' => get_current_user_id() ) );
					$list_params['dashboard_url'] = easymeals_membership_get_dashboard_page_url();
					$html                         = easymeals_core_get_template_part( 'plugins/recipe/post-types/recipe/profile', 'templates/my-recipes', '', $list_params );
					break;
			}
		}

		return $html;
	}
	
	add_filter( 'easymeals_membership_filter_dashboard_page', 'easymeals_core_add_recipe_profile_navigation_pages', 10, 2 );
}

if ( ! function_exists( 'easymeals_core_get_recipe_items_ids' ) ) {
	function easymeals_core_get_recipe_items_ids() {
		$recipe_ids   = array();
		$recipe_items = qode_framework_get_cpt_items( 'recipe' );
		
		if ( ! empty( $recipe_items ) ) {
			foreach ( $recipe_items as $id => $title ) {
				$recipe_meta = get_post_meta( $id, 'qodef_recipe_single_ref_number', true );
				
				if ( ! empty( $recipe_meta ) ) {
					$recipe_ids[] = $recipe_meta;
				}
			}
		}
		
		return $recipe_ids;
	}
}

if ( ! function_exists( 'easymeals_core_add_rest_api_add_recipe_global_variables' ) ) {
	function easymeals_core_add_rest_api_add_recipe_global_variables( $global, $namespace ) {
		$global['addRecipeRestRoute']  = $namespace . '/add-recipe';
		$global['editRecipeRestRoute'] = $namespace . '/edit-recipe';

		return $global;
	}

	add_filter( 'qode_framework_filter_rest_api_global_variables', 'easymeals_core_add_rest_api_add_recipe_global_variables', 10, 2 );
}

if ( ! function_exists( 'easymeals_core_add_rest_api_recipe_global_route' ) ) {
	function easymeals_core_add_rest_api_recipe_global_route( $routes ) {
		$routes['add-recipe'] = array(
			'route'    => 'add-recipe',
			'methods'  => WP_REST_Server::CREATABLE,
			'callback' => 'easymeals_core_add_recipe',
			'permission_callback' => function () {
				return is_user_logged_in();
			},
			'args'     => array(
				'options' => array(
					'required'          => true,
					'validate_callback' => function ( $param, $request, $key ) {
						// Simple solution for validation can be 'is_array' value instead of callback function
						return is_array( $param ) ? $param : (array) $param;
					},
					'description'       => esc_html__( 'Options data is array with reaction and id values', 'easymeals-core' )
				)
			)
		);

		$routes['edit-recipe'] = array(
			'route'    => 'edit-recipe',
			'methods'  => WP_REST_Server::CREATABLE,
			'callback' => 'easymeals_core_edit_recipe',
			'permission_callback' => function () {
				return is_user_logged_in();
			},
			'args'     => array(
				'options' => array(
					'required'          => true,
					'validate_callback' => function ( $param, $request, $key ) {
						// Simple solution for validation can be 'is_array' value instead of callback function
						return is_array( $param ) ? $param : (array) $param;
					},
					'description'       => esc_html__( 'Options data is array with reaction and id values', 'easymeals-core' )
				)
			)
		);

		return $routes;
	}

	add_filter( 'qode_framework_filter_rest_api_routes', 'easymeals_core_add_rest_api_recipe_global_route' );
}

if ( ! function_exists( 'easymeals_core_add_rest_api_add_recipe_delete_global_variables' ) ) {
	function easymeals_core_add_rest_api_add_recipe_delete_global_variables( $global, $namespace ) {
		$global['deleteRecipeRestRoute'] = $namespace . '/delete-recipe';

		return $global;
	}

	add_filter( 'easymeals_filter_rest_api_global_variables', 'easymeals_core_add_rest_api_add_recipe_delete_global_variables', 10, 2 );
}

if ( ! function_exists( 'easymeals_core_add_rest_api_recipe_delete_global_route' ) ) {
	function easymeals_core_add_rest_api_recipe_delete_global_route( $routes ) {

		$routes['delete-recipe'] = array(
			'route'    => 'delete-recipe',
			'methods'  => WP_REST_Server::CREATABLE,
			'callback' => 'easymeals_core_delete_recipe',
			'permission_callback' => function () {
				return is_user_logged_in();
			},
			'args'     => array(
				'recipe_id' => array(
					'required'          => true,
					'validate_callback' => function ( $param, $request, $key ) {
						// Simple solution for validation can be 'is_int' value instead of callback function
						return is_int( $param ) ? $param : intval( $param );
					},
					'description'       => esc_html__( 'Id is int value', 'easymeals-core' )
				)
			)
		);

		return $routes;
	}

	add_filter( 'easymeals_filter_rest_api_routes', 'easymeals_core_add_rest_api_recipe_delete_global_route' );
}

if ( ! function_exists( 'easymeals_core_add_recipe' ) ) {
	function easymeals_core_add_recipe() {
		$user = wp_get_current_user();
		
		if ( ! isset( $_POST['options'] ) || empty( $_POST['options'] ) || ! is_user_logged_in() ) {
			qode_framework_get_ajax_status( 'error', esc_html__( 'You are not authorized.', 'easymeals-core' ) );
		} else {
			$dashboard_url = qode_framework_is_installed('membership') ? easymeals_membership_get_dashboard_page_url() : '#';

			parse_str( $_POST['options'], $new_recipe_data );

			$recipe_params               = array();
			$recipe_params['meta_input'] = array();
			$recipe_params['tax_input']  = array();


			//Check if recipe id already exists
			$recipe_ids = easymeals_core_get_recipe_items_ids();

			if ( in_array( intval( $new_recipe_data['qodef_recipe_single_ref_number_default'] ), $recipe_ids ) ) {
				qode_framework_get_ajax_status( 'error', esc_html__( 'Item Reference Number is taken, please try another.', 'easymeals-core' ) );
			} else {
				$recipe_params['meta_input']['qodef_recipe_single_ref_number'] = intval( $new_recipe_data['qodef_recipe_single_ref_number_default'] );
			}

			if ( empty( $new_recipe_data['qodef_recipe_title_default'] ) ) {
				qode_framework_get_ajax_status( 'error', esc_html__( 'Please enter item title.', 'easymeals-core' ) );
			}

			$recipe_params['post_type']    = 'recipe';
			$recipe_params['post_title']   = sanitize_text_field( $new_recipe_data['qodef_recipe_title_default'] );
			$recipe_params['post_content'] = sanitize_textarea_field( $new_recipe_data['qodef_recipe_description_default'] );
			$recipe_params['post_excerpt'] = sanitize_textarea_field( $new_recipe_data['qodef_recipe_excerpt_default'] );

			foreach ( $new_recipe_data as $key => $value ) {
				// Default values are core WP meta fields
				if ( strpos( $key, '_default' ) === false ) {

					if ( strpos( $key, '_taxonomy' ) !== false && ! empty( $value ) ) {
						$recipe_params['tax_input'][ str_replace( array( 'qodef_', '_taxonomy', '_' ), array( '', '', '-' ), $key ) ] = is_array( $value ) && count( $value ) ? sanitize_text_field( implode( ',', $value ) ) : sanitize_text_field( $value );
					} elseif ( strpos( $key, '_new_item' ) !== false && ! empty( $value ) ) {
						$taxonomy_id     = array();
						$taxonomy_name   = str_replace( array( 'qodef_', '_new_item', '_' ), array( '', '', '-' ), $key );
						$taxonomy_values = explode( ',', sanitize_text_field( $value ) );

						foreach ( $taxonomy_values as $taxonomy_value ) {
							$taxonomy_exist = term_exists( $taxonomy_value, $taxonomy_name );

							// Check is new taxonomy exist
							if ( empty( $taxonomy_exist ) ) {
								// Add new taxonomy value
								$add_taxonomy_value = wp_insert_term( $taxonomy_value, $taxonomy_name );

								if ( ! is_wp_error( $add_taxonomy_value ) ) {
									$taxonomy_id[] = $add_taxonomy_value['term_id'];
								} else {
									qode_framework_get_ajax_status( 'error', sprintf( esc_html__( '%s item can\'t be created.', 'easymeals-core' ), $taxonomy_value ) );
								}
							} else {
								qode_framework_get_ajax_status( 'error', sprintf( esc_html__( 'Please add unique name for %s, that name already exist.', 'easymeals-core' ), ucwords( str_replace( 'recipe-', '', $taxonomy_name ) ) ) );
							}
						}

						if ( ! empty( $taxonomy_id ) ) {
							$recipe_params['tax_input'][ $taxonomy_name ] = sanitize_text_field( implode( ',', $taxonomy_id ) );
						}
					} else {
						
						if ( $key == 'qodef_recipe_single_email' ) {
							$recipe_params['meta_input'][ $key ] = sanitize_email( $value );
							
						} elseif ( $key == 'qodef_recipe_single_site_url') {
							$recipe_params['meta_input'][ $key ] = esc_url_raw( $value );
							
						} elseif ( is_array( $value ) && count( $value ) ) {
							$sanitized_value = array();
							
							foreach ( $value as $single_value_array ) {
								$sanitized_value[] = array_map( 'sanitize_text_field', $single_value_array );
							}
							
							$recipe_params['meta_input'][ $key ] = $sanitized_value;
						} else {
							$recipe_params['meta_input'][$key] = sanitize_text_field( $value );
						}
					}
				}
			}
			
			$recipe_id = wp_insert_post( $recipe_params );

			if ( ! is_wp_error( $recipe_id ) ) {
				// Remove data from global post variable after submission
				unset( $_POST['options'] );

				set_post_thumbnail( $recipe_id, intval( $new_recipe_data['qodef_recipe_featured_image_default'] ) );

				qode_framework_get_ajax_status( 'success', esc_html__( 'Recipe is successfully added.', 'easymeals-core' ), null, $dashboard_url );
			} else {
				qode_framework_get_ajax_status( 'error', esc_html__( 'Error during recipe creating.', 'easymeals-core' ) );
			}
		}
	}
}

if ( ! function_exists( 'easymeals_core_get_recipe_meta' ) ) {
	function easymeals_core_get_recipe_meta( $recipe_id ) {
		$meta_values = array();
		
		if ( ! empty( $recipe_id ) ) {
			$id   = intval( $recipe_id );

			// Dynamically loop throw all core WordPress fields, because these fields are stored in the different table
			$wp_fields = array(
				'title'          => get_the_title( $id ),
				'featured_image' => get_post_thumbnail_id( $id ),
				'description'    => get_post_field( 'post_content', $id ),
				'excerpt'        => get_post_field( 'post_excerpt', $id )
			);
			
			foreach ( $wp_fields as $key => $value ) {
				$meta_values[ 'qodef_recipe_' . $key . '_default' ] = $value;
			}

			//get post meta for single fields that are needed separately
			$meta_arrays = array(
				'qodef_recipe_single_ref_number',
			);
			
			// Dynamically loop throw all meta options
			foreach ( $meta_arrays as $meta ) {
				$meta_values[$meta] = get_post_meta( $id, $meta, true);
			}
			
			// Dynamically loop throw all taxonomies, because these fields are stored in the different table
			$taxonomies = array(
				'category',
				'tag'
			);
			
			foreach ( $taxonomies as $taxonomy ) {
				$term_value = array();
				$terms      = get_the_terms( $id, 'recipe-' . $taxonomy );
				
				if ( ! empty( $terms ) ) {
					foreach ( $terms as $term ) {
						$term_value[ $term->slug ] = $term->term_id;
					}
				}
				
				// This condition is necessary because location is select field type and we need to return only taxonomy id
				if ( $taxonomy === 'location' ) {
					$meta_values[ 'qodef_recipe_' . $taxonomy . '_taxonomy' ] = intval( implode( '', $term_value ) );
				} else {
					$meta_values[ 'qodef_recipe_' . $taxonomy . '_taxonomy' ] = $term_value;
				}
			}
		}

		return $meta_values;
	}
}

if ( ! function_exists( 'easymeals_core_edit_recipe' ) ) {
	function easymeals_core_edit_recipe() {
		$user        = wp_get_current_user();
		
		if ( ! isset( $_POST['options'] ) || empty( $_POST['options'] ) || ! is_user_logged_in() ) {
			qode_framework_get_ajax_status( 'error', esc_html__( 'You are not authorized.', 'easymeals-core' ) );
		} else {

			parse_str( $_POST['options'], $new_recipe_data );

			$recipe_db_id = intval( $new_recipe_data['qodef_recipe_single_db_id'] );

			if ( ! easymeals_core_recipe_check_is_users_item( $recipe_db_id ) ) {
				qode_framework_get_ajax_status( 'error', esc_html__( 'You are not authorized.', 'easymeals-core' ) );
			}

			$dashboard_url = qode_framework_is_installed('membership') ? easymeals_membership_get_dashboard_page_url() : '#';

			$recipe_params               = array();
			$recipe_params['meta_input'] = array();
			$recipe_params['tax_input']  = array();

			//Check if recipe id already exists
			$recipe_ids        = easymeals_core_get_recipe_items_ids();
			$current_recipe_id = get_post_meta( $recipe_db_id, 'qodef_recipe_single_ref_number', true );
			$new_recipe_data['qodef_recipe_single_ref_number_default'] = intval( $new_recipe_data['qodef_recipe_single_ref_number_default'] );

			if ( $current_recipe_id != $new_recipe_data['qodef_recipe_single_ref_number_default'] ) {
				//Check if recipe id already exists
				if ( in_array( $new_recipe_data['qodef_recipe_single_ref_number_default'], $recipe_ids ) ) {
					qode_framework_get_ajax_status( 'error', esc_html__( 'Item Reference Number is taken, please try another.', 'easymeals-core' ) );
				} else {
					$recipe_params['meta_input']['qodef_recipe_single_ref_number'] = $new_recipe_data['qodef_recipe_single_ref_number_default'];
				}
			}

			if ( empty( $new_recipe_data['qodef_recipe_title_default'] ) ) {
				qode_framework_get_ajax_status( 'error', esc_html__( 'Please enter item title.', 'easymeals-core' ) );
			}

			foreach ( $new_recipe_data as $key => $value ) {
				// Default values are core WP meta fields
				if ( strpos( $key, '_default' ) === false ) {

					if ( strpos( $key, '_taxonomy' ) !== false && ! empty( $value ) ) {
						$recipe_params['tax_input'][ str_replace( array( 'qodef_', '_taxonomy', '_' ), array( '', '', '-' ), $key ) ] = is_array( $value ) && count( $value ) ? array_map( 'intval', $value ) : intval( $value );
					} else {
						if ( $key == 'qodef_recipe_single_email' ) {
							$recipe_params['meta_input'][ $key ] = sanitize_email( $value );
							
						} elseif ( $key == 'qodef_recipe_single_site_url') {
							$recipe_params['meta_input'][ $key ] = esc_url_raw( $value );
							
						} elseif ( is_array( $value ) && count( $value ) ) {
							$sanitized_value = array();
							
							foreach ( $value as $single_value_array ) {
								$sanitized_value[] = array_map( 'sanitize_text_field', $single_value_array );
							}
							
							$recipe_params['meta_input'][ $key ] = $sanitized_value;
						} else {
							$recipe_params['meta_input'][$key] = sanitize_text_field( $value );
						}
					}
				}
			}

			// Update featured image
			if ( ! empty( $new_recipe_data['qodef_recipe_featured_image_default'] ) ) {
				set_post_thumbnail( $recipe_db_id, intval( $new_recipe_data['qodef_recipe_featured_image_default'] ) );
			} else {
				delete_post_thumbnail( $recipe_db_id );
			}

			// Set core WordPress fields
			$this_recipe_args = array(
				'ID'           => $recipe_db_id,
				'post_title'   => sanitize_text_field( $new_recipe_data['qodef_recipe_title_default'] ),
				'post_content' => sanitize_textarea_field( $new_recipe_data['qodef_recipe_description_default'] ),
				'post_excerpt' => sanitize_textarea_field( $new_recipe_data['qodef_recipe_excerpt_default'] )
			);

			// Update meta fields
			foreach ( $recipe_params['meta_input'] as $key => $value ) {
				update_post_meta( $recipe_db_id, $key, $value );
			}

			// Update terms fields
			foreach ( $recipe_params['tax_input'] as $key => $value ) {
				wp_set_object_terms( $recipe_db_id, $value, $key );
			}

			// Update the recipe into the database
			$recipe_id_success = wp_update_post( $this_recipe_args );

			if ( ! is_wp_error( $recipe_id_success ) ) {
				// Remove data from global post variable after submission
				unset( $_POST['data'] );

				qode_framework_get_ajax_status( 'success', esc_html__( 'Recipe is successfully edited.', 'easymeals-core' ), null, $dashboard_url );
			} else {
				qode_framework_get_ajax_status( 'error', esc_html__( 'Error during Recipe saving.', 'easymeals-core' ) );
			}
		}
	}
}

if ( ! function_exists( 'easymeals_core_delete_recipe' ) ) {
	function easymeals_core_delete_recipe() {
		
		if ( ! isset( $_POST ) || empty( $_POST ) || ! is_user_logged_in() ) {
			qode_framework_get_ajax_status( 'error', esc_html__( 'You are not authorized.', 'easymeals-core' ) );
		} else {
			$recipe_id = intval( $_POST['recipe_id'] );
			$user       = wp_get_current_user();
			
			// Check is recipe item empty
			if ( empty( $recipe_id ) ) {
				qode_framework_get_ajax_status( 'error', esc_html__( 'Recipe ID is invalid.', 'easymeals-core' ) );
			}
			
			$deleted = wp_delete_post( $recipe_id );
			
			if ( $deleted ) {
				// Remove data from global post variable after submission
				unset( $_POST['recipe_id'] );
				
				qode_framework_get_ajax_status( 'success', esc_html__( 'Recipe is successfully deleted.', 'easymeals-core' ) );
			}
		}
	}
}

if ( ! function_exists( 'easymeals_core_recipe_add_edit_profile_set_front_id' ) ) {
	function easymeals_core_recipe_add_edit_profile_set_front_id( $id ) {
		if ( isset( $_GET['recipe_id'] ) && ! empty( $_GET['recipe_id'] ) ) {
			return intval( $_GET['recipe_id'] );
		}
	}

	add_filter( 'qode_framework_filter_front_end_option_value_id', 'easymeals_core_recipe_add_edit_profile_set_front_id' );
}

if ( ! function_exists( 'easymeals_core_dashboard_add_edit_recipe_fields' ) ) {
	function easymeals_core_dashboard_add_edit_recipe_fields( $params, $action, $recipe_id ) {
		$qode_framework = qode_framework_get_framework_root();

		if ( $action == 'add' ) {
			$title 			= esc_html__( 'Add Recipe', 'easymeals-core' );
			$button_text 	= esc_html__( 'Add Recipe', 'easymeals-core' );
			$updating_text	= esc_html__( 'Adding Recipe', 'easymeals-core' );
			$updated_text 	= esc_html__( 'Recipe Added', 'easymeals-core' );
			$rest_route		= 'addRecipeRestRoute';
		} elseif ( $action == 'edit' ) {
			$title 			= esc_html__( 'Edit Recipe', 'easymeals-core' );
			$button_text 	= esc_html__( 'Edit Recipe', 'easymeals-core' );
			$updating_text	= esc_html__( 'Editing Recipe', 'easymeals-core' );
			$updated_text 	= esc_html__( 'Recipe Edited', 'easymeals-core' );
			$rest_route		= 'editRecipeRestRoute';
		}

		$page = $qode_framework->add_options_page(
			array(
				'type'         => 'front-end',
				'slug'         => $action . '-recipe',
				'title'        => $title,
				'form_id'      => 'qodef-core-' . $action . '-recipe',
				'name'         => $action . '_recipe',
				'method'       => 'POST',
				'button_label' => $button_text,
				'button_args'  => array(
					'data-updating-text' => $updating_text,
					'data-updated-text'  => $updated_text,
					'data-rest-route'    => $rest_route,
					'data-rest-nonce'    => 'restNonce',
				)
			)
		);

		if ( $page ) {
			extract($params);

			$general_tab = $page->add_tab_element(
				array(
					'name'        => 'tab-general',
					'title'       => esc_html__( 'General Settings', 'easymeals-core' ),
					'description' => esc_html__( 'General information about recipe.', 'easymeals-core' )
				)
			);

			if ( $action == 'edit' && isset( $recipe_id ) && ! empty( $recipe_id ) ) {
				$general_tab->add_field_element(
					array(
						'field_type' => 'hidden',
						'name'       => 'qodef_recipe_single_db_id',
						'title'      => esc_html__('Recipe DB ID', 'easymeals-core'),
						'value'      => $recipe_id
					)
				);
			}

			$general_tab->add_field_element(
				array(
					'field_type'  	=> 'text',
					'name'        	=> 'qodef_recipe_title_default',
					'title'      	=> esc_html__( 'Recipe Title', 'easymeals-core' ),
					'value'			=> isset( $qodef_recipe_title_default ) ? $qodef_recipe_title_default : ''
				)
			);

			$general_tab->add_field_element(
				array(
					'field_type'  	=> 'textarea',
					'name'        	=> 'qodef_recipe_description_default',
					'title'      	=> esc_html__( 'Recipe Description', 'easymeals-core' ),
					'value'			=> isset( $qodef_recipe_description_default ) ? $qodef_recipe_description_default : ''
				)
			);

			$general_tab->add_field_element(
				array(
					'field_type'  	=> 'textarea',
					'name'        	=> 'qodef_recipe_excerpt_default',
					'title'      	=> esc_html__( 'Recipe Excerpt', 'easymeals-core' ),
					'value'			=> isset( $qodef_recipe_excerpt_default ) ? $qodef_recipe_excerpt_default : ''
				)
			);

			$general_tab->add_field_element(
				array(
					'field_type'  	=> 'image',
					'name'        	=> 'qodef_recipe_featured_image_default',
					'title'      	=> esc_html__( 'Recipe Featured Image', 'easymeals-core' ),
					'value'			=> isset( $qodef_recipe_featured_image_default ) ? $qodef_recipe_featured_image_default : ''
				)
			);

			$general_tab->add_field_element(
				array(
					'field_type'  	=> 'text',
					'name'        	=> 'qodef_recipe_single_ref_number_default',
					'title'      	=> esc_html__( 'Recipe Reference Number', 'easymeals-core' ),
					'value'			=> isset( $qodef_recipe_single_ref_number ) ? $qodef_recipe_single_ref_number : ''
				)
			);

			$category_meta = qode_framework_get_cpt_taxonomy_items( 'recipe-category', false );
			$categories    = ! empty( $category_meta ) ? $category_meta : array();

			if ( count( $categories ) ) {
				$general_tab->add_field_element(
					array(
						'field_type' => 'checkbox',
						'name'       => 'qodef_recipe_category_taxonomy',
						'title'      => esc_html__('Category', 'easymeals-core'),
						'options'    => $categories,
						'value'			=> isset( $qodef_recipe_category_taxonomy ) ? $qodef_recipe_category_taxonomy : ''
					)
				);
			}

			$tag_meta = qode_framework_get_cpt_taxonomy_items( 'recipe-tag', false );
			$tags     = ! empty( $tag_meta ) ? $tag_meta : array();

			if ( count( $tags ) ) {
				$general_tab->add_field_element(
					array(
						'field_type' => 'checkbox',
						'name'       => 'qodef_recipe_tag_taxonomy',
						'title'      => esc_html__('Tags', 'easymeals-core'),
						'options'    => $tags,
						'value'			=> isset( $qodef_recipe_tag_taxonomy ) ? $qodef_recipe_tag_taxonomy : ''
					)
				);

				if ( $action == 'add' ) {
					$general_tab->add_field_element(
						array(
							'field_type'  => 'text',
							'name'        => 'qodef_recipe_new_item_tag',
							'title'       => esc_html__('New Tag', 'easymeals-core'),
							'description' => esc_html__('If there is no tags in the list, be free to add it. For multiple tags just separate it with comma. That tags will automatically assign to your recipe item', 'easymeals-core'),
							'value'       => ''
						)
					);
				}
			}
			
			/* General sections */
			
			$general_section = $general_tab->add_section_element(
				array(
					'name'        => 'qodef_recipe_single_general_section',
					'title'       => esc_html__( 'General Settings', 'easymeals-core' ),
				)
			);
			
			$general_section->add_field_element(
				array(
					'field_type'  	=> 'select',
					'name'        	=> 'qodef_recipe_single_difficulty',
					'title'      	=> esc_html__( 'Difficulty', 'easymeals-core' ),
					'options'       => easymeals_core_get_receipe_difficulty(),
				)
			);
			
			$general_section->add_field_element(
				array(
					'field_type'  	=> 'text',
					'name'        	=> 'qodef_recipe_preparation_time',
					'title'      	=> esc_html__( 'Preparation Time', 'easymeals-core' ),
				)
			);
			
			$general_section->add_field_element(
				array(
					'field_type'  	=> 'text',
					'name'        	=> 'qodef_recipe_servings_number',
					'title'      	=> esc_html__( 'Servings Number', 'easymeals-core' ),
				)
			);
			
			$general_section->add_field_element(
				array(
					'field_type'    => 'yesno',
					'name'          => 'qodef_recipe_has_video',
					'title'         => esc_html__( 'Upload Video for this recipe', 'easymeals-core' ),
					'options'       => easymeals_core_get_select_type_options_pool( 'no_yes' ),
					'default_value' => 'no'
				)
			);
			
			$general_section->add_field_element(
				array(
					'field_type'  => 'text',
					'name'        => 'qodef_recipe_video_url',
					'title'       => esc_html__( 'Video URL', 'easymeals-core' ),
					'description' => esc_html__( 'Input your video link here. Here are all the supported video formats https://wordpress.org/support/article/video-shortcode/#options  https://wordpress.org/support/article/embeds/#okay-so-what-sites-can-i-embed-from', 'easymeals-core' ),
					'dependency'    => array(
						'show' => array(
							'qodef_recipe_has_video' => array(
								'values'        => 'yes',
								'default_value' => 'no'
							)
						)
					)
				)
			);
			
			/* Ingredients sections */
			
			$ingredients_section = $general_tab->add_section_element(
				array(
					'name'        => 'qodef_recipe_single_ingredients_section',
					'title'       => esc_html__( 'Ingredients', 'easymeals-core' ),
				)
			);
			
			$ingredients_repeater = $ingredients_section->add_repeater_element(
				array(
					'name'        => 'qodef_recipe_single_ingredients_items',
					'title'       => esc_html__( 'Ingredients Item', 'easymeals-core' ),
					'button_text' => esc_html__( 'Add Ingredient', 'easymeals-core' )
				)
			);
			
			$ingredients_repeater->add_field_element(
				array(
					'field_type' => 'text',
					'name'       => 'qodef_recipe_single_ingredients_quantity',
					'title'      => esc_html__( 'Ingredient Quantity', 'easymeals-core' ),
				)
			);
			
			$ingredients_repeater->add_field_element(
				array(
					'field_type' => 'text',
					'name'       => 'qodef_recipe_single_ingredients_text',
					'title'      => esc_html__( 'Ingredient Name', 'easymeals-core' )
				)
			);
			$ingredients_repeater->add_field_element(
				array(
					'field_type' => 'text',
					'name'       => 'qodef_recipe_single_ingredients_link_text',
					'title'      => esc_html__( 'Ingredient Linked Text', 'easymeals-core' )
				)
			);
			$ingredients_repeater->add_field_element(
				array(
					'field_type' => 'text',
					'name'       => 'qodef_recipe_single_ingredients_link',
					'title'      => esc_html__( 'Ingredient Linked Text Link', 'easymeals-core' )
				)
			);
			$ingredients_repeater->add_field_element(
				array(
					'field_type' => 'text',
					'name'       => 'qodef_recipe_single_ingredients_note',
					'title'      => esc_html__( 'Ingredient Info Note', 'easymeals-core' )
				)
			);
			
			/* Additional ingridients sections */
			
			
			$add_ingredients_section = $general_tab->add_section_element(
				array(
					'name'        => 'qodef_recipe_single_add_ingredients_section',
					'title'       => esc_html__( 'Additional Ingredients', 'easymeals-core' ),
				)
			);
			
			$add_ingredients_section->add_field_element(
				array(
					'field_type' => 'text',
					'name'       => 'qodef_recipe_single_add_ingredients_title',
					'title'      => esc_html__( 'Additional Ingredient Section Title', 'easymeals-core' ),
				)
			);
			
			$add_ingredients_repeater = $add_ingredients_section->add_repeater_element(
				array(
					'name'        => 'qodef_recipe_single_add_ingredients_items',
					'title'       => esc_html__( 'Additional Ingredients Item', 'easymeals-core' ),
					'button_text' => esc_html__( 'Add Ingredient', 'easymeals-core' )
				)
			);
			
			$add_ingredients_repeater->add_field_element(
				array(
					'field_type' => 'text',
					'name'       => 'qodef_recipe_single_add_ingredients_quantity',
					'title'      => esc_html__( 'Additional Ingredient Quantity', 'easymeals-core' ),
				)
			);
			
			$add_ingredients_repeater->add_field_element(
				array(
					'field_type' => 'text',
					'name'       => 'qodef_recipe_single_add_ingredients_text',
					'title'      => esc_html__( 'Additional Ingredient Name', 'easymeals-core' )
				)
			);
			$add_ingredients_repeater->add_field_element(
				array(
					'field_type' => 'text',
					'name'       => 'qodef_recipe_single_add_ingredients_note',
					'title'      => esc_html__( 'Additional Ingredient Info Note', 'easymeals-core' )
				)
			);
			
			/* Nutrition sections */
			
			$nutrition_section = $general_tab->add_section_element(
				array(
					'name'        => 'qodef_recipe_single_nutrition_section',
					'title'       => esc_html__( 'Nutrition Info', 'easymeals-core' ),
				)
			);
			
			$nutrition_repeater = $nutrition_section->add_repeater_element(
				array(
					'name'        => 'qodef_recipe_single_nutrition_items',
					'title'       => esc_html__( 'Nutrition Item', 'easymeals-core' ),
					'button_text' => esc_html__( 'Add Nutrition item', 'easymeals-core' )
				)
			);
			
			$nutrition_repeater->add_field_element(
				array(
					'field_type' => 'text',
					'name'       => 'qodef_recipe_single_nutrition_quantity',
					'title'      => esc_html__( 'Nutrition Quantity', 'easymeals-core' ),
				)
			);
			
			$nutrition_repeater->add_field_element(
				array(
					'field_type' => 'text',
					'name'       => 'qodef_recipe_single_nutrition_text',
					'title'      => esc_html__( 'Nutrition Name', 'easymeals-core' )
				)
			);
			
			/* Directions sections */
			
			
			$directions_section = $general_tab->add_section_element(
				array(
					'name'        => 'qodef_recipe_single_directions_section',
					'title'       => esc_html__( 'Directions', 'easymeals-core' ),
				)
			);
			
			$directions_repeater = $directions_section->add_repeater_element(
				array(
					'name'        => 'qodef_recipe_single_direction_items',
					'title'       => esc_html__( 'Directions Item', 'easymeals-core' ),
					'button_text' => esc_html__( 'Add Directions item', 'easymeals-core' )
				)
			);
			
			$directions_repeater->add_field_element(
				array(
					'field_type'  	=> 'text',
					'name'        	=> 'qodef_recipe_single_direction_title',
					'title'      	=> esc_html__( 'Direction Title', 'easymeals-core' ),
				)
			);
			
			$directions_repeater->add_field_element(
				array(
					'field_type'  	=> 'textarea',
					'name'        	=> 'qodef_recipe_single_direction_text_top',
					'title'      	=> esc_html__( 'Direction Text Top', 'easymeals-core' ),
				)
			);
			$directions_repeater->add_field_element(
				array(
					'field_type' => 'image',
					'name'       => 'qodef_recipe_single_direction_gallery',
					'title'      => esc_html__( 'Upload Images', 'easymeals-core' ),
					'multiple'   => 'yes',
				)
			);
			$directions_repeater->add_field_element(
				array(
					'field_type'  	=> 'textarea',
					'name'        	=> 'qodef_recipe_single_direction_text_bottom',
					'title'      	=> esc_html__( 'Direction Text Bottom', 'easymeals-core' ),
				)
			);
			
			/* Notes sections */
			
			$notes_section = $general_tab->add_section_element(
				array(
					'name'        => 'qodef_recipe_single_notes_section',
					'title'       => esc_html__( 'Notes', 'easymeals-core' ),
				)
			);
			
			$notes_repeater = $notes_section->add_repeater_element(
				array(
					'name'        => 'qodef_recipe_single_notes_items',
					'title'       => esc_html__( 'Notes Item', 'easymeals-core' ),
					'button_text' => esc_html__( 'Add Note', 'easymeals-core' )
				)
			);
			
			$notes_repeater->add_field_element(
				array(
					'field_type' => 'text',
					'name'       => 'qodef_recipe_single_note',
					'title'      => esc_html__( 'Note', 'easymeals-core' ),
				)
			);
			
			/* Banner sections */
			
			$banner_section = $general_tab->add_section_element(
				array(
					'name'        => 'qodef_recipe_single_banner_section',
					'title'       => esc_html__( 'Banner', 'easymeals-core' ),
				)
			);
			
			$banner_section->add_field_element(
				array(
					'field_type' => 'image',
					'name'       => 'qodef_recipe_single_banner',
					'title'      => esc_html__( 'Upload Image', 'easymeals-core' ),
				)
			);
			$banner_section->add_field_element(
				array(
					'field_type' => 'text',
					'name'       => 'qodef_recipe_single_banner_link',
					'title'      => esc_html__( 'Link Image', 'easymeals-core' ),
				)
			);
			
			$page->render();
		}
	}
}

if ( ! function_exists( 'easymeals_core_recipe_check_is_users_item' ) ) {
	function easymeals_core_recipe_check_is_users_item( $recipe_item_id ) {
		$user_id = get_current_user_id();

		$item_user_id = intval( get_post_field( 'post_author', $recipe_item_id ) );

		if ( $user_id === $item_user_id ) {
			return true;
		}

		return false;
	}
}
