<?php

if ( ! function_exists( 'easymeals_core_add_recipe_list_variation_info_below' ) ) {
	function easymeals_core_add_recipe_list_variation_info_below( $variations ) {
		
		$variations['info-below'] = esc_html__( 'Info Below', 'easymeals-core' );
		
		return $variations;
	}
	
	add_filter( 'easymeals_core_filter_recipe_list_layouts', 'easymeals_core_add_recipe_list_variation_info_below' );
}

if ( ! function_exists( 'easymeals_core_add_recipe_list_options_info_below' ) ) {
	function easymeals_core_add_recipe_list_options_info_below( $options ) {
		$info_below_options   = array();
		$margin_option        = array(
			'field_type' => 'text',
			'name'       => 'info_below_content_margin_top',
			'title'      => esc_html__( 'Content Top Margin', 'easymeals-core' ),
			'dependency' => array(
				'show' => array(
					'layout' => array(
						'values'        => 'info-below',
						'default_value' => ''
					)
				)
			),
			'group'      => esc_html__( 'Layout', 'easymeals-core' )
		);
		$info_below_options[] = $margin_option;
		$info_below_options[] = array(
			'field_type' => 'text',
			'name'       => 'info_below_title_margin_bottom',
			'title'      => esc_html__( 'Title Bottom Margin', 'easymeals-core' ),
			'dependency' => array(
				'show' => array(
					'layout' => array(
						'values'        => 'info-below',
						'default_value' => ''
					)
				)
			),
			'group'      => esc_html__( 'Layout', 'easymeals-core' )
		);
		$info_below_options[] = array(
			'field_type' => 'select',
			'name'       => 'info_below_enable_button',
			'title'      => esc_html__( 'Enable Read More Button', 'easymeals-core' ),
			'options'    => easymeals_core_get_select_type_options_pool( 'no_yes', false ),
			'default_value' => 'no',
			'dependency' => array(
				'show' => array(
					'layout' => array(
						'values'        => 'info-below',
						'default_value' => ''
					)
				)
			),
			'group'      => esc_html__( 'Layout', 'easymeals-core' )
		);
		$info_below_options[] = array(
			'field_type' => 'select',
			'name'       => 'info_below_hide_image',
			'title'      => esc_html__( 'Hide Featured Image', 'easymeals-core' ),
			'options'    => easymeals_core_get_select_type_options_pool( 'no_yes', false ),
			'default_value' => 'no',
			'dependency' => array(
				'show' => array(
					'layout' => array(
						'values'        => 'info-below',
						'default_value' => ''
					)
				)
			),
			'group'      => esc_html__( 'Layout', 'easymeals-core' )
		);
		
		return array_merge( $options, $info_below_options );
	}
	
	add_filter( 'easymeals_core_filter_recipe_list_extra_options', 'easymeals_core_add_recipe_list_options_info_below' );
}