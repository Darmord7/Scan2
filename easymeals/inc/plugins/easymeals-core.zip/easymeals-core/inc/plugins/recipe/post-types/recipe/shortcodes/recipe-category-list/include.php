<?php

include_once EASYMEALS_CORE_PLUGINS_PATH . '/recipe/post-types/recipe/shortcodes/recipe-category-list/recipe-category-list.php';

foreach ( glob( EASYMEALS_CORE_PLUGINS_PATH . '/recipe/post-types/recipe/shortcodes/recipe-category-list/variations/*/include.php' ) as $variation ) {
	include_once $variation;
}