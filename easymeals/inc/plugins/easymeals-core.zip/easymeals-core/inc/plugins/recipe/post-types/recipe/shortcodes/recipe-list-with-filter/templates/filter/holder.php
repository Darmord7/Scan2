<div class="qodef-e-filter-holder">
    <h3><?php esc_html_e('Filter Recipes:', 'easymeals-core') ?></h3>
    <p><?php esc_html_e('Check multiple boxes below to narrow recipe search results', 'easymeals-core') ?></p>
    <?php
        masterds_core_get_recipe_list_filter( 'custom_search', $params );
        // Get filter by category part
        masterds_core_get_recipe_list_filter( 'category', $params );
        // Get filter by tag part
        masterds_core_get_recipe_list_filter( 'tag', $params );

    // Get filter buttons part
    easymeals_core_template_part( 'plugins/recipe/post-types/recipe/shortcodes/recipe-list-with-filter', 'templates/filter/button' );
    ?>
</div>