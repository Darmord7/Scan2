<?php
$styles = array();
if ( ! empty( $info_right_content_padding_right ) ) {
	$padding_right = qode_framework_string_ends_with_space_units( $info_right_content_padding_right ) ? $info_right_content_padding_right : intval( $info_right_content_padding_right ) . 'px';
	$styles[] = 'padding-right:' . $padding_right;
}
if ( ! empty( $info_right_content_padding_left ) ) {
	$padding_left = qode_framework_string_ends_with_space_units( $info_right_content_padding_left ) ? $info_right_content_padding_left : intval( $info_right_content_padding_left ) . 'px';
	$styles[] = 'padding-left:' . $padding_left;
}
?>
<article <?php post_class( $item_classes ); ?>>
	<div class="qodef-e-inner" <?php qode_framework_inline_style( $this_shortcode->get_list_item_style( $params ) ) ?>>
		<div class="qodef-e-image">
			<?php easymeals_core_list_sc_template_part( 'plugins/recipe/post-types/recipe/shortcodes/recipe-list', 'post-info/image', '', $params ); ?>
		</div>
		<div class="qodef-e-content" <?php qode_framework_inline_style( $styles ); ?>>
			<?php if($enable_top_info === 'yes' ||  $enable_categories === 'yes') { ?>
				<div class="qodef-e-info-top">
					<?php easymeals_core_list_sc_template_part( 'plugins/recipe/post-types/recipe/shortcodes/recipe-list', 'post-info/meta', '', $params ); ?>
					<?php easymeals_core_list_sc_template_part( 'plugins/recipe/post-types/recipe/shortcodes/recipe-list', 'post-info/category', '', $params ); ?>
				</div>
			<?php } ?>
			<?php easymeals_core_list_sc_template_part( 'plugins/recipe/post-types/recipe/shortcodes/recipe-list', 'post-info/title', '', $params ); ?>
			<?php easymeals_core_list_sc_template_part( 'plugins/recipe/post-types/recipe/shortcodes/recipe-list', 'post-info/excerpt', '', $params ); ?>
			<?php if($enable_author_date === 'yes' || $enable_share === 'yes' || $enable_like === 'yes' || $enable_bookmark === 'yes') { ?>
				<div class="qodef-e-info-bottom">
					<?php if($enable_author_date === 'yes') { ?>
						<div class="qodef-e-left">
							<?php easymeals_core_list_sc_template_part( 'plugins/recipe/post-types/recipe/shortcodes/recipe-list', 'post-info/author', '', $params ); ?>
						</div>
					<?php } ?>
					<?php if($enable_share === 'yes' || $enable_like === 'yes' || $enable_bookmark === 'yes') { ?>
						<div class="qodef-e-right">
							<?php if($enable_share === 'yes') {
								easymeals_core_list_sc_template_part( 'plugins/recipe/post-types/recipe/shortcodes/recipe-list', 'post-info/share', '', $params );
							} ?>
							<?php if($enable_like === 'yes') {
								easymeals_core_list_sc_template_part( 'plugins/recipe/post-types/recipe/shortcodes/recipe-list', 'post-info/like', '', $params );
							} ?>
							<?php if($enable_bookmark === 'yes') {
								easymeals_core_list_sc_template_part( 'plugins/recipe/post-types/recipe/shortcodes/recipe-list', 'post-info/wishlist', '', $params );
							} ?>
						</div>
					<?php } ?>
				</div>
			<?php } ?>
			<?php
			if($info_below_enable_button === 'yes') {
				easymeals_core_list_sc_template_part( 'plugins/recipe/post-types/recipe/shortcodes/recipe-list', 'post-info/button', '', $params );
			} ?>
		</div>
	</div>
</article>