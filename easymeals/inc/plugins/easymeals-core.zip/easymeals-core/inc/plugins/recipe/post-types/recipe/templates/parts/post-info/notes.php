<?php
$notes_items = get_post_meta( get_the_ID(), 'qodef_recipe_single_notes_items', true );

if ( ! empty ( $notes_items ) ) { ?>
	<div class="qodef-m-notes">
		<div class="qodef-shortcode qodef-m  qodef-section-title qodef-title-with-lines">
			<h3 class="qodef-m-title">
				<span><?php esc_html_e('Notes','easymeals-core'); ?></span>
				<span class="qodef-m-title-lines"></span>
			</h3>
		</div>
		<?php foreach ( $notes_items as $item ) {
			$note  = $item['qodef_recipe_single_note'];
			?>
			<div class="qodef-e qodef-note">
				<?php echo esc_html($note); ?>
			</div>
		<?php } ?>
	</div>
<?php } ?>