<?php

if ( ! function_exists( 'easymeals_core_add_recipe_single_navigation_options' ) ) {
	function easymeals_core_add_recipe_single_navigation_options( $page ) {

		if ( $page ) {

			$page->add_field_element(
				array(
					'field_type'    => 'yesno',
					'name'          => 'qodef_recipe_enable_navigation',
					'title'         => esc_html__( 'Navigation', 'easymeals-core' ),
					'description'   => esc_html__( 'Enabling this option will turn on recipe navigation functionality', 'easymeals-core' ),
					'default_value' => 'yes'
				)
			);

			$page->add_field_element(
				array(
					'field_type'    => 'yesno',
					'name'          => 'qodef_recipe_navigation_through_same_category',
					'title'         => esc_html__( 'Navigation Through Same Category', 'easymeals-core' ),
					'description'   => esc_html__( 'Enabling this option will make recipe navigation sort through current category', 'easymeals-core' ),
					'default_value' => 'no',
					'dependency'    => array(
						'show' => array(
							'qodef_recipe_enable_navigation' => array(
								'values'        => 'yes',
								'default_value' => 'yes'
							)
						)
					)
				)
			);
		}
	}

	add_action( 'easymeals_core_action_after_recipe_options_single', 'easymeals_core_add_recipe_single_navigation_options' );
}