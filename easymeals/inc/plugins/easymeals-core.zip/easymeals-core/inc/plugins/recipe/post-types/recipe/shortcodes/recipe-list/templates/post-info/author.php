<?php $author_id     = get_the_author_meta('ID'); ?>
<div class="qodef-e qodef-info--author-date">
	<div class="qodef-m-image">
		<a itemprop="url" href="<?php echo esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ); ?>">
			<?php echo get_avatar( $author_id, 48 ); ?>
		</a>
	</div>
	<div class="qodef-m-text">
		<a itemprop="author" class="qodef-e-info-author-link" href="<?php echo esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ); ?>">
			<?php the_author_meta( 'display_name' ); ?>
		</a>
		<p itemprop="dateCreated" class="entry-date updated"><?php the_time( get_option( 'date_format' ) ); ?></p>
	</div>
</div>