<?php

if ( ! function_exists( 'easymeals_core_add_recipe_options' ) ) {
	/**
	 * Function that add general options for this module
	 */
	function easymeals_core_add_recipe_options() {
		$qode_framework = qode_framework_get_framework_root();
		
		$page = $qode_framework->add_options_page(
			array(
				'scope'       => EASYMEALS_CORE_OPTIONS_NAME,
				'type'        => 'admin',
				'slug'        => 'recipe-item',
				'layout'      => 'tabbed',
				'icon'        => 'fa fa-cog',
				'title'       => esc_html__( 'Recipe', 'easymeals-core' ),
				'description' => esc_html__( 'Global settings related to recipes', 'easymeals-core' )
			)
		);
		
		if ( $page ) {
			
			$single_tab = $page->add_tab_element(
				array(
					'name'        => 'tab-single',
					'icon'        => 'fa fa-cog',
					'title'       => esc_html__( 'Recipe Single', 'easymeals-core' ),
					'description' => esc_html__( 'Settings related to recipe single pages', 'easymeals-core' )
				)
			);
			
			$single_tab->add_field_element(
				array(
					'field_type'  => 'select',
					'name'        => 'qodef_recipe_single_sidebar_layout',
					'title'       => esc_html__( 'Sidebar Layout', 'easymeals-core' ),
					'description' => esc_html__( 'Choose default sidebar layout for recipe single', 'easymeals-core' ),
					'options'     => easymeals_core_get_select_type_options_pool( 'sidebar_layouts' )
				)
			);
			
			$custom_sidebars = easymeals_core_get_custom_sidebars();
			if ( ! empty( $custom_sidebars ) && count( $custom_sidebars ) > 1 ) {
				$single_tab->add_field_element(
					array(
						'field_type'    => 'select',
						'name'          => 'qodef_recipe_single_custom_sidebar',
						'title'         => esc_html__( 'Custom Sidebar', 'easymeals-core' ),
						'description'   => esc_html__( 'Choose a custom sidebar to display on recipe singles', 'easymeals-core' ),
						'options'       => $custom_sidebars
					)
				);
			}
			
			$single_tab->add_field_element(
				array(
					'field_type'  => 'select',
					'name'        => 'qodef_recipe_single_sidebar_grid_gutter',
					'title'       => esc_html__( 'Set Grid Gutter', 'easymeals-core' ),
					'description' => esc_html__( 'Choose grid gutter size to set space between content and sidebar', 'easymeals-core' ),
					'options'     => easymeals_core_get_select_type_options_pool( 'items_space' )
				)
			);
			
			// Hook to include additional options after single module options
			do_action( 'easymeals_core_action_after_recipe_options_single', $single_tab );
			
			// Hook to include additional options after module options
			do_action( 'easymeals_core_action_after_recipe_options_map', $page );
		}
	}
	
	add_action( 'easymeals_core_action_default_options_init', 'easymeals_core_add_recipe_options', easymeals_core_get_admin_options_map_position( 'portfolio' ) );
}