<?php

if ( ! function_exists( 'easymeals_core_add_user_cook_role' ) ) {
	function easymeals_core_add_user_cook_role() {
		$allowed_type = 'recipe';

		$capabilities = array(
			'read'								=> false,
			'read_private'.$allowed_type.'s'	=> false,
			'publish_'.$allowed_type.'s'        => false,
			'edit_'.$allowed_type.'s'           => true,
			'edit_published_'.$allowed_type.'s' => true,
			'edit_others_'.$allowed_type.'s'    => false,
			'edit_pages'           				=> false,
			'manage_categories'			    	=> false,
			'manage_terms'				    	=> true,
			'edit_themes'         				=> false,
			'install_plugins'      				=> false,
			'update_plugin'        				=> false,
			'edit_plugins'         				=> false,
			'update_core'          				=> false,
			'upload_files'         				=> true,
			'edit_files'           				=> false
		);
		
		add_role( 'cook', esc_html__( 'Cook', 'easymeals-core' ), $capabilities );
		
		update_option( 'default_role', 'cook' );
	}
	
	add_action( 'easymeals_core_action_plugin_loaded', 'easymeals_core_add_user_cook_role' );
}
