<?php

if ( ! function_exists( 'easymeals_core_add_cook_user_options' ) ) {
	function easymeals_core_add_cook_user_options() {
		$qode_framework = qode_framework_get_framework_root();

		$page = $qode_framework->add_options_page(
			array(
				'scope' => array( 'cook' ),
				'type'  => 'user',
				'title' => esc_html__( 'Cook Info', 'easymeals-core' ),
				'slug'  => 'cook-options',
			)
		);

		if ( $page ) {
			$page->add_field_element(
				array(
					'field_type'  => 'image',
					'name'        => 'qodef_cook_profile_image',
					'title'       => esc_html__( 'Profile Image', 'easymeals-core' ),
				)
			);

			$page->add_field_element(
				array(
					'field_type'  => 'text',
					'name'        => 'qodef_cook_telephone',
					'title'       => esc_html__( 'Telephone', 'easymeals-core' ),
				)
			);

			$page->add_field_element(
				array(
					'field_type'  => 'text',
					'name'        => 'qodef_cook_mobile_phone',
					'title'       => esc_html__( 'Mobile Phone', 'easymeals-core' ),
				)
			);

			$page->add_field_element(
				array(
					'field_type'  => 'text',
					'name'        => 'qodef_cook_fax_number',
					'title'       => esc_html__( 'Fax Number', 'easymeals-core' ),
				)
			);

			$page->add_field_element(
				array(
					'field_type'  => 'text',
					'name'        => 'qodef_cook_address',
					'title'       => esc_html__( 'Cook Address', 'easymeals-core' ),
				)
			);
		}
	}

	add_action( 'easymeals_core_action_register_role_custom_fields', 'easymeals_core_add_cook_user_options' );
}