<?php

if ( ! function_exists( 'easymeals_core_include_recipe_single_related_posts_template' ) ) {
	/**
	 * Function which includes additional module on single recipe page
	 */
	function easymeals_core_include_recipe_single_related_posts_template() {
		easymeals_core_template_part( 'plugins/recipe/post-types/recipe', 'templates/single/related-posts/templates/related-posts' );
	}
	
	add_action( 'easymeals_core_action_after_recipe_single_item', 'easymeals_core_include_recipe_single_related_posts_template', 20 ); // permission 20 is set to define template position
}