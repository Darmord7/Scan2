<?php

if ( ! function_exists( 'easymeals_core_add_recipe_list_with_filter_shortcode' ) ) {
	/**
	 * Function that isadding shortcode into shortcodes list for registration
	 *
	 * @param array $shortcodes - Array of registered shortcodes
	 *
	 * @return array
	 */
	function easymeals_core_add_recipe_list_with_filter_shortcode( $shortcodes ) {
		$shortcodes[] = 'EasyMealsCoreRecipeListWithFilterShortcode';
		
		return $shortcodes;
	}
	
	add_filter( 'easymeals_core_filter_register_shortcodes', 'easymeals_core_add_recipe_list_with_filter_shortcode' );
}

if ( class_exists( 'EasyMealsCoreListShortcode' ) ) {
	class EasyMealsCoreRecipeListWithFilterShortcode extends EasyMealsCoreListShortcode {
		
		public function __construct() {
			$this->set_post_type( 'recipe' );
			$this->set_post_type_taxonomy( 'recipe-category' );
			$this->set_post_type_additional_taxonomies( array( 'recipe-tag' ) );
			$this->set_layouts( apply_filters( 'easymeals_core_filter_recipe_list_with_filter_layouts', array() ) );
			$this->set_extra_options( apply_filters( 'easymeals_core_filter_recipe_list_with_filter_extra_options', array() ) );
			$this->set_hover_animation_options( apply_filters( 'easymeals_core_filter_recipe_list_with_filter_hover_animation_options', array() ) );
			add_filter( 'easymeals_core_filter_additional_query_args', array( $this, 'additional_query' ), 10, 3 );


			parent::__construct();
		}
		
		public function map_shortcode() {
			$this->set_shortcode_path( EASYMEALS_CORE_PLUGINS_URL_PATH . '/recipe/post-types/recipe/shortcodes/recipe-list-with-filter' );
			$this->set_base( 'easymeals_core_recipe_list_with_filter' );
			$this->set_name( esc_html__( 'Recipe List With Filter', 'easymeals-core' ) );
			$this->set_description( esc_html__( 'Shortcode that displays list of recipes with filter on side', 'easymeals-core' ) );
			$this->set_category( esc_html__( 'EasyMeals Core', 'easymeals-core' ) );
			$this->set_scripts(
				apply_filters('easymeals_core_filter_recipe_list_with_filter_register_assets', array())
			);

			$this->set_option( array(
				'field_type' => 'text',
				'name'       => 'custom_class',
				'title'      => esc_html__( 'Custom Class', 'easymeals-core' )
			) );
			$this->set_option( array(
				'field_type' => 'text',
				'name'       => 'custom_search',
				'title'      => esc_html__( 'Custom Search', 'easymeals-core' ),
				'visibility' => array( 'map_for_page_builder' => false )
			) );
			$this->map_list_options( array(
				'exclude_behavior' => array( 'masonry', 'slider' ),
				'group'            => esc_html__( 'Gallery Settings', 'easymeals-core' )
			) );
			$this->map_query_options( array( 'post_type' => $this->get_post_type() ) );
			$this->map_layout_options( array(
				'layouts'          => $this->get_layouts(),
				'hover_animations' => $this->get_hover_animation_options()
			) );
			$this->map_additional_options(
				array(
					'exclude_filter' => true,
				)
			);
			$this->map_extra_options();
		}
		
		public static function call_shortcode( $params ) {
			$html = qode_framework_call_shortcode( 'easymeals_core_recipe_list_with_filter', $params );
			$html = str_replace( "\n", '', $html );
			
			return $html;
		}
		
		public function load_assets() {
			parent::load_assets();
			
			do_action( 'easymeals_core_action_recipe_list_with_filter_load_assets', $this->get_atts() );
		}
		
		public function render( $options, $content = null ) {
			parent::render( $options );
			
			$atts = $this->get_atts();
			
			$atts['post_type']       = $this->get_post_type();
			$atts['taxonomy_filter'] = $this->get_post_type_taxonomy();
			
			// Additional query args
			$atts['additional_query_args'] = $this->get_additional_query_args( $atts );
			
			$atts['query_result']   = new \WP_Query( easymeals_core_get_query_params( $atts ) );
			$atts['holder_classes'] = $this->get_holder_classes( $atts );
			//$atts['slider_attr']    = $this->get_slider_data( $atts );
			$atts['unique'] = wp_unique_id();
			$atts['data_attr']      = easymeals_core_get_pagination_data( EASYMEALS_CORE_REL_PATH, 'plugins/recipe/post-types/recipe/shortcodes', 'recipe-list-with-filter', 'recipe', $atts );
			
			$atts['this_shortcode'] = $this;
			
			return easymeals_core_get_template_part( 'plugins/recipe/post-types/recipe/shortcodes/recipe-list-with-filter', 'templates/content', $atts['behavior'], $atts );
		}
		
		private function get_holder_classes( $atts ) {
			$holder_classes = $this->init_holder_classes();
			
			$holder_classes[] = 'qodef-recipe-list-with-filter';
			$holder_classes[] = ! empty( $atts['layout'] ) ? 'qodef-item-layout--' . $atts['layout'] : '';

			$list_classes            = $this->get_list_classes( $atts );
			$hover_animation_classes = $this->get_hover_animation_classes( $atts );
			$holder_classes          = array_merge( $holder_classes, $list_classes, $hover_animation_classes );
			
			return implode( ' ', $holder_classes );
		}
		
		public function get_item_classes( $atts ) {
			$item_classes = $this->init_item_classes();
			
			$list_item_classes = $this->get_list_item_classes( $atts );
			
			$item_classes = array_merge( $item_classes, $list_item_classes );
			
			return implode( ' ', $item_classes );
		}

		public function additional_query( $args, $atts, $post_type ) {
			$number_of_taxonomies = count( array_merge( array( $this->get_post_type_taxonomy() ), $this->get_post_type_additional_taxonomies() ) );

			if ( ! empty( $atts['additional_params'] ) && $atts['additional_params'] == 'tax' && $number_of_taxonomies > 0 && $post_type == $this->get_post_type() && $atts['object_class_name'] === 'EasyMealsCoreRecipeListWithFilterShortcode' ) {
				$args['tax_query'] = array();

				for ( $i = 1; $i <= $number_of_taxonomies; $i ++ ) {
					$taxonomy_values = array();

					$slug = isset( $atts[ 'tax_slug_' . $i ] ) ? $atts[ 'tax_slug_' . $i ] : '';
					$ids  = isset( $atts[ 'tax__in_' . $i ] ) ? $atts[ 'tax__in_' . $i ] : '';

					if ( ! empty( $ids ) && empty( $slug ) ) {
						$taxonomy_values['field'] = 'term_id';
						$taxonomy_values['terms'] = is_array( $ids ) ? array_map( 'intval', $ids ) : array_map( 'intval', explode( ',', str_replace( ' ', '', $ids ) ) );
					} elseif ( ! empty( $slug ) ) {
						$taxonomy_values['field'] = 'slug';
						$taxonomy_values['terms'] = $slug;
					}

					if ( ! empty( $atts[ 'tax_' . $i ] ) && ! empty( $taxonomy_values ) ) {
						$args['tax_query'][] = array_merge( array( 'taxonomy' => $atts[ 'tax_' . $i ] ), $taxonomy_values );
					}
				}

				if ( count( $args['tax_query'] ) > 1 ) {
					$args['tax_query'] = array_merge( array( 'relation' => 'AND' ), $args['tax_query'] );
				}
			}

			return $args;
		}
	}
}