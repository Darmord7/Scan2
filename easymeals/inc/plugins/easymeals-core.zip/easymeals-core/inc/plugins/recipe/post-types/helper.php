<?php

if ( ! function_exists( 'easymeals_core_recipe_post_types' ) ) {
	function easymeals_core_recipe_post_types( $class ) {
		foreach ( glob( EASYMEALS_CORE_PLUGINS_PATH . '/recipe/post-types/*', GLOB_ONLYDIR ) as $post_type ) {
			
			if ( basename( $post_type ) !== 'dashboard' ) {
				$is_disabled = easymeals_core_performance_get_option_value( $post_type, 'easymeals_core_performance_post_type_' );
				
				if ( empty( $is_disabled ) ) {
					$class->set_allowed_post_types( $post_type );
				}
			}
		}
	}
	
	add_action( 'easymeals_core_action_add_custom_post_type', 'easymeals_core_recipe_post_types' );
}