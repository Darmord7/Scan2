<?php
$directions_items = get_post_meta( get_the_ID(), 'qodef_recipe_single_direction_items', true );

if ( ! empty ( $directions_items ) ) { ?>
	<div class="qodef-m-directions">
		<div class="qodef-shortcode qodef-m  qodef-section-title qodef-title-with-lines">
			<h3 class="qodef-m-title">
				<span><?php esc_html_e('Directions','easymeals-core'); ?></span>
				<span class="qodef-m-title-lines"></span>
			</h3>
		</div>
		<?php
		$i = 0;
		foreach ( $directions_items as $item ) {
			$title  = $item['qodef_recipe_single_direction_title'];
			$media  = $item['qodef_recipe_single_direction_gallery'];
			$text_top  = $item['qodef_recipe_single_direction_text_top'];
			$text_bottom  = $item['qodef_recipe_single_direction_text_bottom'];
			$images = explode( ',', $media );
			$i++;
			?>
			<div class="qodef-e qodef-directions-items">
			<span class="qodef-m-order-num">
				<?php echo esc_html($i).'.'; ?>
			</span>
				<div class="qodef-direction-inner">
					<h4 class="qodef-direction-title"><?php echo esc_html( $title ); ?></h4>
					<div class="qodef-m-direction-text-top"><?php echo esc_html( $text_top ); ?></div>
					<?php if( ! empty ($media ) ) { ?>
						<div class="qodef-e qodef-gallery">
							<?php foreach ($images as $image ) {
								$image_src   = wp_get_attachment_image_src( $image, 'full' );
								?>
								<span class="qodef-grid-item">
									<?php echo wp_get_attachment_image( $image, 'full' ); ?>
								</span>
							<?php } ?>
						</div>
					<?php } ?>
					<div class="qodef-m-direction-text-bottom"><?php echo esc_html( $text_bottom ); ?></div>
					<div class="qodef-m-completed">
						<span class="icon_circle-empty"></span>
						<span><?php esc_html_e('Mark as complete','easymeals-core') ?></span>
					</div>
				</div>
			</div>
		<?php } ?>
	</div>
<?php } ?>