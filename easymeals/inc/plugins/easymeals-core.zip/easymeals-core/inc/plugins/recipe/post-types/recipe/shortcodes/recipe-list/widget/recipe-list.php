<?php

if ( ! function_exists( 'easymeals_core_add_recipe_list_widget' ) ) {
	/**
	 * Function that add widget into widgets list for registration
	 *
	 * @param array $widgets
	 *
	 * @return array
	 */
	function easymeals_core_add_recipe_list_widget( $widgets ) {
		$widgets[] = 'EasyMealsCoreRecipeListWidget';
		
		return $widgets;
	}
	
	add_filter( 'easymeals_core_filter_register_widgets', 'easymeals_core_add_recipe_list_widget' );
}

if ( class_exists( 'QodeFrameworkWidget' ) ) {
	class EasyMealsCoreRecipeListWidget extends QodeFrameworkWidget {
		
		public function map_widget() {
			$this->set_widget_option(
				array(
					'field_type' => 'text',
					'name'       => 'widget_title',
					'title'      => esc_html__( 'Title', 'easymeals-core' )
				)
			);
			$widget_mapped = $this->import_shortcode_options( array(
              'shortcode_base' => 'easymeals_core_recipe_list',
                'exclude'   => array(
                    'custom_padding', 'enable_top_info', 'enable_share', 'enable_like', 'enable_bookmark', 'enable_excerpt', 'excerpt_length', 'white_bg', 'tags_column'
                )
          ) );
			
			if ( $widget_mapped ) {
				$this->set_base( 'easymeals_core_recipe_list' );
				$this->set_name( esc_html__( 'EasyMeals Recipe List', 'easymeals-core' ) );
				$this->set_description( esc_html__( 'Display a list of recipe', 'easymeals-core' ) );
			}
		}
		
		public function render( $atts ) {
			$params = $this->generate_string_params( $atts );
			
			echo do_shortcode( "[easymeals_core_recipe_list $params]" ); // XSS OK
		}
	}
}
