<article <?php post_class( 'qodef-recipe-list-item qodef-e' ); ?>>
	<div class="qodef-e-inner">
		<?php easymeals_core_template_part( 'plugins/recipe/post-types/recipe', 'templates/parts/post-info/title' ); ?>
		<div class="qodef-e-content qodef-e-content-above-image">
			<?php easymeals_core_template_part( 'plugins/recipe/post-types/recipe', 'templates/parts/post-info/author-date' ); ?>
			<?php easymeals_core_template_part( 'plugins/recipe/post-types/recipe', 'templates/parts/post-info/social-share' ); ?>
		</div>
		<?php easymeals_core_template_part( 'plugins/recipe/post-types/recipe', 'templates/parts/post-info/media' ); ?>
		<div class="qodef-e-content qodef-e-content-under-image">
			<span class="qodef-m-title-lines"></span>
			<?php easymeals_core_template_part( 'plugins/recipe/post-types/recipe', 'templates/parts/post-info/preparation-time' ); ?>
			<?php easymeals_core_template_part( 'plugins/recipe/post-types/recipe', 'templates/parts/post-info/difficulty' ); ?>
			<?php easymeals_core_template_part( 'plugins/recipe/post-types/recipe', 'templates/parts/post-info/serves' ); ?>
			<?php easymeals_core_template_part( 'plugins/recipe/post-types/recipe', 'templates/parts/post-info/categories' ); ?>
			<span class="qodef-m-title-lines"></span>
		</div>
		<div class="qodef-e-content">
			<?php easymeals_core_template_part( 'plugins/recipe/post-types/recipe', 'templates/parts/post-info/content' ); ?>
			<?php easymeals_core_template_part( 'plugins/recipe/post-types/recipe', 'templates/parts/post-info/average-rating' ); ?>
			<?php easymeals_core_template_part( 'plugins/recipe/post-types/recipe', 'templates/parts/post-info/ingredients' ); ?>
			<?php easymeals_core_template_part( 'plugins/recipe/post-types/recipe', 'templates/parts/post-info/nutrition' ); ?>
			<?php easymeals_core_template_part( 'plugins/recipe/post-types/recipe', 'templates/parts/post-info/directions' ); ?>
			<?php easymeals_core_template_part( 'plugins/recipe/post-types/recipe', 'templates/parts/post-info/notes' ); ?>
		</div>
		<div class="qodef-e-content-bottom">
			<?php easymeals_core_template_part( 'plugins/recipe/post-types/recipe', 'templates/parts/post-info/like' ); ?>
			<div class="qodef-m-print"><a href="javascript:window.print()" class="qodef-e-print"><span class="qodef-icon-linear-icons lnr-printer lnr qodef-icon qodef-e"></span><span><?php esc_html_e('Print','easymeals-core') ?></span></a></div>
			<?php do_action('easymeals_core_action_recipe_side_info_last'); ?>
		</div>
		<?php easymeals_core_template_part( 'plugins/recipe/post-types/recipe', 'templates/parts/post-info/tags' ); ?>
		<?php easymeals_core_template_part( 'plugins/recipe/post-types/recipe', 'templates/parts/post-info/banner' ); ?>
	</div>
</article>
<?php
// Hook to include additional content after portfolio single item
do_action( 'easymeals_core_action_after_recipe_single_item' );
?>
<?php easymeals_core_template_part( 'plugins/recipe/post-types/recipe', 'templates/parts/post-info/comments' ); ?>
