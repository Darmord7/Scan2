<?php

include_once EASYMEALS_CORE_PLUGINS_PATH . '/recipe/post-types/recipe/helper.php';
include_once EASYMEALS_CORE_PLUGINS_PATH . '/recipe/post-types/recipe/profile/helper.php';

foreach ( glob( EASYMEALS_CORE_PLUGINS_PATH . '/recipe/post-types/recipe/dashboard/admin/*.php' ) as $module ) {
	include_once $module;
}

foreach ( glob( EASYMEALS_CORE_PLUGINS_PATH . '/recipe/post-types/recipe/dashboard/meta-box/*.php' ) as $module ) {
	include_once $module;
}

foreach ( glob( EASYMEALS_CORE_PLUGINS_PATH . '/recipe/post-types/recipe/dashboard/taxonomy/*.php' ) as $module ) {
	include_once $module;
}
foreach ( glob( EASYMEALS_CORE_PLUGINS_PATH . '/recipe/post-types/recipe/templates/single/*/include.php' ) as $single_part ) {
	include_once $single_part;
}