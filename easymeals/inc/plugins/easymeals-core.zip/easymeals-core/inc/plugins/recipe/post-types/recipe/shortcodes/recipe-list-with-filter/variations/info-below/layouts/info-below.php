<article <?php post_class( $item_classes ); ?>>
	<div class="qodef-e-inner">
		<div class="qodef-e-image">
			<?php easymeals_core_list_sc_template_part( 'plugins/recipe/post-types/recipe/shortcodes/recipe-list-with-filter', 'post-info/image', '', $params ); ?>
		</div>
		<div class="qodef-e-content">
				<div class="qodef-e-info-top">
					<?php easymeals_core_list_sc_template_part( 'plugins/recipe/post-types/recipe/shortcodes/recipe-list-with-filter', 'post-info/meta', '', $params ); ?>
				</div>
			<?php easymeals_core_list_sc_template_part( 'plugins/recipe/post-types/recipe/shortcodes/recipe-list-with-filter', 'post-info/title', '', $params ); ?>
		</div>
	</div>
</article>