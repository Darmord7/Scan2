<?php $author_id     = get_the_author_meta('ID'); ?>
<?php
global $authordata;
$link = get_author_posts_url( $authordata->ID, $authordata->user_nicename );
$link = sprintf( '<a href="%1$s" title="%2$s" rel="author">%3$s</a>',
	esc_url( add_query_arg('post_type', 'recipe', $link )),
	esc_attr( sprintf( 'Posts by %s', get_the_author())),
	get_the_author()
);
//echo $link;
?>
<div class="qodef-e qodef-info--author-date">
	<div class="qodef-m-image">
		<a itemprop="url" href="<?php echo esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ); ?>">
			<?php echo get_avatar( $author_id, 48 ); ?>
		</a>
	</div>
	<div class="qodef-m-text">
		<a itemprop="author" class="qodef-e-info-author-link" href="<?php echo esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ); ?>">
			<?php the_author_meta( 'display_name' ); ?>
		</a>
		<p itemprop="dateCreated" class="entry-date updated"><?php the_time( get_option( 'date_format' ) ); ?></p>
	</div>
</div>