<div class="qodef-e qodef-info--social-share">
	<?php if ( class_exists( 'EasyMealsCoreSocialShareShortcode' ) ) {
		$params = array(
			'title'  => esc_html__( 'Share:', 'easymeals-core' ),
			'layout' => 'text'
		);
		
		echo EasyMealsCoreSocialShareShortcode::call_shortcode( $params );
	} ?>
</div>