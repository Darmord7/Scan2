<div class="qodef-recipe-profile-my-recipes">
	<?php if ( $recipe_items ) { ?>
		<div class="qodef-m-section-title">
			<h3 class="qodef-m-title"><?php esc_html_e( 'My Recipes', 'easymeals-core' ); ?></h3>
			<p class="qodef-m-text"><?php esc_html_e( 'This is a list of all your recipes.', 'easymeals-core' ); ?></p>
		</div>
		<div class="qodef-m-recipe-items">
			<?php foreach ( $recipe_items as $id => $title ) { ?>
				<div class="qodef-m-item">
					<div class="qodef-m-content">
						<?php if ( has_post_thumbnail( $id ) ) {
							echo get_the_post_thumbnail( $id, 'thumbnail' );
						} ?>
						<h4 class="qodef-m-title">
							<a href="<?php the_permalink( $id ); ?>"><?php echo esc_html( $title ); ?></a>
						</h4>
					</div>
					<div class="qodef-m-buttons">
						<?php
							echo EasyMealsCoreButtonShortcode::call_shortcode( array(
								'custom_class' => 'qodef-recipe-item-preview',
								'link'         => esc_url( get_permalink( $id ) ),
								'target'       => '_blank',
								'button_layout'=> 'textual',
								'text'         => esc_html__( 'Preview', 'easymeals-core' )
							) );
							
							echo EasyMealsCoreButtonShortcode::call_shortcode( array(
								'custom_class' => 'qodef-recipe-item-edit',
								'button_layout'=> 'textual',
								'link'         => esc_url( add_query_arg( array( 'user-action' => 'edit-recipe', 'recipe_id'  => $id ), $dashboard_url ) ),
								'text'         => esc_html__( 'Edit', 'easymeals-core' )
							) );
							
							echo EasyMealsCoreButtonShortcode::call_shortcode( array(
								'custom_class' => 'qodef-recipe-item-delete',
								'link'         => '#',
								'button_layout'=> 'textual',
								'text'         => esc_html__( 'Delete', 'easymeals-core' ),
								'custom_attrs' => array(
									'data-recipe-id'   => $id,
									'data-confirm-text' => esc_html__( 'Are you sure you want to delete this recipe?', 'easymeals-core' )
								)
							) );
						?>
					</div>
				</div>
			<?php } ?>
		</div>
	<?php } else { ?>
		<h3 class="qodef-m--not-found"><?php esc_html_e( 'You haven\'t added any recipe yet.', 'easymeals-core' ); ?></h3>
	<?php } ?>
</div>