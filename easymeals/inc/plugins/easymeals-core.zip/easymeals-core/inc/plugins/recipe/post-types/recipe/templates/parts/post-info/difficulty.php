<?php
$difficulty = get_post_meta( get_the_ID(), 'qodef_recipe_single_difficulty', true);
$difficulty = easymeals_core_get_receipe_difficulty_label($difficulty);

if( ! empty( $difficulty ) ) { ?>
	<p class="qodef-recipe-difficulty">
		<span class="qodef-icon-linear-icons lnr-thumbs-up lnr qodef-icon qodef-e"></span>
		<?php echo esc_html( $difficulty ); ?>
	</p>
<?php }