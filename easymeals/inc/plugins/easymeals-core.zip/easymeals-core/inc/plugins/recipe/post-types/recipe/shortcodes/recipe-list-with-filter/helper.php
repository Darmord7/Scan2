<?php

if ( ! function_exists( 'easymeals_core_recipe_list_filter_query' ) ) {
	/**
	 * Function to adjust query for listing list parameters
	 */
	function easymeals_core_recipe_list_filter_query( $args, $params ) {

		if ( ! empty( $params['custom_search'] ) ) {
			$args['s'] = '"' . esc_attr( $params['custom_search'] ) . '"';
		}

		return $args;
	}

	add_filter('easymeals_filter_query_params', 'easymeals_core_recipe_list_filter_query', 10, 2);
}

if ( ! function_exists( 'masterds_core_get_recipe_list_filter' ) ) {
	function masterds_core_get_recipe_list_filter( $type, $params ) {
		$item_params = array();

		$item_params['filter_type']   = $type;
		$item_params['value']         = false;

		switch ( $type ) {

			case 'custom_search':
				$item_params['field_type']    = 'text';
				$item_params['default_label'] = esc_html__( 'What you are looking for?', 'easymeals-core' );
				$item_params['terms']		  = true;
				$item_params['value']         = isset( $params['custom_search'] ) && ! empty( $params['custom_search'] ) ? $params['custom_search'] : '';
				break;

			case 'category':
				$item_params['field_type']    = 'checkboxes';
				$item_params['default_label'] = esc_html__( 'Filter by Categories', 'easymeals-core' );
				$item_params['terms']		  = qode_framework_get_cpt_taxonomy_items( 'recipe-' . $type, false, true );
				break;

			case 'tag':
				$item_params['field_type']    = 'checkboxes';
				$item_params['default_label'] = esc_html__( 'Filter by Tags', 'easymeals-core' );
				$item_params['terms']		  = qode_framework_get_cpt_taxonomy_items( 'recipe-'.  $type, false, true );
				break;
		}

		easymeals_core_template_part( 'plugins/recipe/post-types/recipe/shortcodes/recipe-list-with-filter', 'templates/filter/filter-item', '', $item_params );
	}
}

if ( ! function_exists( 'masterds_core_include_recipe_list_filter_scripts' ) ) {
	/**
	 * Function that enqueue modules 3rd party scripts
	 *
	 * @param array $atts
	 */
	function masterds_core_include_recipe_list_filter_scripts() {

		wp_enqueue_script( 'show-more');
	}

	add_action( 'easymeals_core_filter_recipe_list_with_filter_register_assets', 'masterds_core_include_recipe_list_filter_scripts' );
}

if ( ! function_exists( 'masterds_core_register_recipe_list_filter_scripts' ) ) {
	/**
	 * Function that register modules 3rd party scripts
	 *
	 * @param array $scripts
	 *
	 * @return array
	 */
	function masterds_core_register_recipe_list_filter_scripts( $scripts ) {

		$scripts['show-more'] = array(
			'registered'	=> false,
			'url'			=> EASYMEALS_CORE_INC_URL_PATH . '/plugins/recipe/post-types/recipe/shortcodes/recipe-list-with-filter/assets/js/plugins/jquery-show-more.js',
			'dependency'	=> array( 'jquery' )
		);

		return $scripts;
	}

	add_filter( 'easymeals_core_filter_recipe_list_with_filter_register_assets', 'masterds_core_register_recipe_list_filter_scripts' );
}


if ( ! function_exists( 'masterds_core_listing_add_multiple_vars_pagination' ) ) {
	/**
	 * Function that extended global pagination options for this module
	 *
	 * @param array $data
	 * @param array $options
	 *
	 * @return array
	 */
	function masterds_core_listing_add_multiple_vars_pagination( $data, $options ) {

		if ( $options['shortcode'] == 'recipe-list-with-filter' ) {

			$data['max_num_pages'] = $options['query_result']->max_num_pages;

			if ( empty( $options['pagination_type_load_more_top_margin'] ) ) {
				$options['pagination_type_load_more_top_margin'] = '';
			}

			$data['pagination_html'] = easymeals_core_get_theme_template_part( 'pagination', 'templates/pagination', $options['pagination_type'], $options );
		}

		return $data;
	}

	add_action( 'easymeals_filter_pagination_data_return', 'masterds_core_listing_add_multiple_vars_pagination', 10, 2 );
}
