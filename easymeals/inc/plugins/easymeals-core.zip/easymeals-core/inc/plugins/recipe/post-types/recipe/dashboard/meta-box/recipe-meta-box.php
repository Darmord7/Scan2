<?php

if ( ! function_exists( 'easymeals_core_add_recipe_single_meta_box' ) ) {
	/**
	 * Function that add general options for this module
	 */
	function easymeals_core_add_recipe_single_meta_box() {
		$qode_framework = qode_framework_get_framework_root();
		
		$page = $qode_framework->add_options_page(
			array(
				'scope'  => array( 'recipe' ),
				'type'   => 'meta',
				'slug'   => 'recipe',
				'title'  => esc_html__( 'Recipe Settings', 'easymeals-core' ),
				'layout' => 'tabbed'
			)
		);
		
		if ( $page ) {
			
			/* General sections */
			
			$general_tab = $page->add_tab_element(
				array(
					'name'        => 'tab-general',
					'title'       => esc_html__( 'General Settings', 'easymeals-core' ),
					'description' => esc_html__( 'General information about recipe.', 'easymeals-core' )
				)
			);
			
			$general_tab->add_field_element(
				array(
					'field_type'  	=> 'select',
					'name'        	=> 'qodef_recipe_single_difficulty',
					'title'      	=> esc_html__( 'Difficulty', 'easymeals-core' ),
					'options'       => easymeals_core_get_receipe_difficulty(),
				)
			);
			
			$general_tab->add_field_element(
				array(
					'field_type'  	=> 'text',
					'name'        	=> 'qodef_recipe_preparation_time',
					'title'      	=> esc_html__( 'Preparation Time', 'easymeals-core' ),
				)
			);
			
			$general_tab->add_field_element(
				array(
					'field_type'  	=> 'text',
					'name'        	=> 'qodef_recipe_servings_number',
					'title'      	=> esc_html__( 'Servings Number', 'easymeals-core' ),
				)
			);
			
			$general_tab->add_field_element(
				array(
					'field_type'    => 'yesno',
					'name'          => 'qodef_recipe_has_video',
					'title'         => esc_html__( 'Upload Video for this recipe', 'easymeals-core' ),
					'options'       => easymeals_core_get_select_type_options_pool( 'no_yes' ),
					'default_value' => 'no'
				)
			);
			
			$general_tab->add_field_element(
				array(
					'field_type'  => 'text',
					'name'        => 'qodef_recipe_video_url',
					'title'       => esc_html__( 'Video URL', 'easymeals-core' ),
					'description' => esc_html__( 'Input your video link here. Here are all the supported video formats https://wordpress.org/support/article/video-shortcode/#options  https://wordpress.org/support/article/embeds/#okay-so-what-sites-can-i-embed-from', 'easymeals-core' ),
					'dependency'    => array(
						'show' => array(
							'qodef_recipe_has_video' => array(
								'values'        => 'yes',
								'default_value' => 'no'
							)
						)
					)
				)
			);
			
			/* Ingredients sections */
			
			$ingredients_section = $page->add_tab_element(
				array(
					'name'        => 'tab-ingredients',
					'title'       => esc_html__( 'Ingredients', 'easymeals-core' ),
				)
			);
			
			$ingredients_repeater = $ingredients_section->add_repeater_element(
				array(
					'name'        => 'qodef_recipe_single_ingredients_items',
					'title'       => esc_html__( 'Ingredients Item', 'easymeals-core' ),
					'button_text' => esc_html__( 'Add Ingredient', 'easymeals-core' )
				)
			);
			
			$ingredients_repeater->add_field_element(
				array(
					'field_type' => 'text',
					'name'       => 'qodef_recipe_single_ingredients_quantity',
					'title'      => esc_html__( 'Ingredient Quantity', 'easymeals-core' ),
				)
			);

			$ingredients_repeater->add_field_element(
				array(
					'field_type' => 'text',
					'name'       => 'qodef_recipe_single_ingredients_unit',
					'title'      => esc_html__( 'Ingredient Quantity Unit', 'easymeals-core' ),
				)
			);
			
			$ingredients_repeater->add_field_element(
				array(
					'field_type' => 'text',
					'name'       => 'qodef_recipe_single_ingredients_text',
					'title'      => esc_html__( 'Ingredient Name', 'easymeals-core' )
				)
			);
			$ingredients_repeater->add_field_element(
				array(
					'field_type' => 'text',
					'name'       => 'qodef_recipe_single_ingredients_link_text',
					'title'      => esc_html__( 'Ingredient Linked Text', 'easymeals-core' ),
					'description' => esc_html__('Enter the number of word that will be linked in text. If you want third word to be linked, enter 3', 'easymeals-core')
				)
			);
			$ingredients_repeater->add_field_element(
				array(
					'field_type' => 'text',
					'name'       => 'qodef_recipe_single_ingredients_link',
					'title'      => esc_html__( 'Ingredient Linked Text Link', 'easymeals-core' )
				)
			);
			$ingredients_repeater->add_field_element(
				array(
					'field_type' => 'text',
					'name'       => 'qodef_recipe_single_ingredients_note',
					'title'      => esc_html__( 'Ingredient Info Note', 'easymeals-core' )
				)
			);
			
			/* Additional ingridients sections */
			
			$add_ingredients_section = $page->add_tab_element(
				array(
					'name'        => 'tab-add-ingredients',
					'title'       => esc_html__( 'Additional Ingredients', 'easymeals-core' ),
				)
			);
			
			$add_ingredients_section->add_field_element(
				array(
					'field_type' => 'text',
					'name'       => 'qodef_recipe_single_add_ingredients_title',
					'title'      => esc_html__( 'Additional Ingredient Section Title', 'easymeals-core' ),
				)
			);
			
			$add_ingredients_repeater = $add_ingredients_section->add_repeater_element(
				array(
					'name'        => 'qodef_recipe_single_add_ingredients_items',
					'title'       => esc_html__( 'Additional Ingredients Item', 'easymeals-core' ),
					'button_text' => esc_html__( 'Add Ingredient', 'easymeals-core' )
				)
			);
			
			$add_ingredients_repeater->add_field_element(
				array(
					'field_type' => 'text',
					'name'       => 'qodef_recipe_single_add_ingredients_quantity',
					'title'      => esc_html__( 'Additional Ingredient Quantity', 'easymeals-core' ),
				)
			);

			$add_ingredients_repeater->add_field_element(
				array(
					'field_type' => 'text',
					'name'       => 'qodef_recipe_single_add_ingredients_unit',
					'title'      => esc_html__( 'Additional Ingredient Quantity Unit', 'easymeals-core' ),
				)
			);
			
			$add_ingredients_repeater->add_field_element(
				array(
					'field_type' => 'text',
					'name'       => 'qodef_recipe_single_add_ingredients_text',
					'title'      => esc_html__( 'Additional Ingredient Name', 'easymeals-core' )
				)
			);
			$add_ingredients_repeater->add_field_element(
				array(
					'field_type' => 'text',
					'name'       => 'qodef_recipe_single_add_ingredients_link_text',
					'title'      => esc_html__( 'Additional Ingredient Linked Text', 'easymeals-core' ),
					'description' => esc_html__('Enter the number of word that will be linked in text. If you want third word to be linked, enter 3', 'easymeals-core')
				)
			);
			$add_ingredients_repeater->add_field_element(
				array(
					'field_type' => 'text',
					'name'       => 'qodef_recipe_single_add_ingredients_link',
					'title'      => esc_html__( 'Additional Ingredient Linked Text Link', 'easymeals-core' )
				)
			);
			$add_ingredients_repeater->add_field_element(
				array(
					'field_type' => 'text',
					'name'       => 'qodef_recipe_single_add_ingredients_note',
					'title'      => esc_html__( 'Additional Ingredient Info Note', 'easymeals-core' )
				)
			);
			
			/* Nutrition sections */
			
			$nutrition_section = $page->add_tab_element(
				array(
					'name'        => 'tab-nutrition',
					'title'       => esc_html__( 'Nutrition Info', 'easymeals-core' ),
				)
			);
			
			$nutrition_repeater = $nutrition_section->add_repeater_element(
				array(
					'name'        => 'qodef_recipe_single_nutrition_items',
					'title'       => esc_html__( 'Nutrition Item', 'easymeals-core' ),
					'button_text' => esc_html__( 'Add Nutrition item', 'easymeals-core' )
				)
			);
			
			$nutrition_repeater->add_field_element(
				array(
					'field_type' => 'text',
					'name'       => 'qodef_recipe_single_nutrition_quantity',
					'title'      => esc_html__( 'Nutrition Quantity', 'easymeals-core' ),
				)
			);
			
			$nutrition_repeater->add_field_element(
				array(
					'field_type' => 'text',
					'name'       => 'qodef_recipe_single_nutrition_text',
					'title'      => esc_html__( 'Nutrition Name', 'easymeals-core' )
				)
			);
			
			/* Directions sections */
			
			$directions_section = $page->add_tab_element(
				array(
					'name'        => 'tab-directions',
					'title'       => esc_html__( 'Directions', 'easymeals-core' ),
				)
			);
			
			$directions_repeater = $directions_section->add_repeater_element(
				array(
					'name'        => 'qodef_recipe_single_direction_items',
					'title'       => esc_html__( 'Directions Item', 'easymeals-core' ),
					'button_text' => esc_html__( 'Add Directions item', 'easymeals-core' )
				)
			);
			
			$directions_repeater->add_field_element(
				array(
					'field_type'  	=> 'text',
					'name'        	=> 'qodef_recipe_single_direction_title',
					'title'      	=> esc_html__( 'Direction Title', 'easymeals-core' ),
				)
			);
			
			$directions_repeater->add_field_element(
				array(
					'field_type'  	=> 'textarea',
					'name'        	=> 'qodef_recipe_single_direction_text_top',
					'title'      	=> esc_html__( 'Direction Text Top', 'easymeals-core' ),
				)
			);
			$directions_repeater->add_field_element(
				array(
					'field_type' => 'image',
					'name'       => 'qodef_recipe_single_direction_gallery',
					'title'      => esc_html__( 'Upload Images', 'easymeals-core' ),
					'multiple'   => 'yes',
				)
			);
			$directions_repeater->add_field_element(
				array(
					'field_type'  	=> 'textarea',
					'name'        	=> 'qodef_recipe_single_direction_text_bottom',
					'title'      	=> esc_html__( 'Direction Text Bottom', 'easymeals-core' ),
				)
			);
			
			/* Notes sections */
			
			$notes_section = $page->add_tab_element(
				array(
					'name'        => 'tab-notes',
					'title'       => esc_html__( 'Notes', 'easymeals-core' ),
				)
			);
			
			$notes_repeater = $notes_section->add_repeater_element(
				array(
					'name'        => 'qodef_recipe_single_notes_items',
					'title'       => esc_html__( 'Notes Item', 'easymeals-core' ),
					'button_text' => esc_html__( 'Add Note', 'easymeals-core' )
				)
			);
			
			$notes_repeater->add_field_element(
				array(
					'field_type' => 'text',
					'name'       => 'qodef_recipe_single_note',
					'title'      => esc_html__( 'Note', 'easymeals-core' ),
				)
			);
			
			/* Banner sections */
			
			$banner_section = $page->add_tab_element(
				array(
					'name'        => 'tab-banner',
					'title'       => esc_html__( 'Banner', 'easymeals-core' ),
				)
			);
			
			$banner_section->add_field_element(
				array(
					'field_type' => 'image',
					'name'       => 'qodef_recipe_single_banner',
					'title'      => esc_html__( 'Upload Image', 'easymeals-core' ),
				)
			);
			$banner_section->add_field_element(
				array(
					'field_type' => 'text',
					'name'       => 'qodef_recipe_single_banner_link',
					'title'      => esc_html__( 'Link Image', 'easymeals-core' ),
				)
			);

			// Hook to include additional options after module options
			do_action( 'easymeals_core_action_after_recipe_meta_box_map', $page, $general_tab );
		}
	}
	
	add_action( 'easymeals_core_action_default_meta_boxes_init', 'easymeals_core_add_recipe_single_meta_box' );
}
