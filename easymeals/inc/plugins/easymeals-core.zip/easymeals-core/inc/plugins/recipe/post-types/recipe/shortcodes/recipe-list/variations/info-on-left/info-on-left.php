<?php

if ( ! function_exists( 'easymeals_core_add_recipe_list_variation_info_on_left' ) ) {
	function easymeals_core_add_recipe_list_variation_info_on_left( $variations ) {
		
		$variations['info-on-left'] = esc_html__( 'Info On Left', 'easymeals-core' );
		
		return $variations;
	}
	
	add_filter( 'easymeals_core_filter_recipe_list_layouts', 'easymeals_core_add_recipe_list_variation_info_on_left' );
}