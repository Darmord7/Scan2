(function ($) {
	"use strict";
	
	$(document).ready(function () {
		qodefServingsCalc.init();
		qodefCompleted.init();
		qodefPrintRecipe.init();
		qodefReinitRecipe.init();
	});
	
	var qodefServingsCalc = {
		init: function () {
		var $calculator = $('.qodef-servings-calc input');
		
		if($calculator.length) {
			var $ingredients = $('.qodef-m-ingredients-wrap'),
			$ingredient_q = $ingredients.find('.qodef-ingredient-quantity');
			
			$ingredient_q.each(function () {
				var $thisItem = $(this);
				var $initialValue = $(this).text();
				if(!isNaN($initialValue)) {
                    $calculator.on('input', function(evt) {
                        var $portions = this.value;
                        if($portions.length !== 0) {
                            var $value = $initialValue * $portions;
                            $thisItem.text($value);
                        }
                    });
                }
			});
		}
		},
	};
	
	var qodefCompleted = {
		init: function() {
			var $holder = $('.qodef-m-completed');
			
			if($holder.length) {
				$holder.each(function() {
					var $thisHolder = $(this);
					
					$thisHolder.on('click', function() {
						$thisHolder.parent().toggleClass('qodef-completed');
						$thisHolder.toggleClass('qodef-completed');
						if(($(this).find('span')).hasClass('icon_circle-empty')) {
							$(this).find('span.icon_circle-empty').removeClass('icon_circle-empty').addClass('icon_check');
						} else if(($(this).find('span')).hasClass('icon_check')) {
							$(this).find('span.icon_check').removeClass('icon_check').addClass('icon_circle-empty');
						}
					});
				});
			}
		},
	};

    var qodefPrintRecipe = {
        init: function() {
            var $holder = $('.qodef-recipe-single > article');

            if($holder.length) {
                $holder.each(function() {
                    var $thisHolder = $(this);
                    var $printButton = $thisHolder.find('.qodef-e-print');
                    $printButton.on('click',function (e) {
                        e.preventDefault();
                        $( document.body ).trigger( 'qodef_reciepe_printed' );
                        $thisHolder.printElement({printMode: 'popup'});
                    });
                });
            }
        },
    };

    var qodefReinitRecipe = {
        init: function() {
            $( document.body ).on( 'qodef_reciepe_printed', function () {
                qodefPrintRecipe;
            } );
        },
    };
	
})(jQuery);
