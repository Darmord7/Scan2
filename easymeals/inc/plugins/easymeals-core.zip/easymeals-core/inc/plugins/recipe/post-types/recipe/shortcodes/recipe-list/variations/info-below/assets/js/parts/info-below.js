(function($) {
    'use strict';

    $(document).ready(function () {
        qodefRecipeInfoBelow.init();
    });

    var qodefRecipeInfoBelow = {
        init: function () {
            this.holder = $('.qodef-recipe-list.qodef-item-layout--info-below');

            if ( this.holder.length ) {
                this.holder.each( function () {
                    var $thisHolder = $(this);

                    if ( $thisHolder.hasClass('qodef-zoom-out-effect') ) {
                        qodefRecipeInfoBelow.zoomOut( $thisHolder );
                    }

                    if ( $thisHolder.hasClass('qodef-appear-effect') ) {
                        qodefRecipeInfoBelow.appearAnimation( $thisHolder );
                    }
                });
            }
        },
        zoomOut: function ( $thisHolder ) {
            var $item = $thisHolder.find('article');

            $item.each( function() {
                var $thisItem = $(this);

                $thisItem.appear(function () {
                    $thisItem.addClass('qodef-zoom-out');
                }, { accX: 0, accY: 0 });
            })
        },
        appearAnimation: function( $thisHolder ) {
            $thisHolder.appear(function () {
                $thisHolder.addClass('qodef-appear');
            }, { accX: 0, accY: 0 });
        }
    };

})(jQuery);