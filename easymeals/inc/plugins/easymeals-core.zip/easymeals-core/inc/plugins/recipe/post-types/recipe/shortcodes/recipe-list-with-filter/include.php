<?php

include_once EASYMEALS_CORE_PLUGINS_PATH . '/recipe/post-types/recipe/shortcodes/recipe-list-with-filter/helper.php';
include_once EASYMEALS_CORE_PLUGINS_PATH . '/recipe/post-types/recipe/shortcodes/recipe-list-with-filter/recipe-list-with-filter.php';

foreach ( glob( EASYMEALS_CORE_PLUGINS_PATH . '/recipe/post-types/recipe/shortcodes/recipe-list-with-filter/variations/*/include.php' ) as $variation ) {
	include_once $variation;
}