<?php

include_once EASYMEALS_CORE_PLUGINS_PATH . '/recipe/post-types/recipe/templates/single/single-navigation/helper.php';
include_once EASYMEALS_CORE_PLUGINS_PATH . '/recipe/post-types/recipe/templates/single/single-navigation/dashboard/admin/single-navigation-options.php';