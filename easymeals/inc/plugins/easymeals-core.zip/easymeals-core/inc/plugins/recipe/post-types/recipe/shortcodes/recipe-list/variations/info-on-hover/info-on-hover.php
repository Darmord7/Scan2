<?php

if ( ! function_exists( 'easymeals_core_add_recipe_list_variation_info_on_hover' ) ) {
	function easymeals_core_add_recipe_list_variation_info_on_hover( $variations ) {
		
		$variations['info-on-hover'] = esc_html__( 'Info On Hover', 'easymeals-core' );
		
		return $variations;
	}
	
	add_filter( 'easymeals_core_filter_recipe_list_layouts', 'easymeals_core_add_recipe_list_variation_info_on_hover' );
}