<?php

if ( ! function_exists( 'easymeals_core_add_recipe_list_with_filter_variation_info_below' ) ) {
	function easymeals_core_add_recipe_list_with_filter_variation_info_below( $variations ) {
		
		$variations['info-below'] = esc_html__( 'Info Below', 'easymeals-core' );
		
		return $variations;
	}
	
	add_filter( 'easymeals_core_filter_recipe_list_with_filter_layouts', 'easymeals_core_add_recipe_list_with_filter_variation_info_below' );
}