<?php

if ( ! function_exists( 'easymeals_core_add_recipe_list_shortcode' ) ) {
	/**
	 * Function that isadding shortcode into shortcodes list for registration
	 *
	 * @param array $shortcodes - Array of registered shortcodes
	 *
	 * @return array
	 */
	function easymeals_core_add_recipe_list_shortcode( $shortcodes ) {
		$shortcodes[] = 'EasyMealsCoreRecipeListShortcode';
		
		return $shortcodes;
	}
	
	add_filter( 'easymeals_core_filter_register_shortcodes', 'easymeals_core_add_recipe_list_shortcode' );
}

if ( class_exists( 'EasyMealsCoreListShortcode' ) ) {
	class EasyMealsCoreRecipeListShortcode extends EasyMealsCoreListShortcode {
		
		public function __construct() {
			$this->set_post_type( 'recipe' );
			$this->set_post_type_taxonomy( 'recipe-category' );
			$this->set_post_type_additional_taxonomies( array( 'recipe-tag' ) );
			$this->set_layouts( apply_filters( 'easymeals_core_filter_recipe_list_layouts', array() ) );
			$this->set_extra_options( apply_filters( 'easymeals_core_filter_recipe_list_extra_options', array() ) );
			$this->set_hover_animation_options( apply_filters( 'easymeals_core_filter_recipe_list_hover_animation_options', array() ) );
			
			parent::__construct();
		}
		
		public function map_shortcode() {
			$this->set_shortcode_path( EASYMEALS_CORE_PLUGINS_URL_PATH . '/recipe/post-types/recipe/shortcodes/recipe-list' );
			$this->set_base( 'easymeals_core_recipe_list' );
			$this->set_name( esc_html__( 'Recipe List', 'easymeals-core' ) );
			$this->set_description( esc_html__( 'Shortcode that displays list of recipes', 'easymeals-core' ) );
			$this->set_category( esc_html__( 'EasyMeals Core', 'easymeals-core' ) );
			$this->set_scripts(
				apply_filters('easymeals_core_filter_recipe_list_register_assets', array())
			);

			$this->set_option( array(
				'field_type' => 'text',
				'name'       => 'custom_class',
				'title'      => esc_html__( 'Custom Class', 'easymeals-core' )
			) );
			$this->map_list_options();
			$this->map_query_options( array( 'post_type' => $this->get_post_type() ) );
			$this->map_layout_options( array(
				'layouts'          => $this->get_layouts(),
				'hover_animations' => $this->get_hover_animation_options(),
				'exclude_option' => array( 'text_transform' )
			) );
			if ( empty( $exclude_option ) || ( ! empty( $exclude_option ) && ! in_array( 'custom_padding', $exclude_option ) ) ) {
				$this->set_option( array(
					'field_type'    => 'select',
					'name'          => 'custom_padding',
					'title'         => esc_html__( 'Use Item Custom Padding', 'easymeals-core' ),
					'group'         => esc_html__( 'Layout', 'easymeals-core' ),
					'default_value' => 'no',
					'options'       => easymeals_core_get_select_type_options_pool( 'no_yes', false ),
				) );
			}
			$this->set_option( array(
				'field_type' => 'select',
				'name'       => 'enable_top_info',
				'title'      => esc_html__( 'Enable Top Info', 'easymeals-core' ),
				'options'    => easymeals_core_get_select_type_options_pool( 'no_yes', false ),
				'default_value' => 'no',
				'group'      => esc_html__( 'Layout', 'easymeals-core' )
			) );
			$this->set_option( array(
               'field_type' => 'select',
               'name'       => 'enable_categories',
               'title'      => esc_html__( 'Enable Categories', 'easymeals-core' ),
               'options'    => easymeals_core_get_select_type_options_pool( 'yes_no', false ),
               'default_value' => 'yes',
               'group'      => esc_html__( 'Layout', 'easymeals-core' )
            ) );
			$this->set_option( array(
               'field_type' => 'select',
               'name'       => 'enable_author_date',
               'title'      => esc_html__( 'Enable Author/Date Info', 'easymeals-core' ),
               'options'    => easymeals_core_get_select_type_options_pool( 'no_yes', false ),
               'default_value' => 'no',
               'group'      => esc_html__( 'Layout', 'easymeals-core' )
             ) );
			$this->set_option( array(
               'field_type' => 'select',
               'name'       => 'enable_share',
               'title'      => esc_html__( 'Enable Share', 'easymeals-core' ),
               'options'    => easymeals_core_get_select_type_options_pool( 'no_yes', false ),
               'default_value' => 'no',
               'group'      => esc_html__( 'Layout', 'easymeals-core' )
              ) );
			$this->set_option( array(
               'field_type' => 'select',
               'name'       => 'enable_like',
               'title'      => esc_html__( 'Enable Like', 'easymeals-core' ),
               'options'    => easymeals_core_get_select_type_options_pool( 'no_yes', false ),
               'default_value' => 'no',
               'group'      => esc_html__( 'Layout', 'easymeals-core' )
             ) );
			$this->set_option( array(
               'field_type' => 'select',
               'name'       => 'enable_bookmark',
               'title'      => esc_html__( 'Enable Bookmark', 'easymeals-core' ),
               'options'    => easymeals_core_get_select_type_options_pool( 'no_yes', false ),
               'default_value' => 'no',
               'group'      => esc_html__( 'Layout', 'easymeals-core' )
             ) );
			$this->set_option( array(
				'field_type' => 'select',
				'name'       => 'enable_excerpt',
				'title'      => esc_html__( 'Enable Excerpt', 'easymeals-core' ),
				'options'    => easymeals_core_get_select_type_options_pool( 'no_yes', false ),
				'default_value' => 'no',
				'group'      => esc_html__( 'Layout', 'easymeals-core' )
             ) );
			$this->set_option( array(
               'field_type' => 'text',
               'name'       => 'excerpt_length',
               'title'      => esc_html__( 'Excerpt Length', 'easymeals-core' ),
               'group'      => esc_html__( 'Layout', 'easymeals-core' )
             ) );
			$this->set_option( array(
				'field_type' => 'text',
				'name'       => 'excerpt_font_size',
				'title'      => esc_html__( 'Excerpt Font Size', 'easymeals-core' ),
				'group'      => esc_html__( 'Layout', 'easymeals-core' )
			) );
			$this->set_option( array(
				'field_type' => 'select',
				'name'       => 'white_bg',
				'title'      => esc_html__( 'White background', 'easymeals-core' ),
				'options'    => easymeals_core_get_select_type_options_pool( 'no_yes', false ),
				'default_value' => 'no',
				'group'      => esc_html__( 'Layout', 'easymeals-core' ),
				'dependency'  => array(
					'show' => array(
						'layout' => array(
							'values'        => array('info-on-right', 'info-below', 'info-on-left'),
							'default_value' => '',
						)
					),
				),
			) );
			$this->set_option( array(
				'field_type' => 'select',
				'name'       => 'tags_column',
				'title'      => esc_html__( 'Enable Tags', 'easymeals-core' ),
				'options'    => easymeals_core_get_select_type_options_pool( 'no_yes', false ),
				'default_value' => 'no',
				'group'      => esc_html__( 'Layout', 'easymeals-core' ),
				'dependency'  => array(
					'show' => array(
						'layout' => array(
							'values'        => 'info-below',
							'default_value' => '',
						)
					),
				),
			) );
            $this->set_option( array(
                'field_type'    => 'select',
                'name'          => 'hover_type',
                'title'         => esc_html__( 'Hover Type', 'easymeals-core' ),
                'options'       => array(
                    'none' => esc_html__( 'None', 'easymeals-core' ),
                    'move' => esc_html__( 'Move', 'easymeals-core' ),
                    'zoom' => esc_html__( 'Zoom', 'easymeals-core' )
                ),
                'default_value' => 'none',
                'group'         => esc_html__( 'Animation', 'easymeals-core' )
            ) );
            $this->set_option( array(
                'field_type'    => 'select',
                'name'          => 'appear_effect',
                'title'         => esc_html__( 'Enable Appear Effect', 'easymeals-core' ),
                'options'       => easymeals_core_get_select_type_options_pool( 'no_yes', false ),
                'default_value' => 'no',
                'group'         => esc_html__( 'Animation', 'easymeals-core' ),
                'dependency'    => array(
                    'show' => array(
                        'behavior' => array(
                            'values'        => 'columns',
                            'default_value' => 'columns',
                        )
                    ),
                )
            ) );
            $this->set_option( array(
                'field_type'    => 'select',
                'name'          => 'zoom_out_effect',
                'title'         => esc_html__( 'Enable Zoom Out Effect on Appear', 'easymeals-core' ),
                'options'       => easymeals_core_get_select_type_options_pool( 'no_yes', false ),
                'default_value' => 'no',
                'group'         => esc_html__( 'Animation', 'easymeals-core' ),
                'dependency'    => array(
                    'show' => array(
                        'behavior' => array(
                            'values'        => 'columns',
                            'default_value' => 'columns',
                        )
                    ),
                )
            ) );
			$this->map_additional_options();
			$this->map_extra_options();
		}
		
		public static function call_shortcode( $params ) {
			$html = qode_framework_call_shortcode( 'easymeals_core_recipe_list', $params );
			$html = str_replace( "\n", '', $html );
			
			return $html;
		}
		
		public function load_assets() {
			parent::load_assets();
			
			do_action( 'easymeals_core_action_recipe_list_load_assets', $this->get_atts() );
		}
		
		public function render( $options, $content = null ) {
			parent::render( $options );
			
			$atts = $this->get_atts();
			
			$atts['post_type']       = $this->get_post_type();
			$atts['taxonomy_filter'] = $this->get_post_type_taxonomy();
			
			// Additional query args
			$atts['additional_query_args'] = $this->get_additional_query_args( $atts );
			
			$atts['query_result']   = new \WP_Query( easymeals_core_get_query_params( $atts ) );
			$atts['holder_classes'] = $this->get_holder_classes( $atts );
			$atts['text_styles']    = $this->get_text_styles( $atts );
			//$atts['slider_attr']    = $this->get_slider_data( $atts );
			$atts['unique'] = wp_unique_id();
			$atts['slider_attr']    = $this->get_slider_data( $atts, array( 'unique' => $atts['unique'], 'outsideNavigation' => 'yes' ) );

			$atts['data_attr']      = easymeals_core_get_pagination_data( EASYMEALS_CORE_REL_PATH, 'plugins/recipe/post-types/recipe/shortcodes', 'recipe-list', 'recipe', $atts );
			
			$atts['this_shortcode'] = $this;
			
			return easymeals_core_get_template_part( 'plugins/recipe/post-types/recipe/shortcodes/recipe-list', 'templates/content', $atts['behavior'], $atts );
		}
		
		private function get_holder_classes( $atts ) {
			$holder_classes = $this->init_holder_classes();
			
			$holder_classes[] = 'qodef-recipe-list';
			$holder_classes[] = ! empty( $atts['layout'] ) ? 'qodef-item-layout--' . $atts['layout'] : '';
			$holder_classes[] = $atts['white_bg'] === 'yes' ? 'qodef-item--white-bg' : '';
			$holder_classes[] = $atts['tags_column'] === 'yes' ? 'qodef-item--with-tags' : '';
			$holder_classes[] = $atts['info_right_image_layout'] === 'yes' ? 'qodef-small-images' : '';
			$holder_classes[] = ! empty( $atts['hover_type'] ) ? 'qodef-hover-type--' . $atts['hover_type'] : '';
            $holder_classes[] = $atts['appear_effect'] === 'yes' ? 'qodef-appear-effect' : '';
			$holder_classes[] = $atts['zoom_out_effect'] === 'yes' ? 'qodef-zoom-out-effect' : '';

			$list_classes            = $this->get_list_classes( $atts );
			$hover_animation_classes = $this->get_hover_animation_classes( $atts );
			$holder_classes          = array_merge( $holder_classes, $list_classes, $hover_animation_classes );
			
			return implode( ' ', $holder_classes );
		}
		
		public function get_item_classes( $atts ) {
			$item_classes = $this->init_item_classes();
			
			$list_item_classes = $this->get_list_item_classes( $atts );
			
			$item_classes = array_merge( $item_classes, $list_item_classes );
			
			return implode( ' ', $item_classes );
		}
		
		public function get_list_item_style( $atts ) {
			$styles = array();
			
			if ( isset( $atts['custom_padding'] ) && $atts['custom_padding'] == 'yes' ) {
				$styles[] = 'padding: ' . get_post_meta( get_the_ID(), "qodef_recipe_item_padding", true );
			}
			
			return $styles;
		}

		private function get_text_styles( $atts ) {
			$styles = array();

			if ( ! empty( $atts['excerpt_font_size'] ) ) {
				if ( qode_framework_string_ends_with_typography_units( $atts['excerpt_font_size'] ) ) {
					$styles[] = 'font-size: ' . $atts['excerpt_font_size'];
				} else {
					$styles[] = 'font-size: ' . intval( $atts['excerpt_font_size'] ) . 'px';
				}
			}

			return $styles;
		}
	}
}