<?php if ( isset( $telephone ) && ! empty( $telephone ) ) { ?>
    <p class="qodef-m-text qodef--telephone">
        <span class="qodef-m-text-label"><?php esc_html_e( 'Telephone:', 'easymeals-core' ); ?></span>
        <span class="qodef-m-text-value"><?php echo qode_framework_wp_kses_html( 'content', $telephone ); ?></span>
    </p>
<?php } ?>
<?php if ( isset( $mobile_phone ) && ! empty( $mobile_phone ) ) { ?>
    <p class="qodef-m-text qodef--mobile-phone">
        <span class="qodef-m-text-label"><?php esc_html_e( 'Mobile Phone:', 'easymeals-core' ); ?></span>
        <span class="qodef-m-text-value"><?php echo qode_framework_wp_kses_html( 'content', $mobile_phone ); ?></span>
    </p>
<?php } ?>
<?php if ( isset( $fax_number ) && ! empty( $fax_number ) ) { ?>
    <p class="qodef-m-text qodef--fax-number">
        <span class="qodef-m-text-label"><?php esc_html_e( 'Fax Number:', 'easymeals-core' ); ?></span>
        <span class="qodef-m-text-value"><?php echo qode_framework_wp_kses_html( 'content', $fax_number ); ?></span>
    </p>
<?php } ?>
<?php if ( isset( $address ) && ! empty( $address ) ) { ?>
    <p class="qodef-m-text qodef--address">
        <span class="qodef-m-text-label"><?php esc_html_e( 'Address:', 'easymeals-core' ); ?></span>
        <span class="qodef-m-text-value"><?php echo qode_framework_wp_kses_html( 'content', $address ); ?></span>
    </p>
<?php } ?>