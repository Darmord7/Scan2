<?php

if ( ! function_exists( 'easymeals_core_remove_user_cook_role' ) ) {
	function easymeals_core_remove_user_cook_role() {
		remove_role( 'cook' );
		
		update_option( 'default_role', 'subscriber' );
	}
	
	add_action( 'easymeals_core_action_on_deactivation', 'easymeals_core_remove_user_cook_role' );
}
