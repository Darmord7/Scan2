<h1 itemprop="name" class="qodef-e-title entry-title qodef-recipe-title">
	<?php the_title(); ?>
</h1>