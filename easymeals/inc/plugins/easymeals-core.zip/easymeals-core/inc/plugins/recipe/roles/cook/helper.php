<?php

if ( ! function_exists( 'easymeals_core_add_cook_profile_page_content' ) ) {
	function easymeals_core_add_cook_profile_page_content( $params ) {
		
		if ( isset( $params['user'] ) && in_array( 'cook', $params['user']->roles ) ) {
			easymeals_core_template_part( 'plugins/recipe/roles/cook', 'templates/profile', 'additional', $params );
		}
	}
	
	add_action( 'easymeals_membership_action_additional_profile_page_content', 'easymeals_core_add_cook_profile_page_content' );
}

if ( ! function_exists( 'easymeals_core_get_cook_params' ) ) {
	/**
	 * Returns cook params
	 */
	function easymeals_core_get_cook_params( $params ) {
		
		if ( in_array( 'cook', $params['user']->roles ) ) {
			$user_id = $params['user']->data->ID;
			
			$params['telephone']           = get_user_meta( $user_id, 'qodef_cook_telephone', true );
			$params['mobile_phone']        = get_user_meta( $user_id, 'qodef_cook_mobile_phone', true );
			$params['fax_number']          = get_user_meta( $user_id, 'qodef_cook_fax_number', true );
			$params['address']             = get_user_meta( $user_id, 'qodef_cook_address', true );
			$params['cook_profile_image'] = get_user_meta( $user_id, 'qodef_cook_profile_image', true );
			
			if ( isset( $params['cook_profile_image'] ) && $params['cook_profile_image'] !== '' ) {
				$params['profile_image'] = wp_get_attachment_image( $params['cook_profile_image'], 'medium' );
			}
		}
		
		return $params;
	}
	
	add_filter( 'easymeals_membership_filter_user_params', 'easymeals_core_get_cook_params' );
}

if ( ! function_exists( 'easymeals_core_cook_edit_profile_fields' ) ) {
	function easymeals_core_cook_edit_profile_fields( $page, $params ) {
		if ( in_array( 'cook', $params['user']->roles ) ) {
			extract( $params );
			
			$page->add_field_element(
				array(
					'field_type'    => 'text',
					'name'          => 'qodef_cook_telephone',
					'title'         => esc_html__( 'Telephone', 'easymeals-core' ),
					'default_value' => $telephone
				)
			);
			
			$page->add_field_element(
				array(
					'field_type'    => 'text',
					'name'          => 'qodef_cook_mobile_phone',
					'title'         => esc_html__( 'Mobile Phone', 'easymeals-core' ),
					'default_value' => $mobile_phone
				)
			);
			
			$page->add_field_element(
				array(
					'field_type'    => 'text',
					'name'          => 'qodef_cook_fax_number',
					'title'         => esc_html__( 'Fax Number', 'easymeals-core' ),
					'default_value' => $fax_number
				)
			);
			
			$page->add_field_element(
				array(
					'field_type'    => 'text',
					'name'          => 'qodef_cook_address',
					'title'         => esc_html__( 'Address', 'easymeals-core' ),
					'default_value' => $address
				)
			);
			
			$page->add_field_element(
				array(
					'field_type'    => 'image',
					'name'          => 'qodef_cook_profile_image',
					'title'         => esc_html__( 'Profile Image', 'easymeals-core' ),
					'default_value' => $cook_profile_image
				)
			);
		}
	}
	
	add_action( 'easymeals_membership_action_after_dashboard_edit_profile_fields', 'easymeals_core_cook_edit_profile_fields', 10, 2 );
}

if ( ! function_exists( 'easymeals_core_cook_update' ) ) {
	function easymeals_core_cook_update( $options, $user_id ) {
		update_user_meta( $user_id, 'qodef_cook_telephone', $options['qodef_cook_telephone'] );
		update_user_meta( $user_id, 'qodef_cook_mobile_phone', $options['qodef_cook_mobile_phone'] );
		update_user_meta( $user_id, 'qodef_cook_fax_number', $options['qodef_cook_fax_number'] );
		update_user_meta( $user_id, 'qodef_cook_address', $options['qodef_cook_address'] );
		update_user_meta( $user_id, 'qodef_cook_profile_image', $options['qodef_cook_profile_image'] );
	}
	
	add_action( 'easymeals_membership_action_update_user_profile', 'easymeals_core_cook_update', 10, 2 );
}

if ( ! function_exists( 'easymeals_core_cook_role_approved_filter' ) ) {
	function easymeals_core_cook_role_approved_filter( $is_enabled ) {
		$user          = wp_get_current_user();
		$cook_approved = easymeals_core_get_post_value_through_levels( 'qodef_recipe_enable_cook_adding_recipe' );

		if ( $cook_approved !== 'yes' && in_array( 'cook', $user->roles ) ) {
			$is_enabled = false;
		}
		
		return $is_enabled;
	}
	
	add_filter( 'easymeals_core_filter_recipe_profile_navigation_item_visibility', 'easymeals_core_cook_role_approved_filter' );
}

if ( ! function_exists( 'easymeals_core_cook_limit_access_attachments' ) ) {
	function easymeals_core_cook_limit_access_attachments( $query ) {
		$user = wp_get_current_user();
		
		if ( in_array( 'cook', $user->roles ) ) {
			if ( ! current_user_can( 'edit_others_posts' ) ) {
				$query['author'] = $user->ID;
			}
		}
		
		return $query;
	}
	
	add_filter( 'ajax_query_attachments_args', 'easymeals_core_cook_limit_access_attachments' );
}
