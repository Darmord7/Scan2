<?php

if ( ! function_exists( 'easymeals_core_add_recipe_list_variation_info_on_right' ) ) {
	function easymeals_core_add_recipe_list_variation_info_on_right( $variations ) {
		
		$variations['info-on-right'] = esc_html__( 'Info on Right', 'easymeals-core' );
		
		return $variations;
	}
	
	add_filter( 'easymeals_core_filter_recipe_list_layouts', 'easymeals_core_add_recipe_list_variation_info_on_right' );
}

if ( ! function_exists( 'easymeals_core_add_recipe_list_options_info_right' ) ) {
	function easymeals_core_add_recipe_list_options_info_right( $options ) {
		$info_right_options   = array();

		$info_right_options[] = array(
			'field_type' => 'select',
			'name'       => 'info_right_image_layout',
			'title'      => esc_html__( 'Small Image Layout', 'easymeals-core' ),
			'options'    => easymeals_core_get_select_type_options_pool( 'no_yes', false ),
			'dependency' => array(
				'show' => array(
					'layout' => array(
						'values'        => 'info-on-right',
						'default_value' => ''
					)
				)
			),
			'group'      => esc_html__( 'Layout', 'easymeals-core' )
		);

		$margin_option        = array(
			'field_type' => 'text',
			'name'       => 'info_right_content_padding_right',
			'title'      => esc_html__( 'Content Right Padding', 'easymeals-core' ),
			'dependency' => array(
				'show' => array(
					'layout' => array(
						'values'        => 'info-on-right',
						'default_value' => ''
					)
				)
			),
			'group'      => esc_html__( 'Layout', 'easymeals-core' )
		);
		$info_right_options[] = $margin_option;

		$info_right_options[] = array(
			'field_type' => 'text',
			'name'       => 'info_right_content_padding_left',
			'title'      => esc_html__( 'Content Left Padding', 'easymeals-core' ),
			'dependency' => array(
				'show' => array(
					'layout' => array(
						'values'        => 'info-on-right',
						'default_value' => ''
					)
				)
			),
			'group'      => esc_html__( 'Layout', 'easymeals-core' )
		);

		return array_merge( $options, $info_right_options );
	}

	add_filter( 'easymeals_core_filter_recipe_list_extra_options', 'easymeals_core_add_recipe_list_options_info_right' );
}