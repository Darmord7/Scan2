<?php
$nutrition_items = get_post_meta( get_the_ID(), 'qodef_recipe_single_nutrition_items', true );

if ( ! empty ( $nutrition_items ) ) { ?>
	<div class="qodef-m-nutritions-table">
		<h4 class="qodef-m-nutritions-title"><?php esc_html_e('Nutritional Information','easymeals-core'); ?></h4>
		<div class="qodef-m-nutritions-table-inner">
			<?php foreach ( $nutrition_items as $item ) {
				$label  = $item['qodef_recipe_single_nutrition_text'];
				$value  = $item['qodef_recipe_single_nutrition_quantity'];
				?>
				<div class="qodef-e qodef-nutrition-items">
					<span class="qodef-nutrition-value"><?php echo wp_kses_post( $value ); ?></span>
					<?php if ( ! empty ( $label ) ) { ?>
						<span class="qodef-nutrition-label"><?php echo esc_html( $label ); ?></span>
					<?php } ?>
				</div>
			<?php } ?>
		</div>
	</div>
<?php } ?>