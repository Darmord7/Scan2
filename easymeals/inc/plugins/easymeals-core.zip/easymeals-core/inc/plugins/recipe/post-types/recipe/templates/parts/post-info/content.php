<div class="qodef-e qodef-recipe-content">
	<?php the_content(); ?>
</div>