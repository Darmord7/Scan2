<?php

include_once EASYMEALS_CORE_PLUGINS_PATH . '/recipe/post-types/recipe/shortcodes/recipe-category-list/variations/gallery/helper.php';