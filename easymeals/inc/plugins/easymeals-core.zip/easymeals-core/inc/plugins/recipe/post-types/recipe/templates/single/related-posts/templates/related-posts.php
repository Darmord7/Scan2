<?php
$post_id       = get_the_ID();
$is_enabled    = easymeals_core_get_post_value_through_levels( 'qodef_recipe_single_enable_related_posts' );
$related_posts = easymeals_core_get_custom_post_type_related_posts( $post_id, easymeals_core_get_recipe_single_post_taxonomies( $post_id ) );

if ( $is_enabled === 'yes' && ! empty( $related_posts ) ) { ?>
	<div id="qodef-recipe-single-related-items">
		<div class="qodef-shortcode qodef-m qodef-section-title qodef-title-with-lines">
			<h3 class="qodef-m-title">
				<span><?php esc_html_e('You may like these too','easymeals-core'); ?></span>
				<span class="qodef-m-title-lines"></span>
			</h3>
		</div>
		<?php if ( class_exists( 'EasyMealsCoreRecipeListShortcode' ) ) {
			$params = apply_filters( 'easymeals_core_filter_recipe_single_related_posts_params', array(
				'custom_class'      => 'qodef--no-bottom-space',
				'columns'           => '4',
				'posts_per_page'    => 4,
				'additional_params' => 'tax',
				'tax'               => $related_posts['taxonomy'],
				'tax__in'           => $related_posts['items'],
				'layouts'           => 'info-below',
				'enable_categories' => 'no',
				'space'             => 'small',
				'title_tag'         => 'h6',
				'excerpt_length'    => '100',
				'info_below_content_margin_top' => '0'
			) );
			
			echo EasyMealsCoreRecipeListShortcode::call_shortcode( $params );
		}
		?>
	</div>
<?php } ?>