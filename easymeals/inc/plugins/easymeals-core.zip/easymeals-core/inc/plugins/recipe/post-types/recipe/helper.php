<?php

if ( ! function_exists( 'easymeals_core_generate_recipe_single_layout' ) ) {
	function easymeals_core_generate_recipe_single_layout() {
		$template = 'default';
		
		return $template;
	}
	
	add_filter( 'easymeals_core_filter_recipe_single_layout', 'easymeals_core_generate_recipe_single_layout' );
}

if ( ! function_exists( 'easymeals_core_set_recipe_custom_sidebar_name' ) ) {
	/**
	 * Function that return sidebar name
	 *
	 * @param string $sidebar_name
	 *
	 * @return string
	 */
	function easymeals_core_set_recipe_custom_sidebar_name( $sidebar_name ) {
		
		if( is_singular( 'recipe' ) ) {
			$option = easymeals_core_get_post_value_through_levels( 'qodef_recipe_single_custom_sidebar' );
		} elseif ( is_tax() ) {
			$taxonomies = get_object_taxonomies( 'recipe' );
			
			foreach ( $taxonomies as $tax ) {
				if ( is_tax( $tax ) ) {
					$option = easymeals_core_get_post_value_through_levels( 'qodef_recipe_archive_custom_sidebar' );
				}
			}
		}
		
		if ( isset( $option ) && ! empty( $option ) ) {
			$sidebar_name = $option;
		}
		
		return $sidebar_name;
	}
	
	add_filter( 'easymeals_filter_sidebar_name', 'easymeals_core_set_recipe_custom_sidebar_name' );
}

if ( ! function_exists( 'easymeals_core_set_recipe_sidebar_layout' ) ) {
	/**
	 * Function that return sidebar layout
	 *
	 * @param string $layout
	 *
	 * @return string
	 */
	function easymeals_core_set_recipe_sidebar_layout( $layout ) {
		
		if( is_singular( 'recipe' ) ) {
			$option = easymeals_core_get_post_value_through_levels( 'qodef_recipe_single_sidebar_layout' );
		} elseif( is_tax() ) {
			$taxonomies = get_object_taxonomies( 'recipe' );
			foreach ( $taxonomies as $tax ) {
				if( is_tax( $tax ) ) {
					$option = easymeals_core_get_post_value_through_levels( 'qodef_recipe_archive_sidebar_layout' );
				}
			}
		}
		
		if ( isset( $option ) && ! empty( $option ) ) {
			$layout = $option;
		}
		
		return $layout;
	}
	
	add_filter( 'easymeals_filter_sidebar_layout', 'easymeals_core_set_recipe_sidebar_layout' );
}

if ( ! function_exists( 'easymeals_core_set_recipe_sidebar_grid_gutter_classes' ) ) {
	/**
	 * Function that returns grid gutter classes
	 *
	 * @param string $classes
	 *
	 * @return string
	 */
	function easymeals_core_set_recipe_sidebar_grid_gutter_classes( $classes ) {
		
		if( is_singular( 'recipe' ) ) {
			$option = easymeals_core_get_post_value_through_levels( 'qodef_recipe_single_sidebar_grid_gutter' );
		} elseif( is_tax() ) {
			$taxonomies = get_object_taxonomies( 'recipe' );
			foreach ( $taxonomies as $tax ) {
				if( is_tax( $tax ) ) {
					$option = easymeals_core_get_post_value_through_levels( 'qodef_recipe_archive_sidebar_grid_gutter' );
				}
			}
		}
		if ( isset( $option ) && ! empty( $option ) ) {
			$classes = 'qodef-gutter--' . esc_attr( $option );
		}
		
		return $classes;
	}
	
	add_filter('easymeals_filter_grid_gutter_classes', 'easymeals_core_set_recipe_sidebar_grid_gutter_classes');
}

if ( ! function_exists( 'easymeals_core_add_administrator_capabilites_recipe' ) ) {
	function easymeals_core_add_administrator_capabilites_recipe( $cpts ) {
		$cpts[] = 'recipe';
		
		return $cpts;
	}
	
	add_filter( 'easymeals_core_filter_administrator_cpts', 'easymeals_core_add_administrator_capabilites_recipe' );
}

if ( ! function_exists( 'easymeals_core_disable_page_title_for_recipe_single' ) ) {
	/**
	 * Function that disable page title area
	 *
	 * @param bool $enable_page_title
	 *
	 * @return bool
	 */
	function easymeals_core_disable_page_title_for_recipe_single( $enable_page_title ) {
		if ( is_singular( 'recipe' ) ) {
			$enable_page_title = false;
		}
		
		return $enable_page_title;
	}
	
	add_filter( 'easymeals_filter_enable_page_title', 'easymeals_core_disable_page_title_for_recipe_single' );
}


if ( ! function_exists( 'easymeals_core_add_administrator_capabilites_recipe' ) ) {
	function easymeals_core_add_administrator_capabilites_recipe( $cpts ) {
		$cpts[] = 'recipe';
		
		return $cpts;
	}
	
	add_filter( 'easymeals_core_filter_administrator_cpts', 'easymeals_core_add_administrator_capabilites_recipe' );
}

if ( ! function_exists( 'easymeals_core_get_receipe_difficulty' ) ) {
	/**
	 * Returns array of price range
	 *
	 * @return array
	 */
	function easymeals_core_get_receipe_difficulty() {
		$options = array();

		$options['super easy'] = esc_html__( 'Super Easy', 'easymeals-core' );
		$options['easy'] = esc_html__( 'Easy', 'easymeals-core' );
		$options['medium'] = esc_html__( 'Medium', 'easymeals-core' );
		$options['hard'] = esc_html__( 'Hard', 'easymeals-core' );
		$options['very difficult'] = esc_html__( 'Very Difficult', 'easymeals-core' );
		
		return $options;
	}
}

if ( ! function_exists('easymeals_core_get_receipe_difficulty_label')) {
	function easymeals_core_get_receipe_difficulty_label($value) {
		$label = '';
		if($value !== '') {
			switch ( $value ) {
				case 'super easy':
					$label = esc_html__('super easy','easymeals-core');
					break;
				case 'easy':
					$label = esc_html__('easy','easymeals-core');
					break;
				case 'medium':
					$label = esc_html__('medium','easymeals-core');
					break;
				case 'hard':
					$label = esc_html__('hard','easymeals-core');
					break;
				case 'very difficult':
					$label = esc_html__('very difficult','easymeals-core');
					break;
				default:
					$label = esc_html__('medium','easymeals-core');
					break;
			}
		}
		return $label;
	}
}

if ( ! function_exists( 'easymeals_core_get_recipe_holder_classes' ) ) {
	/**
	 * Function that return classes for the main team holder
	 *
	 * @return string
	 */
	function easymeals_core_get_recipe_holder_classes() {
		$classes = array( '' );
		
		$classes[]   = 'qodef-recipe-single';
		
		$item_layout = easymeals_core_generate_recipe_single_layout();
		$classes[]   = 'qodef-item-layout--' . $item_layout;
		
		return implode( ' ', $classes );
	}
}

if ( ! function_exists( 'easymeals_core_get_recipe_single_post_taxonomies' ) ) {
	/**
	 * Function that return single post taxonomies list
	 *
	 * @param int $post_id
	 *
	 * @return array
	 */
	function easymeals_core_get_recipe_single_post_taxonomies( $post_id ) {
		$options = array();
		
		if ( ! empty( $post_id ) ) {
			$options['recipe-tag']      = wp_get_post_terms( $post_id, 'recipe-tag' );
			$options['recipe-category'] = wp_get_post_terms( $post_id, 'recipe-category' );
		}
		
		return $options;
	}
}

if ( ! function_exists( 'easymeals_core_generate_recipe_archive_with_shortcode' ) ) {
	/**
	 * Function that executes recipe list shortcode with params on archive pages
	 *
	 * @param string $tax - type of taxonomy
	 * @param string $tax_slug - slug of taxonomy
	 *
	 */
	function easymeals_core_generate_recipe_archive_with_shortcode( $tax, $tax_slug ) {
		$params = array();
		$posts_per_page = get_option( 'posts_per_page' );

		$params['additional_params']         = 'tax';
		$params['tax']                       = $tax;
		$params['tax_slug']                  = $tax_slug;
		$params['posts_per_page']            = ! empty( $posts_per_page ) ? intval( $posts_per_page ) : 9;
		$params['layout']                    = easymeals_core_get_post_value_through_levels( 'qodef_recipe_archive_item_layout' );
		$params['behavior']                  = easymeals_core_get_post_value_through_levels( 'qodef_recipe_archive_behavior' );
		$params['masonry_images_proportion'] = easymeals_core_get_post_value_through_levels( 'qodef_recipe_archive_masonry_images_proportion' );
		$params['images_proportion'] = 'custom';
		$params['custom_image_width'] = '500px';
		$params['custom_image_height'] = '667px';
		$params['title_tag'] = 'h3';
		$params['info_below_title_margin_bottom'] = '20px';
		$params['enable_top_info'] = 'yes';
		$params['excerpt_font_size'] = '16px';
		$params['columns']                   = easymeals_core_get_post_value_through_levels( 'qodef_recipe_archive_columns' );
		$params['space']                     = easymeals_core_get_post_value_through_levels( 'qodef_recipe_archive_space' );
		$params['columns_responsive']        = easymeals_core_get_post_value_through_levels( 'qodef_recipe_archive_columns_responsive' );
		$params['columns_1440']              = easymeals_core_get_post_value_through_levels( 'qodef_recipe_archive_columns_1440' );
		$params['columns_1366']              = easymeals_core_get_post_value_through_levels( 'qodef_recipe_archive_columns_1366' );
		$params['columns_1024']              = easymeals_core_get_post_value_through_levels( 'qodef_recipe_archive_columns_1024' );
		$params['columns_768']               = easymeals_core_get_post_value_through_levels( 'qodef_recipe_archive_columns_768' );
		$params['columns_680']               = easymeals_core_get_post_value_through_levels( 'qodef_recipe_archive_columns_680' );
		$params['columns_480']               = easymeals_core_get_post_value_through_levels( 'qodef_recipe_archive_columns_480' );
		$params['slider_loop']               = easymeals_core_get_post_value_through_levels( 'qodef_recipe_archive_slider_loop' );
		$params['slider_autoplay']           = easymeals_core_get_post_value_through_levels( 'qodef_recipe_archive_slider_autoplay' );
		$params['slider_speed']              = easymeals_core_get_post_value_through_levels( 'qodef_recipe_archive_slider_speed' );
		$params['slider_navigation']         = easymeals_core_get_post_value_through_levels( 'navigation' );
		$params['slider_pagination']         = easymeals_core_get_post_value_through_levels( 'pagination' );
		$params['pagination_type']           = 'load-more';
		$params['enable_excerpt']           = 'yes';
		
		echo EasyMealsCoreRecipeListShortcode::call_shortcode( $params );
	}
}

if ( ! function_exists( 'easymeals_core_include_recipe_shortcodes_widget' ) ) {
	/**
	 * Function that includes widgets
	 */
	function easymeals_core_include_recipe_shortcodes_widget() {
		foreach ( glob( EASYMEALS_CORE_PLUGINS_PATH . '/recipe/post-types/recipe/shortcodes/*/widget/include.php' ) as $widget ) {
			include_once $widget;
		}
	}
	
	add_action( 'qode_framework_action_before_widgets_register', 'easymeals_core_include_recipe_shortcodes_widget' );
}

if ( ! function_exists( 'easymeals_core_set_recipe_archives_page_title_text' ) ) {
	/**
	 * Function that override current page title text for custom post type archive pages
	 *
	 * @param string $title
	 *
	 * @return string
	 */
	function easymeals_core_set_recipe_archives_page_title_text( $title ) {

		if ( is_tax( 'recipe-category' ) ) {
			$title = sprintf( esc_html__( 'Recipe Category: %s', 'easymeals-core' ), single_cat_title( '', false ) );
		} elseif ( is_tax( 'recipe-tag' ) ) {
			$title = sprintf( esc_html__( 'Recipe Tag: %s', 'easymeals-core' ), single_cat_title( '', false ) );
		} elseif ( is_post_type_archive( 'recipe' ) ) {
			$title = esc_html__( 'Recipes', 'easymeals-core' );
		}

		return $title;
	}

	add_filter( 'easymeals_filter_page_title_text', 'easymeals_core_set_recipe_archives_page_title_text' );
}

if ( ! function_exists( 'easymeals_core_recipe_print_script' ) ) {
	function easymeals_core_recipe_print_script() {
		wp_enqueue_script( 'printelement', EASYMEALS_CORE_PLUGINS_URL_PATH . '/recipe/assets/js/plugins/jquery.printelement.min.js', array( 'jquery' ), false, true );
	}

	add_action( 'easymeals_core_action_before_main_js', 'easymeals_core_recipe_print_script' );
}
