<?php

get_header();

$params = array();
$params['content'] = 'shortcode';
// Include cpt content template
easymeals_core_template_part( 'plugins/recipe/post-types/recipe', 'templates/content', '', $params );

get_footer();