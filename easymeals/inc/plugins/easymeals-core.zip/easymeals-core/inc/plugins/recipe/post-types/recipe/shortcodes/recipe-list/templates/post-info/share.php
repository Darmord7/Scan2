<?php if ( class_exists( 'EasyMealsCoreSocialShareShortcode' ) ) { ?>
	<div class="qodef-e-info-item qodef-e-info-social-share">
		<?php
		$params = array();
		
		echo EasyMealsCoreSocialShareShortcode::call_shortcode( $params ); ?>
	</div>
<?php } ?>