<?php if ( has_post_thumbnail() ) { ?>
	<div class="qodef-e-main-image">
		<a itemprop="url" href="<?php the_permalink(); ?>">
			<?php the_post_thumbnail( 'full' ); ?>
		</a>
	</div>
<?php } ?>