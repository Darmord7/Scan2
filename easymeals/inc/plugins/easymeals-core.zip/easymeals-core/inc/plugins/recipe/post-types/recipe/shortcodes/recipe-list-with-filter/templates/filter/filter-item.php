<?php

// Disable filter section if filter type is empty (type can be taxonomy name or custom)
if ( ! isset( $filter_type ) && empty( $filter_type ) ) {
	return;
}

// Check is filter section allowed
$is_option_set      = $value && $field_type !== 'text' && ! isset( $_GET['qodef-listing-search'] );
$hide_active_filter = isset( $hide_filter ) && $hide_filter === 'yes';

if ( ! $is_option_set || ( $is_option_set && ! $hide_active_filter ) ) { ?>
	<div class="qodef-e-section qodef-e-section--<?php echo esc_attr( $filter_type ); ?>">
		<?php easymeals_core_template_part( 'plugins/recipe/post-types/recipe/shortcodes/recipe-list-with-filter', 'templates/filter/' . $field_type, '', $params ); ?>
	</div>
<?php } ?>