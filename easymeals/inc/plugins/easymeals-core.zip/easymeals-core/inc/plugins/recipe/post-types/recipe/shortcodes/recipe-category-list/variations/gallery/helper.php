<?php

if ( ! function_exists( 'easymeals_core_add_recipe_category_list_variation_gallery' ) ) {
	function easymeals_core_add_recipe_category_list_variation_gallery( $variations ) {
		$variations['gallery'] = esc_html__( 'Gallery', 'easymeals-core' );
		
		return $variations;
	}
	
	add_filter( 'easymeals_core_filter_recipe_category_list_layouts', 'easymeals_core_add_recipe_category_list_variation_gallery' );
}
