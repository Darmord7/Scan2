<div class="qodef-m-like">
	<?php easymeals_core_get_like(); ?>
</div>