<?php
$ingredients_items = get_post_meta( get_the_ID(), 'qodef_recipe_single_ingredients_items', true );
$additional_ingredients_items = get_post_meta( get_the_ID(), 'qodef_recipe_single_add_ingredients_items', true );
$add_ingredients_title = get_post_meta( get_the_ID(), 'qodef_recipe_single_add_ingredients_title', true );

if ( ! empty ( $ingredients_items ) ) { ?>
	<div class="qodef-m-ingredients-wrap">
		<div class="qodef-shortcode qodef-m  qodef-section-title qodef-title-with-lines">
			<h3 class="qodef-m-title">
				<span><?php esc_html_e('Ingredients','easymeals-core'); ?></span>
				<span class="qodef-m-title-lines"></span>
			</h3>
		</div>
		<div class="qodef-servings-calc">
			<h6 class="qodef-quantity-title"><?php esc_html_e('Adjust Servings','easymeals-core'); ?></h6>
			<input type="text" class="qodef-quantity-input" data-step="1" data-min="1" data-max="" name="quantity" value="1" inputmode="numeric">
		</div>
		<table>
			<tbody>
			<?php
			foreach ( $ingredients_items as $item ) {
				$label  = $item['qodef_recipe_single_ingredients_text'];
				$value  = $item['qodef_recipe_single_ingredients_quantity'];
				$unit  = $item['qodef_recipe_single_ingredients_unit'];
				$info   = $item['qodef_recipe_single_ingredients_note'];
				$linked_text   = $item['qodef_recipe_single_ingredients_link_text'];
				$link   = $item['qodef_recipe_single_ingredients_link'];

				if ( ! empty( $label ) && ! empty( $linked_text ) ) {
					$split_title          = explode( ' ', $label );
					$link_positions = explode( ',', str_replace( ' ', '', $linked_text ) );

					foreach ( $link_positions as $position ) {
						$position = intval($position);
						if ( isset( $split_title[ $position - 1 ] ) && ! empty( $split_title[ $position - 1 ] ) ) {
							$split_title[ $position - 1 ] = '<a href="'. esc_url($link) .'" target="_blank">' . $split_title[ $position - 1 ] . '</a>';
						}
					}

					$label = implode( ' ', $split_title );
				}
				?>
				<tr class="qodef-e qodef-ingredients-items">
					<td class="qodef-m-completed">
						<span class="icon_circle-empty"></span>
					</td>
					<td>
						<span><span class="qodef-ingredient-quantity"><?php echo wp_kses_post( $value ); ?></span><?php echo esc_html( $unit ); ?></span>
						<span class="qodef-ingredient-label"><?php echo wp_kses_post( $label ); ?></span>
						<?php if ( ! empty ( $info ) ) { ?>
							<span class="qodef-note-opener">
							<span class="qodef-icon-elegant-icons icon_info qodef-icon qodef-e"></span>
							<span class="qodef-ingredient-note"><?php echo esc_html( $info ); ?></span>
							</span>
						<?php } ?>
					</td>
				</tr>
			<?php } ?>
			</tbody></table>
		<h6 class="qodef-additional-title"><?php echo esc_html($add_ingredients_title); ?></h6>
		<?php if ( ! empty ( $additional_ingredients_items ) ) { ?>
		<table>
			<tbody>
			<?php
			foreach ( $additional_ingredients_items as $item ) {
				$label  = $item['qodef_recipe_single_add_ingredients_text'];
				$value  = $item['qodef_recipe_single_add_ingredients_quantity'];
				$unit  = $item['qodef_recipe_single_add_ingredients_unit'];
				$info   = $item['qodef_recipe_single_add_ingredients_note'];
				$linked_text   = $item['qodef_recipe_single_add_ingredients_link_text'];
				$link   = $item['qodef_recipe_single_add_ingredients_link'];

				if ( ! empty( $label ) && ! empty( $linked_text ) ) {
					$split_title          = explode( ' ', $label );
					$link_positions = explode( ',', str_replace( ' ', '', $linked_text ) );

					foreach ( $link_positions as $position ) {
						if ( isset( $split_title[ $position - 1 ] ) && ! empty( $split_title[ $position - 1 ] ) ) {
							$split_title[ $position - 1 ] = '<a href="'. esc_url($link) .'" target="_blank">' . $split_title[ $position - 1 ] . '</a>';
						}
					}

					$label = implode( ' ', $split_title );
				}
				?>
				<tr class="qodef-e qodef-ingredients-items">
					<td class="qodef-m-completed">
						<span class="icon_circle-empty"></span>
					</td>
					<td>
						<span><span class="qodef-ingredient-quantity"><?php echo wp_kses_post( $value ); ?></span><?php echo esc_html( $unit ); ?></span>
						<span class="qodef-ingredient-label"><?php echo wp_kses_post( $label ); ?></span>
						<?php if ( ! empty ( $info ) ) { ?>
							<span class="qodef-note-opener">
							<span class="qodef-icon-elegant-icons icon_info qodef-icon qodef-e"></span>
							<span class="qodef-ingredient-note"><?php echo esc_html( $info ); ?></span>
							</span>
						<?php } ?>
					</td>
				</tr>
			<?php } ?>
			</tbody></table>
		<?php } ?>
	</div>
<?php } ?>