<?php

include_once EASYMEALS_CORE_PLUGINS_PATH . '/recipe/post-types/recipe/shortcodes/recipe-list/variations/info-on-left/info-on-left.php';