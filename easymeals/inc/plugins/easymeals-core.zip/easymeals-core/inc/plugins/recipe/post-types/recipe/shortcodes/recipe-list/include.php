<?php

include_once EASYMEALS_CORE_PLUGINS_PATH . '/recipe/post-types/recipe/shortcodes/recipe-list/recipe-list.php';

foreach ( glob( EASYMEALS_CORE_PLUGINS_PATH . '/recipe/post-types/recipe/shortcodes/recipe-list/variations/*/include.php' ) as $variation ) {
	include_once $variation;
}