<?php

if ( ! function_exists( 'easymeals_core_add_recipe_roles_options' ) ) {
	/**
	 * Function that add general options for this module
	 */
	function easymeals_core_add_recipe_roles_options( $page ) {
		
		$page->add_field_element(
			array(
				'field_type'    => 'yesno',
				'name'          => 'qodef_recipe_registration_role',
				'title'         => esc_html__( 'Enable Registration Role', 'easymeals-core' ),
				'description'   => esc_html__( 'Enable this if you want to allow users to choose role upon registration. Otherwise, default role from WP Settings -> General will be used.', 'easymeals-core' ),
				'default_value' => 'yes'
			)
		);
		
		$page->add_field_element(
			array(
				'field_type'    => 'yesno',
				'name'          => 'qodef_recipe_enable_cook_role',
				'title'         => esc_html__( 'Enable Cook Role', 'easymeals-core' ),
				'default_value' => 'yes',
				'dependency'    => array(
					'show' => array(
						'qodef_recipe_registration_role' => array(
							'values'        => 'yes',
							'default_value' => 'yes'
						)
					)
				)
			)
		);
		
		$page->add_field_element(
			array(
				'field_type'    => 'yesno',
				'name'          => 'qodef_recipe_enable_cook_adding_recipe',
				'title'         => esc_html__( 'Enable Adding Recipe Item for Cook', 'easymeals-core' ),
				'default_value' => 'yes',
			)
		);
	}
	
	add_action( 'easymeals_core_action_after_recipe_options_single', 'easymeals_core_add_recipe_roles_options' );
}