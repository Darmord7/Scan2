<div class="qodef-recipe-profile-add-recipe">
	<div class="qodef-lp-section-title">
		<h3 class="qodef-lp-st-title"><?php esc_html_e( 'Add New Recipe', 'easymeals-core' ); ?></h3>
		<p class="qodef-lp-st-text"><?php esc_html_e( 'You can create new recipes by filling out the fields below. Please note that fields marked with an asterisk (*) have to be filled before you can create your recipe.', 'easymeals-core' ); ?></p>
	</div>
	<div>
		<div id="qodef-page" class="qodef-options-front-end">
			<?php easymeals_core_dashboard_add_edit_recipe_fields( $params, 'add', '' ); ?>
		</div>
	</div>
</div>