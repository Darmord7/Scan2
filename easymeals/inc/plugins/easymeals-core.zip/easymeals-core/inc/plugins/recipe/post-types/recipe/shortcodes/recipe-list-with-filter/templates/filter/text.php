<div class="qodef-e-section-inner qodef-e-text" data-type="<?php echo esc_attr( $filter_type ); ?>">
	<input type="text" name="qodef-text-<?php echo esc_attr( $filter_type ); ?>" value="<?php echo esc_attr( $value ); ?>" placeholder="<?php echo esc_attr( $default_label ); ?>" />
</div>
