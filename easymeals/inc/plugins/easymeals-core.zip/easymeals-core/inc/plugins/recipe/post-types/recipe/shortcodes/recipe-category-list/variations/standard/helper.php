<?php

if ( ! function_exists( 'easymeals_core_add_recipe_category_list_variation_standard' ) ) {
	function easymeals_core_add_recipe_category_list_variation_standard( $variations ) {
		$variations['standard'] = esc_html__( 'Standard', 'easymeals-core' );
		
		return $variations;
	}
	
	add_filter( 'easymeals_core_filter_recipe_category_list_layouts', 'easymeals_core_add_recipe_category_list_variation_standard' );
}
