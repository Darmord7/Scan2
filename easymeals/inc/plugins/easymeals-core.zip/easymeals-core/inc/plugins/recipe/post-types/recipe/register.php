<?php

if ( ! function_exists( 'easymeals_core_register_recipe_for_meta_options' ) ) {
	function easymeals_core_register_recipe_for_meta_options( $post_types ) {
		$post_types[] = 'recipe';
		
		return $post_types;
	}
	
	add_filter( 'qode_framework_filter_meta_box_save', 'easymeals_core_register_recipe_for_meta_options' );
	add_filter( 'qode_framework_filter_meta_box_remove', 'easymeals_core_register_recipe_for_meta_options' );
	
	// Allow reviews for custom post type
	add_filter( 'easymeals_core_filter_rating_post_types', 'easymeals_core_register_recipe_for_meta_options' );
}

if ( ! function_exists( 'easymeals_core_add_recipe_custom_post_type' ) ) {
	/**
	 * Function that adds custom post type
	 *
	 * @param array $cpts
	 *
	 * @return array
	 */
	function easymeals_core_add_recipe_custom_post_type( $cpts ) {
		$cpts[] = 'EasyMealsCoreRecipeCPT';
		
		return $cpts;
	}
	
	add_filter( 'easymeals_core_filter_register_custom_post_types', 'easymeals_core_add_recipe_custom_post_type' );
}

if ( class_exists( 'QodeFrameworkCustomPostType' ) ) {
	class EasyMealsCoreRecipeCPT extends QodeFrameworkCustomPostType {
		
		public function map_post_type() {
			$name = esc_html__( 'Recipe', 'easymeals-core' );
			$this->set_base( 'recipe' );
			$this->set_menu_position( 33 );
			$this->set_menu_icon( 'dashicons-location-alt' );
			$this->set_slug( 'recipe' );
			$this->set_show_in_rest( true );
			$this->set_name( $name );
			$this->set_path( EASYMEALS_CORE_PLUGINS_PATH . '/recipe/post-types/recipe' );
			$this->set_labels( array(
				                   'name'          => esc_html__( 'EasyMeals Recipes', 'easymeals-core' ),
				                   'singular_name' => esc_html__( 'Recipe', 'easymeals-core' ),
				                   'add_item'      => esc_html__( 'New Recipe', 'easymeals-core' ),
				                   'add_new_item'  => esc_html__( 'Add New Recipe', 'easymeals-core' ),
				                   'edit_item'     => esc_html__( 'Edit Recipe', 'easymeals-core' )
			                   ) );
			$this->set_supports( array(
				                     'author',
				                     'revisions',
				                     'title',
				                     'thumbnail',
				                     'editor',
				                     'excerpt',
				                     'page-attributes',
				                     'comments',
			                     ) );
			
			$this->set_capability_type('recipe');
			
			$this->add_post_taxonomy( array(
				                          'base'          => 'recipe-category',
				                          'slug'          => 'recipe-category',
				                          'singular_name' => esc_html__( 'Category', 'easymeals-core' ),
				                          'plural_name'   => esc_html__( 'Categories', 'easymeals-core' ),
				                          'capabilities'	=> array(
					                          'manage_terms' => 'manage_categories',
					                          'edit_terms'   => 'manage_categories',
					                          'delete_terms' => 'manage_categories',
					                          'assign_terms' => 'edit_recipes'
				                          )
			                          ) );
			$this->add_post_taxonomy( array(
				                          'base'          => 'recipe-tag',
				                          'slug'          => 'recipe-tag',
				                          'singular_name' => esc_html__( 'Tag', 'easymeals-core' ),
				                          'plural_name'   => esc_html__( 'Tags', 'easymeals-core' ),
				                          'capabilities'	=> array(
					                          'manage_terms' => 'manage_categories',
					                          'edit_terms'   => 'manage_categories',
					                          'delete_terms' => 'manage_categories',
					                          'assign_terms' => 'edit_recipes'
				                          )
			                          ) );
		}
	}
}
