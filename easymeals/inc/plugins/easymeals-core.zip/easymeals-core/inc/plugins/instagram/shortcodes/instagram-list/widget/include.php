<?php

include_once EASYMEALS_CORE_PLUGINS_PATH . '/instagram/shortcodes/instagram-list/widget/instagram-list.php';