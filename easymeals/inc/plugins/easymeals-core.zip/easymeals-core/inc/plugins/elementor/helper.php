<?php

if ( ! function_exists( 'easymeals_core_get_elementor_instance' ) ) {
	function easymeals_core_get_elementor_instance() {
		return \Elementor\Plugin::instance();
	}
}

if ( ! function_exists( 'easymeals_core_get_elementor_widgets_manager' ) ) {
	function easymeals_core_get_elementor_widgets_manager() {
		return easymeals_core_get_elementor_instance()->widgets_manager;
	}
}

if ( ! function_exists( 'easymeals_core_load_elementor_widgets' ) ) {

	function easymeals_core_load_elementor_widgets() {

		$check_code = class_exists( 'EasyMealsCoreDashboard' ) ? EasyMealsCoreDashboard::get_instance()->get_code() : true;

		if ( ! empty( $check_code ) ) {
			foreach (glob(EASYMEALS_CORE_SHORTCODES_PATH . '/*/*-elementor.php') as $shortcode_load) {
				include_once $shortcode_load;
			}

			foreach (glob(EASYMEALS_CORE_INC_PATH . '/*/shortcodes/*/*-elementor.php') as $shortcode_load) {
				include_once $shortcode_load;
			}

			foreach (glob(EASYMEALS_CORE_CPT_PATH . '/*/shortcodes/*/*-elementor.php') as $shortcode_load) {
				include_once $shortcode_load;
			}

			foreach (glob(EASYMEALS_CORE_PLUGINS_PATH . '/*/shortcodes/*/*-elementor.php') as $shortcode_load) {
				include_once $shortcode_load;
			}
			foreach (glob(EASYMEALS_CORE_PLUGINS_PATH . '/*/post-types/*/shortcodes/*/*-elementor.php') as $shortcode_load) {
				include_once $shortcode_load;
			}
		}
	}
	
	add_action( 'elementor/widgets/widgets_registered', 'easymeals_core_load_elementor_widgets' );
}