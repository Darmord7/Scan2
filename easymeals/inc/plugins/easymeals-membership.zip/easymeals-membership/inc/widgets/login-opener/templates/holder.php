<?php

if ( is_user_logged_in() ) {
	easymeals_membership_template_part( 'widgets/login-opener', 'templates/logged-in-content' );
} else {
	easymeals_membership_template_part( 'widgets/login-opener', 'templates/logged-out-content' );
}