<a href="#" class="qodef-login-opener qodef-register">
	<?php echo qode_framework_icons()->render_icon( 'lnr-smile', 'linear-icons' ); ?>
    <span class="qodef-login-opener-text"><?php esc_html_e('Register', 'easymeals-membership'); ?></span>
</a>
<a href="#" class="qodef-login-opener qodef-login">
	<?php echo qode_framework_icons()->render_icon( 'lnr-user', 'linear-icons' ); ?>
    <span class="qodef-login-opener-text"><?php esc_html_e('Login', 'easymeals-membership'); ?></span>
</a>
