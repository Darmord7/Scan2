<div class="qodef-m-social-login">
	<span class="qodef-m-social-login-label"><?php esc_html_e('Or login with:', 'easymeals-membership'); ?></span>
	<?php do_action( 'easymeals_membership_action_social_login_content' ); ?>
</div>