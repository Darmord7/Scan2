<?php

include_once EASYMEALS_MEMBERSHIP_LOGIN_MODAL_PATH . '/helper.php';

foreach ( glob( EASYMEALS_MEMBERSHIP_LOGIN_MODAL_PATH . '/*/include.php' ) as $module ) {
	include_once $module;
}