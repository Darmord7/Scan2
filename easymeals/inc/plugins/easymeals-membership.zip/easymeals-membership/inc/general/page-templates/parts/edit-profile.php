<?php

if ( ! function_exists( 'easymeals_membership_dashboard_edit_profile_fields' ) ) {
	function easymeals_membership_dashboard_edit_profile_fields( $params ) {
		$qode_framework = qode_framework_get_framework_root();
		
		$page = $qode_framework->add_options_page(
			array(
				'type'         => 'front-end',
				'slug'         => 'edit-profile-page',
				'title'        => esc_html__( 'Edit Profile', 'easymeals-membership' ),
				'form_id'      => 'qodef-membership-edit-profile',
				'name'         => 'edit_profile_form',
				'method'       => 'POST',
				'button_label' => esc_html__( 'Update Profile', 'easymeals-membership' ),
				'button_args'  => array(
					'data-updating-text' => esc_html__( 'Updating Profile', 'easymeals-membership' ),
					'data-updated-text'  => esc_html__( 'Profile Updated', 'easymeals-membership' ),
					'data-rest-route'    => 'updateUserRestRoute',
					'data-rest-nonce'    => 'updateUserNonce',
				)
			)
		);
		
		if ( $page ) {
			extract( $params );
			
			$page->add_field_element(
				array(
					'field_type'    => 'text',
					'name'          => 'first_name',
					'title'         => esc_html__( 'First Name', 'easymeals-membership' ),
					'default_value' => $first_name
				)
			);
			
			$page->add_field_element(
				array(
					'field_type'    => 'text',
					'name'          => 'last_name',
					'title'         => esc_html__( 'Last Name', 'easymeals-membership' ),
					'default_value' => $last_name
				)
			);
			
			$page->add_field_element(
				array(
					'field_type'    => 'text',
					'name'          => 'user_email',
					'title'         => esc_html__( 'Email', 'easymeals-membership' ),
					'default_value' => $email
				)
			);
			
			$page->add_field_element(
				array(
					'field_type'    => 'text',
					'name'          => 'user_url',
					'title'         => esc_html__( 'Website', 'easymeals-membership' ),
					'default_value' => $website
				)
			);
			
			$page->add_field_element(
				array(
					'field_type'    => 'text',
					'name'          => 'description',
					'title'         => esc_html__( 'Description', 'easymeals-membership' ),
					'default_value' => $description
				)
			);

			$page->add_field_element(
				array(
					'field_type' => 'password',
					'name'       => 'user_password',
					'title'      => esc_html__( 'Password', 'easymeals-membership' )
				)
			);

			$page->add_field_element(
				array(
					'field_type' => 'text',
					'name'       => 'user_confirm_password',
					'title'      => esc_html__( 'Repeat Password', 'easymeals-membership' )
				)
			);

			do_action( 'easymeals_membership_action_after_dashboard_edit_profile_fields', $page, $params );
			
			$page->render();
		}
	}
}
?>
<div class="qodef-m-content-inner qodef--<?php echo esc_attr( isset( $action ) && ! empty( $action ) ? $action : 'dashboard' ); ?>">
    <div id="qodef-page" class="qodef-options-front-end">
	    <?php easymeals_membership_dashboard_edit_profile_fields( $params ); ?>
    </div>
</div>